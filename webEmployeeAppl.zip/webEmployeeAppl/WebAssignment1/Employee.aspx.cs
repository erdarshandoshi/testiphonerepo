﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Employee : System.Web.UI.Page
{
    EmployeeDTO e_DTO = new EmployeeDTO();
    EmpBAL e_BAL = new EmpBAL();

    public int EmpId // make readonly property to retrive data 
    {
        get 
        {
            if (!string.IsNullOrEmpty(Request.QueryString["Id"]))
            {
                return Convert.ToInt32(Request.QueryString["Id"]);
            }
            return 0;
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlbind();

            #region Edit
            if(this.EmpId > 0)
            {
                RetriveData();
                btnSubmit.Text = "Update";
               // btnSubmit.Text = "Cancel";
            }
            else
            {
                btnSubmit.Text = "ADD";
            }
            #endregion
            //Calendar1.Visible = false;
        }
    }

   

    private void RetriveData()
    {
        e_BAL = new EmpBAL();
        EmployeeDTO e_DTO = e_BAL.GetEmpById(this.EmpId);
        txtFirstName.Text = e_DTO.FirstName;
        TxtLastName.Text = e_DTO.LastName;
        txtJoiningDate.Text = e_DTO.JoiningDate.ToString("MM/dd/yyyy");
        txtEmailId.Text = e_DTO.EmailId;
        TxtDOB.Text = e_DTO.DOB.ToString("dd/MM/yyyy");
        if (e_DTO.Gender == "Male")
        {
            rdbMale.Checked = true;
        }
        else
        {
            rdbFemale.Checked = true;
        }
       
    }

    private void ddlbind()
    {
        DataSet ds = new DataSet();
        ds = e_BAL.GetAllDesignation();
        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        {
            ddlDesignation.DataTextField = "DesignationName";
            ddlDesignation.DataValueField = "Id";
            ddlDesignation.DataSource = ds;
            ddlDesignation.DataBind();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //if(((Button)sender).Text.Trim().ToLower() == "update")
        //{

        //}

        if(this.EmpId > 0)
        {
            e_DTO.Id = this.EmpId;
            
        }
        else
        {
            e_DTO.Id = 0;
        }

        e_DTO.FirstName = txtFirstName.Text;
        e_DTO.LastName = TxtLastName.Text;
        e_DTO.DesignationName = ddlDesignation.SelectedItem.Value;
        //DateTime _dt;
        //if (DateTime.TryParseExact(txtJoiningDate.Text, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _dt))
        //{
        //    e_DTO.JoiningDate = _dt;
        //}
        //else
        //{

        //}

        e_DTO.JoiningDate = Convert.ToDateTime(txtJoiningDate.Text);
        e_DTO.Gender = rdbMale.Checked ? "Male" : "Female";
        e_DTO.DOB = Convert.ToDateTime(TxtDOB.Text);
       // e_DTO.JoiningDate = cldJoiningDate.SelectedDate;
        e_DTO.EmailId = txtEmailId.Text;

        //    img()
        //    //string logo = FileUpload1.FileName;
        //    //FileUpload1.SaveAs(Server.MapPath("~/Images") + logo);
        //    if(FileUpload1.HasFile == true)
        //    {
        //        if(img()== true  )
        //        {
        //            if(FileUpload1.PostedFile.ContentLength > 4194304)
        //            {
        //                 Response.Write("File size should not greater than 4 MB ");

        //            }
        //            else
        //            {
        //                   string logo = FileUpload1.FileName;
        //                 FileUpload1.SaveAs(Server.MapPath("~/Images") + logo);
        //                Image1.ImageUrl();
        //            }
        //        }
        //        else
        //        {

        //        }
        //    }
        //    else{
        //        Response.Write ("INVALID");
        //    }
        bool result = e_BAL.InsertUpdateEmpDetails(e_DTO);




    }

    //private bool img()
    //{
    //    string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
    //    if(ext == "PNG" || ext == "GIF" || ext == "JPG")
    //    {
    //        return true;
    //    }
    //    else
    //    {
    //        return false;
    //    }
    //}
    protected void imgCalender_Click(object sender, ImageClickEventArgs e)
    {
        cldJoiningDate.Visible = true;
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtJoiningDate.Text = cldJoiningDate.SelectedDate.ToShortDateString();
        cldJoiningDate.Visible = false;
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.IsOtherMonth && e.Day.IsWeekend)
        {
            e.Day.IsSelectable = false;
            e.Cell.BackColor = System.Drawing.Color.Pink;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowDetails.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if(this.EmpId > 0)
        {
            Response.Redirect("ShowDetails.aspx");
        }
    }
}