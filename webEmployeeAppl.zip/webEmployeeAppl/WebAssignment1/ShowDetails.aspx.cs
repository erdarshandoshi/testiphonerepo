﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowDetails : System.Web.UI.Page
{
    #region Fields
    EmpBAL e_BAL = new EmpBAL();
    EmployeeDTO e_DTO = new EmployeeDTO();
    #endregion

    #region Properties
    #endregion

    #region Methods
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindEmployeeDetails();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Employee.aspx");
    }

    protected void lnkbtnDelete_Click(object sender, EventArgs e)
    {
        GridViewRow _row = ((LinkButton)sender).NamingContainer as GridViewRow;
        if (_row != null)
        {
            Label _id = _row.Cells[0].FindControl("lblId") as Label;
            if (_id != null && _id.Text != string.Empty)
            {
                int empId = Convert.ToInt32(_id.Text);
                if (empId > 0)
                {
                    if (e_BAL.DeleteEmpDetails(empId))
                    {
                        Response.Redirect("Employee.aspx"); //same page redirection

                    }
                    else
                    {
                        Label1.Text = "oops there is something goes wrong !!! We were unable to delete records...";
                        // you can set the text value of lable which will say like "ooups there is something goes wrong !!! We were unable to delete records"...
                    }
                    // call delete function of bal
                }
            }
        }
    }


    #endregion

    #region Private Functions
    private void BindEmployeeDetails()
    {
        List<EmployeeDTO> lst_dto = e_BAL.GetEmployeeDetails();
        GridView1.DataSource = lst_dto;
        GridView1.DataBind();
    }
    #endregion



    protected void lnkbtnEdit(object sender, EventArgs e)
    {
        GridViewRow _row = ((LinkButton)sender).NamingContainer as GridViewRow;
        if (_row != null)
        {
            Label _id = _row.Cells[0].FindControl("lblId") as Label;
            if (_id != null && _id.Text != string.Empty)
            {
                int empId = Convert.ToInt32(_id.Text);
                if (empId > 0)
                {
                    //if(e_BAL.GetEmpById(empId))
                    //{
                    Response.Redirect("Employee.aspx?id=" + empId);
                    //}
                }
                else
                {
                    Label1.Text = "oops there is something goes wrong !!! We were unable to Edit records...";
                }
            }
        }
    }
}