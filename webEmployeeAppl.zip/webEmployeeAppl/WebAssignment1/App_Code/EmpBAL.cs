﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAL;
using System.Data;



/// <summary>
/// Summary description for EmpBAL
/// </summary>
public class EmpBAL
{
    #region MyRegion
    DBManager m_db;
    EmployeeDTO e_DTO;
    #endregion
    public EmpBAL()
    {
        string con = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
        m_db = new DBManager(con);


    }

    public DataSet GetAllDesignation()
    {
        DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetAllDesignation");
        return ds;
    }

    public bool InsertUpdateEmpDetails(EmployeeDTO e_DTO)
    {
        HitechQueryParameter param = new HitechQueryParameter();
        param.AddQueryParameter("@Id", e_DTO.Id);
        param.AddQueryParameter("@FirstName", e_DTO.FirstName);
        param.AddQueryParameter("@LastName", e_DTO.LastName);
        param.AddQueryParameter("@Gender", e_DTO.Gender);
        param.AddQueryParameter("@DOB", e_DTO.DOB);
        param.AddQueryParameter("@JoiningDate", e_DTO.JoiningDate);
        param.AddQueryParameter("@ProfilePic", e_DTO.ProfilePic);
        param.AddQueryParameter("@EmailId", e_DTO.EmailId);
        param.AddQueryParameter("@FK_ID", e_DTO.DesignationName);
        m_db.ExecuteNonSPQuery("dbo.InsertUpdateEmpDetails", param);
        return true;
    }

    public List<EmployeeDTO> GetEmployeeDetails()
    {
        HitechQueryParameter param = new HitechQueryParameter();
        List<EmployeeDTO> lst_DTO = new List<EmployeeDTO>();
        DataSet ds = new DataSet();
        ds = m_db.ExecuteDataSetForProcedure("dbo.GetEmployeeDetails", param);

        if (ds != null && ds.Tables[0].Rows.Count > 0 && ds.Tables.Count > 0)
        {
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                EmployeeDTO e_DTO = new EmployeeDTO();
                e_DTO.Id = Convert.ToInt32(dr["Id"]);
                e_DTO.FirstName = Convert.ToString(dr["FirstName"]);
                e_DTO.LastName = Convert.ToString(dr["LastNmae"]);
                e_DTO.Gender = Convert.ToString(dr["Gender"]);
                e_DTO.DesignationName = Convert.ToString(dr["DesignationName"]);
                e_DTO.DOB = Convert.ToDateTime(dr["DOB"]);
                e_DTO.JoiningDate = Convert.ToDateTime(dr["JoiningDate"]);
                e_DTO.EmailId = Convert.ToString(dr["EmailId"]);
                lst_DTO.Add(e_DTO);
            }

        }

        return lst_DTO;
    }

    public bool DeleteEmpDetails(int empid)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@Id", empid);
            int dlt = m_db.ExecuteNonSPQuery("dbo.DeleteEmpDetails", param);
            return dlt > 0;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public EmployeeDTO GetEmpById(int empId)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("Id", empId);
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetEmpById", param);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                EmployeeDTO e_DTO = new EmployeeDTO();
                e_DTO.Id = Convert.ToInt32(ds.Tables[0].Rows[0]["Id"]);
                e_DTO.FirstName = Convert.ToString(ds.Tables[0].Rows[0]["FirstName"]);
                e_DTO.LastName = Convert.ToString(ds.Tables[0].Rows[0]["LastNmae"]);
                e_DTO.Gender = Convert.ToString(ds.Tables[0].Rows[0]["Gender"]);
                e_DTO.DesignationName = Convert.ToString(ds.Tables[0].Rows[0]["DesignationName"]);
                e_DTO.DOB = Convert.ToDateTime(ds.Tables[0].Rows[0]["DOB"]);
                e_DTO.JoiningDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["JoiningDate"]);
                e_DTO.EmailId = Convert.ToString(ds.Tables[0].Rows[0]["EmailId"]);
                return e_DTO;
            }
            else
            {
                return null;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
     
}
