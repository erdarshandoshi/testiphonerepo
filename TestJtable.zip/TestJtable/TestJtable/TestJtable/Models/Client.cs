﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TestJtable.Models
{
    public class Client
    {
        public long ID { get; set; }
         [Required(ErrorMessage = "Please enter your new Name")]
        public string Name { get; set; }
        [Required]
        public string ContactName { get; set; }
        public long Contact_ID { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long State_ID { get; set; }
        public string Zip { get; set; }
        public string PrimaryPhone { get; set; }
        public string Fax { get; set; }
        public string Notes { get; set; }
        public string Email { get; set; }
        public long Company_ID { get; set; }
        public string Attachments { get; set; }
        public bool Inactive { get; set; }
        //public DateTime CreateDate { get; set; }
        //public int UserId { get; set; }



    }
    public class state
    {
        public int ID { get; set; }
        public string State { get; set; }
    }
   
}