﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestJtable.Models
{
    public class Customer
    {
        public int customerid { get; set; }
        public string customername { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public char gender { get; set; }
        public long stateid { get; set; }
        public string state { get; set; }
        public int countyid { get; set; }
        public string county { get; set; }
        public bool isactive { get; set; }
        public string hobbies { get; set; }
        public DateTime createddate { get; set; }
        public DateTime deliverydate { get; set; }
    }
}