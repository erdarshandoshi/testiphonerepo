﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestJtable.Models;

namespace TestJtable.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View("Test");
        }

        // GET: Test/Details/5
        [HttpPost]
        public JsonResult Details(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            try
            {
                List<N_GetClient_Result> lstclient;
                using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
                {
                    lstclient = dbcontext.fnN_GetClient().ToList();
                    //List<Client> lstclient = new List<Client>();
                    //Client obj = new Client();
                    // var client = dbcontext.fnN_GetClient();
                    // foreach (var item in client)
                    // {
                    //     obj.Name = item.Name;
                    //     obj.Address = item.Address;
                    //     obj.ContactName = item.ContactName;
                    //     obj.Address = item.Address;
                    //     obj.City = item.City;
                    //     obj.State = item.State;
                    //     obj.Zip = item.Zip;
                    //     obj.PrimaryPhone = item.PrimaryPhone;
                    //     obj.Fax = item.Fax;
                    //     obj.Notes = item.Notes;
                    //     obj.Email = item.Email;
                    // }
                    // lstclient.Add(obj);
                    return Json(new { Result = "OK", Records = lstclient, TotalRecordCount = lstclient.Count });


                }
                #region sorting
                if (string.IsNullOrEmpty(jtSorting) || jtSorting.Equals("Name"))
                {
                    lstclient = lstclient.OrderBy(p => p.Name).ToList();
                }
                else if (jtSorting.Equals("Name DESC"))
                {
                    lstclient = lstclient.OrderByDescending(p => p.Name).ToList();
                }

                #endregion
                #region Paging
                if (jtPageSize > 0)
                {
                    lstclient = lstclient.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    lstclient = lstclient.ToList();
                }
                #endregion

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
            // return View();
        }

        // GET: Test/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Test/Create
        [HttpPost]
        public ActionResult CreateClient(Client record)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { Result = "ERROR", Message = "Form is not valid! Please correct it and try again." });
                }
                using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
                {
                    dbcontext.fnN_CreateClient(record.Name, record.ContactName, record.Address, record.City, record.State, record.Zip, record.PrimaryPhone, record.Fax, record.Notes, record.Email, record.Inactive);
                }
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }


        [HttpPost]
        public JsonResult UpdateClient(Client record)
        {

            // TODO: Add update logic here
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { Result = "ERROR", Message = "Form is not valid! Please correct it and try again." });
                }
                using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
                {
                    dbcontext.FnN_UpdateClient(record.ID, record.Name, record.ContactName, record.Address, record.City, record.State,record.State_ID, record.Zip, record.PrimaryPhone, record.Fax, record.Notes, record.Email, record.Inactive);
                }
                return Json(new { Result = "OK" });
            }



            //  return RedirectToAction("Index");
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        // GET: Test/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetStateOptions()
        {
            List<N_GetStateOptions_Result1> _states;
            using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
               
                _states = dbcontext.FnN_GetStateOptions().ToList();
                var _allstates = _states.Select(c => new { DisplayText = c.State, Value = c.State_ID });
                return Json(new { Result = "OK", Options = _allstates });
            }

        }

        // POST: Test/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
