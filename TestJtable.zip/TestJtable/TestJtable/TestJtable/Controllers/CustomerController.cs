﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestJtable.Models;

namespace TestJtable.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            List<N_customerlist_Result> lstcustomer;
            List<Customer> custlst = new List<Customer>();
            using(PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
                lstcustomer = dbcontext.FnN_customerlist().ToList();
                foreach (var item in lstcustomer)
                {
                    Customer cust = new Customer();
                    cust.customerid = item.customerid;
                    cust.customername = item.customername;
                    cust.email = item.email;
                    cust.password = item.password;
                    cust.gender = Convert.ToChar(item.gender);
                    cust.stateid = Convert.ToChar(item.stateid);
                    cust.state = item.statename;
                    cust.county = item.countyname;
                    custlst.Add(cust);
                }
            }

            return View("Customer", custlst.ToList());
        }

        // GET: Customer/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Customer/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Customer/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Customer/Edit/5
        [HttpGet]
        public ActionResult Edit(int customerid,int stateid)
        {
            Customer cust = new Customer();
            using(PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
              var result =  dbcontext.FnN_GetcustomerById(customerid);
              var item = result.FirstOrDefault();
              cust.customerid = item.customerid;
              cust.customername = item.customername;
              cust.email = item.email;
              cust.password = item.password;
              cust.gender = Convert.ToChar(item.gender);
              cust.stateid = Convert.ToChar(item.stateid);
              cust.state = item.statename;
              cust.county = item.countyname;
            }
            
            List<SelectListItem> alllst = new List<SelectListItem>();
            using(PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
              var countyvalue =  dbcontext.FnN_GetCountyByStateid(stateid).ToList();
              foreach (var item in countyvalue)
              {
                  SelectListItem lst = new SelectListItem();
                  lst.Value = Convert.ToInt64(item.ID).ToString();
                  lst.Text = item.County;
                  alllst.Add(lst);
              }
                
            }
            ViewBag.CountyDetails = alllst;

            List<SelectListItem> alllstofstate = new List<SelectListItem>();
            List<SelectListItem> allstate = new List<SelectListItem>();
            using(PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
                var statedetails = dbcontext.FnN_GetStateOptions().ToList();
                foreach (var item in statedetails)
                {
                    SelectListItem _alllst = new SelectListItem();
                    _alllst.Value = Convert.ToInt64(item.State_ID).ToString();
                    _alllst.Text = item.State;
                    alllstofstate.Add(_alllst);
                }
            }
            ViewBag.StateDetails = alllstofstate;
            return View("Edit",cust);
        }

        // POST: Customer/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Customer/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Customer/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
