﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestJtable.Models;

namespace TestJtable.Controllers
{
    public class Test2Controller : Controller
    {
        // GET: Test2
        public ActionResult Index()
        {
            List<N_GetClient_Result> lstclient;
            List<Client> lstobjclient = new List<Client>();
            using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
                lstclient = dbcontext.fnN_GetClient().ToList();
                foreach (var item in lstclient)
                {
                    Client obj = new Client();
                    obj.ID = item.ID;
                    obj.Address = item.Address;
                    obj.Name = item.Name;
                    obj.ContactName = item.ContactName;
                    obj.City = item.City;
                    obj.State = item.State;
                    obj.Zip = item.Zip;
                    obj.PrimaryPhone = item.PrimaryPhone;
                    obj.Fax = item.Fax;
                    obj.Notes = item.Notes;
                    obj.Email = item.Email;
                    // obj.Attachments = item.Attachments;
                    lstobjclient.Add(obj);

                }


            }
            
            return View("Test2", lstobjclient);
        }

        // GET: Test2/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Test2/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Test2/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Test2/Edit/5
        [HttpGet]
        public ActionResult Edit(int ID)
        {
            //FnN_GetClientById]
            Client obj = new Client();
            using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {
                var result = dbcontext.FnN_GetClientById(ID);
                var item = result.FirstOrDefault();
                obj.Address =  item.Address;
                obj.Name = item.Name;
                obj.ContactName = item.ContactName;
                obj.City = item.City;
                obj.State_ID = item.ID;
                obj.State = item.State;
                obj.Zip = item.Zip;
                obj.PrimaryPhone = item.PrimaryPhone;
                obj.Fax = item.Fax;
                obj.Notes = item.Notes;
                obj.Email = item.Email;
            }
            List<N_GetStateOptions_Result1> _states;
            List<SelectListItem> lst = new List<SelectListItem>();

            using (PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
            {

                _states = dbcontext.FnN_GetStateOptions().ToList();
                foreach (var item in _states)
                {
                    SelectListItem o = new SelectListItem();
                    o.Value = Convert.ToInt64(item.State_ID).ToString();
                    o.Text = item.State;
                    lst.Add(o);
                }

            }
            ViewBag.allstates = lst;

            return View("Edit",obj);
        }

        // POST: Test2/Edit/5
        [HttpPost]
        public ActionResult Edit(Client record)
        {
            try
            {
                // TODO: Add update logic here
                using(PTSNewHTML5Entities dbcontext = new PTSNewHTML5Entities())
                {
                    dbcontext.FnN_UpdateClient(record.ID, record.Name, record.ContactName, record.Address, record.City, record.State,record.State_ID, record.Zip, record.PrimaryPhone, record.Fax, record.Notes, record.Email, record.Inactive);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Test2/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Test2/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
