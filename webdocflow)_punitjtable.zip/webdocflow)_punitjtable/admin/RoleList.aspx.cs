﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebDocflow.BAL;
using WebDocflow.Models;

namespace WebDocflow.admin
{
    public partial class RoleList : System.Web.UI.Page
    {
        #region Fields
        private RoleBAL objRoleBAL = new RoleBAL();
        #endregion

        #region Public Methods

        #region Listing

        //[WebMethod(EnableSession = true)]
        [WebMethod]
        public static object RoleListing(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = "RoleName ASC")
        {
            try
            {
                int totalRecords = 0;

                RoleBAL objRoleBAL = new RoleBAL();
                int recordscount = 0;

                List<RoleDTO> lstRole = new List<RoleDTO>();
                IEnumerable<WebDocflow.Models.Role> newlist = objRoleBAL.GetAllRoles(ref totalRecords);
                recordscount = newlist.Count();
                foreach (var item in newlist)
                {
                    RoleDTO roleDTO = new RoleDTO();
                    roleDTO.RoleId = item.RoleId;
                    roleDTO.RoleName = item.RoleName;
                    roleDTO.IsActive = item.IsActive;
                    roleDTO.IsDelete = item.IsDeleted;
                    roleDTO.CreatedDate = item.CreatedDate;
                    lstRole.Add(roleDTO);
                }

                #region Sorting
                if (jtSorting == "RoleName ASC")
                {
                    lstRole = lstRole.OrderBy(p => p.RoleName).ToList();
                }
                else if (jtSorting == "RoleName DESC")
                {
                    lstRole = lstRole.OrderByDescending(p => p.RoleName).ToList();
                }
                else if (jtSorting == "IsActive ASC")
                {
                    lstRole = lstRole.OrderBy(p => p.IsActive).ToList();
                }
                else if (jtSorting == "IsActive DESC")
                {
                    lstRole = lstRole.OrderByDescending(P => P.IsActive).ToList();
                }
                else if (jtSorting == "IsDelete ASC")
                {
                    lstRole = lstRole.OrderBy(p => p.IsDelete).ToList();
                }
                else if (jtSorting == "IsDelete DESC")
                {
                    lstRole = lstRole.OrderByDescending(p => p.IsDelete).ToList();
                }
                else if (jtSorting == "Created Date ASC")
                {
                    lstRole = lstRole.OrderBy(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "Created Date DESC")
                {
                    lstRole = lstRole.OrderByDescending(p => p.CreatedDate).ToList();
                }
                #endregion

                #region Paging
                if(jtPageSize>0)
                {
                    lstRole = lstRole.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    lstRole = lstRole.ToList();
                }
                #endregion

                return new { Result = "OK", Records = lstRole, TotalRecordCount = totalRecords };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }

        }
        [WebMethod]
        public static object DeleteRole(int RoleId)
        {
            try
            {
                RoleBAL objRoleBAL = new RoleBAL();
                //objRoleBAL.DeleteRole(roleid);
                objRoleBAL.DeleteRole(RoleId);
                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }

        }

        [WebMethod(EnableSession = true)]
        public static object CreateRole(RoleDTO record)
        {
            try
            {
                RoleBAL objRoleBAL = new RoleBAL();
                int result = objRoleBAL.CreateRole(record);
                return new { Result = "OK", Record = result };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object UpdateRole(RoleDTO record)
        {
            try
            {
                RoleBAL objRoleBAL = new RoleBAL();
                objRoleBAL.UpdateRole(record);
                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }

        }



        #endregion


        #endregion

        #region Private Methods

        #endregion
    }
}
