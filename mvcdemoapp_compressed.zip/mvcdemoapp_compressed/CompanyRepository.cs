﻿using MVCDemo.Model;
using MVCDemo.Repository.Shared;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;


namespace MVCDemo.Repository
{
    public class CompanyRepository : Common
    {

        public CompanyRepository()
        {
            DBContext.Configuration.ProxyCreationEnabled = false;
        }

        public List<Company> CompanyList(ref int totalrecord)
        {
            var foundcompany = DBContext.Companies.ToList();
            totalrecord = foundcompany.Count();
            return foundcompany;
        }
        public void CreateCompany(Company company)
        {
            DBContext.Companies.Add(company);
            DBContext.SaveChanges();
        }

        public void Delete(int CompanyId)
        {
            var companyrecord = DBContext.Companies.Where(x => x.CompanyId == CompanyId).FirstOrDefault();
            DBContext.Companies.Remove(companyrecord);
            DBContext.SaveChanges();
        }

        public Company getById(int id)
        {
            try
            {
                return DBContext.Companies.Where(x => x.CompanyId == id).FirstOrDefault();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public void UpdateCompany(Company company)
        {
            //db.Entry(company).State = EntityState.Modified;
            DBContext.Entry(company).State = EntityState.Modified;
            DBContext.SaveChanges();
        }

        public List<Company> GetCompanyOption()
        {
            var compnydrp = DBContext.Companies.Where(c => c.IsActive && c.IsCustomer).ToList();
            return compnydrp;
        }
    }
}
