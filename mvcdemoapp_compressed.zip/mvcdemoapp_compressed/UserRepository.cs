﻿using MVCDemo.Model;
using MVCDemo.Repository.Shared;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;

namespace MVCDemo.Repository
{
    public class UserRepository : Common
    {



        #region methods
        public User ValidateUser(string emailid, string password)
        {
            try
            {
                User objuser = null;
                objuser = this.DBContext.Users.FirstOrDefault(x => x.EmailId.Trim().ToLower() == emailid.Trim().ToLower() && x.Password.Trim().ToLower() == password.Trim().ToLower());
                // objuser = this.DBContext.Users.FirstOrDefault(x=>EmailId.Trim().ToLower() == emailid.Trim().ToLower() && x.Password.Trim().ToLower() == password.Trim().ToLower());
                return objuser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        //public bool ValidateUser(string emailid, string password)
        //{
        //    try
        //    {
        //        if (!string.IsNullOrEmpty(emailid) || !string.IsNullOrEmpty(password))
        //        {

        //            bool objuser = this.DBContext.Users.ToList().Where(user => user.EmailId.ToLower() == emailid.ToLower().Trim() && user.Password == password).Count() > 0;
        //            return objuser;
        //        }

        //        else
        //        {

        //            return false;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public User getUser(string email, string pwd)
        //{
        //    User objuser = this.DBContext.Users.FirstOrDefault(x => x.EmailId.Trim().ToLower() == email.Trim().ToLower() && x.Password.Trim().ToLower() == pwd.Trim().ToLower());

        //   return objuser;
        //}

        public List<UserDTO> getUserList(ref int totalrecord, int recordperpage, int startindex, int page)
        {
            //List<User> userList;
            User objuser = new User();

            var List = from u in DBContext.Users
                       join c in DBContext.Companies on u.CompanyId equals c.CompanyId
                       join r in DBContext.Roles on u.RoleId equals r.RoleId
                       select new UserDTO
                       {
                           RoleId = r.RoleId,
                           RoleName = r.RoleName,
                           CompanyId = c.CompanyId,
                           CompanyName = c.CompanyName,
                           UserId = u.UserId,
                           UserName = u.UserName,
                           FirstName = u.FirstName,
                           LastName = u.LastName,
                           Location = u.Location,
                           EmailId = u.EmailId,
                           IsActive = u.IsActive,
                           IsDeleted = u.IsDeleted
                       };
            //List = List.Skip(startindex).Take(page);
            //List = List.Skip((page - 1) * recordperpage).Take(recordperpage);
            totalrecord = List.Count();

            return List.ToList();
        }

        public int CreateUser(UserDTO userDTO)
        {
            User objuser = new User();
            objuser.UserId = userDTO.UserId;
            objuser.UserName = userDTO.UserName;
            objuser.FirstName = userDTO.FirstName;
            objuser.LastName = userDTO.LastName;
            objuser.Location = userDTO.Location;
            objuser.EmailId = userDTO.EmailId;
            objuser.Password = userDTO.Password;
            objuser.IsActive = userDTO.IsActive;
            objuser.IsDeleted = userDTO.IsDeleted;
            objuser.RoleId = userDTO.RoleId;
            objuser.CompanyId = userDTO.CompanyId;
            objuser.CreatedDate = userDTO.CreatedDate;
            DBContext.Users.Add(objuser);
            return DBContext.SaveChanges();
        }

        //public void CreateUpdateUser(User objuser)
        //{
        //    DBContext.Users.Add(objuser);
        //    DBContext.SaveChanges();
        //}

        public User getUserById(int id)
        {
            return DBContext.Users.Where(x => x.UserId == id).FirstOrDefault();
        }

        public void UpdateUser(UserDTO userDTO)
        {


            var getuser = DBContext.Users.FirstOrDefault(x => x.UserId == userDTO.UserId);
            //if (getid != null)
            //{
            //User objuser = new User();
            // objuser.UserId = userDTO.UserId;
            DBContext.Users.Attach(getuser);
            getuser.UserName = userDTO.UserName;
            getuser.FirstName = userDTO.FirstName;
            getuser.LastName = userDTO.LastName;
            getuser.Location = userDTO.Location;
            getuser.EmailId = userDTO.EmailId;
            getuser.Password = userDTO.Password;
            getuser.IsActive = userDTO.IsActive;
            getuser.IsDeleted = userDTO.IsDeleted;
            getuser.RoleId = userDTO.RoleId;
            getuser.CompanyId = userDTO.CompanyId;
            getuser.CreatedDate = userDTO.CreatedDate;


            DBContext.Entry(getuser).State = EntityState.Modified;
            DBContext.SaveChanges();
        }
        //return true;
        //}

        public void DeleteUser(int id)
        {
            var deleteduser  = DBContext.Users.Where(x=>x.UserId == id).FirstOrDefault();
            DBContext.Users.Remove(deleteduser);
            DBContext.SaveChanges();
        }
    }
}
