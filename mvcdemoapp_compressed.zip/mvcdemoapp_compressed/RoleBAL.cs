﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVCDemo.Repository;
using MVCDemo.Model;


namespace MVCDemo.BAL
{
    public class RoleBAL
    {
        #region Private fields
        private RoleRepository _rolerepository;
       
        #endregion

        public void DeleteRole(int id)
        {
            try
            {
                RoleRepository _rolerepository = new RoleRepository();
                _rolerepository.DeleteRole(id);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
       
        public List<Role> RoleList(ref int totalRecords)
        {
            try
            {
                RoleRepository _rolerepository = new RoleRepository();
                return _rolerepository.RoleList(ref totalRecords);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }

        }
        public int CreateRole(RoleDTO roleDTO)
        {
            try
            {
                RoleRepository _rolerepository = new RoleRepository();
                _rolerepository = new RoleRepository();
                Role roleobj = new Role();
                roleobj.RoleId = Convert.ToInt16(roleDTO.RoleId);
                roleobj.RoleName = roleDTO.RoleName;
                roleobj.IsActive = roleDTO.IsActive;
                roleobj.IsDeleted = roleDTO.IsDeleted;
                roleobj.CreatedDate = roleDTO.CreatedDate;

                return _rolerepository.CreateRole(roleobj);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public void UpdateRole(RoleDTO record)
        {
            try
            {
                RoleRepository _rolerepository = new RoleRepository();
                _rolerepository.UpdateRole(record);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public List<Role> GetRoleOption()
        {
            _rolerepository = new RoleRepository();
            return _rolerepository.GetRoleOption();
        }

        
    }
}
