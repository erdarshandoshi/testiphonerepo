﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace MVCDemoApp.Models
{
    public class RoleModel
    {
        public RoleModel()
        {
            this.CreatedDate = DateTime.Now;
            this.RoleId = RoleId;
        }

        public int RoleId { get; set; }
        
        [Required]
        public string RoleName { get; set; }
        [Required]
        public bool IsActive { get; set; }

        [Required]
        public bool IsDeleted { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime CreatedDate { get; set; }
    }
}