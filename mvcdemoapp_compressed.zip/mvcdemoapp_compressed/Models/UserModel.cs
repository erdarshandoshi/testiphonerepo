﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace MVCDemoApp.Models
{
    public class UserModel
    {

        public UserModel()
        {
            this.CreatedDate = DateTime.Now;
            this.ModifiedDate = DateTime.Now;
        }

        //public long? UserId { get; set; }

        public long UserId { get; set; }


        [Required(ErrorMessage = "Please Enter User Name ")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Please enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please enter First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter First Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter Location")]
        public string Location { get; set; }

        [Required(ErrorMessage = "Please enter EmailId")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"\b[a-zA-Z0-9._%\-+']+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,4}\b", ErrorMessage = "Email Address is invalid.")]
        public string EmailId { get; set; }

        [DisplayName("Active Status")]
        public bool IsActive { get; set; }
        [DisplayName("Delete Status")]
        public bool IsDeleted { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        
        
        public short CompanyId { get; set; }

        [Required(ErrorMessage="Required")]
        public short RoleId { get; set; }

        [Required(ErrorMessage = "Please enter Company Name")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Please enter Role Name")]
        public string RoleName { get; set; }

        
    }
}