﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVCDemoApp.Models
{
    public class LoginModel
    {
        public long UserId { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"\b[a-zA-Z0-9._%\-+']+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,4}\b", ErrorMessage = "Email Address is invalid.")]
        public string EmailAddress { get; set; } 

        [Required(ErrorMessage = "password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}