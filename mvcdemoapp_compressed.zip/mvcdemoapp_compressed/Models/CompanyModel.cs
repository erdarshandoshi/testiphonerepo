﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MVCDemoApp.Models
{
    public class CompanyModel
    {
        //public Int16 CompanyId { get; set; }
        public short CompanyId { get; set; }
        [Required(ErrorMessage = "Please Enter Company Name ")]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Please Enter Physical Address  ")]
        public string PhysicalAddress { get; set; }

        [Required(ErrorMessage = "Please Enter Billing Address  ")]
        public string BillingAddress { get; set; }

        [DisplayName("Customer Status")]
        public bool IsCustomer { get; set; }

        [DisplayName("Active Status")]
        public bool IsActive { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public CompanyModel()
        {
            CreatedDate = DateTime.Now;
            ModifiedDate = DateTime.Now;
        }
    }

}