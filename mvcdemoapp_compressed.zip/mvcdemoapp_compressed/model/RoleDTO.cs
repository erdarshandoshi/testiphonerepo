﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCDemo.Model
{
    public class RoleDTO
    {
        public RoleDTO()
        {
            this.CreatedDate = DateTime.Now;
            this.RoleId = RoleId;
        }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
