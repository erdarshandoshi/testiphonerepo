﻿using MVCDemo.BAL;
using MVCDemo.Model;
using MVCDemo.Repository;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemoApp.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        private UserRepository _userRepository;
        public UserController()
        {
            _userRepository = new UserRepository();
        }

        /// <summary>
        /// Use for listing records
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            int totalrecord = 0;
            int recordperpage = 5;
            int startindex = 0;
            int page = 1;
            List<UserDTO> userlst = _userRepository.getUserList(ref totalrecord, recordperpage, startindex, page);
            // return View(userlst);
            List<UserModel> lstmodel = new List<UserModel>();
            foreach (var item in userlst)
            {
                UserModel usermodel = new UserModel();
                //usermodel.CompanyId = item.CompanyId;
                //usermodel.RoleId = item.RoleId;
                usermodel.CompanyName = item.CompanyName;
                usermodel.RoleName = item.RoleName;
                usermodel.UserName = item.UserName;
                usermodel.IsActive = item.IsActive;
                usermodel.IsDeleted = item.IsDeleted;
                usermodel.Location = item.Location;
                usermodel.EmailId = item.EmailId;
                usermodel.FirstName = item.FirstName;
                usermodel.LastName = item.LastName;
                usermodel.UserId = item.UserId;
                //usermodel.UserId = item.UserId.HasValue ? item.UserId.Value : 0;
                lstmodel.Add(usermodel);
            }
            return View("User", lstmodel);
            //return View(userlst.AsEnumerable(),"User");
        }

        [HttpGet]
        public ActionResult CreateUser()
        {
            RoleBAL objroleBAL = new RoleBAL();
            //IEnumerable<SelectListItem> roleList = objroleBAL.GetRoleOption().ToList().Select(x => new SelectListItem { Text = x.RoleName.ToString(), Value = x.RoleId.ToString() });
            IEnumerable<SelectListItem> roleList = objroleBAL.GetRoleOption().ToList().Select(x => new SelectListItem { Text = x.RoleName.ToString(), Value = x.RoleId.ToString() });
            ViewBag.RoleList = roleList;

            CompanyRepository _companyRepository = new CompanyRepository();
            IEnumerable<SelectListItem> companylist = _companyRepository.GetCompanyOption().ToList().Select(x => new SelectListItem { Text = x.CompanyName.ToString(), Value = x.CompanyId.ToString() });
            ViewBag.CompanyList = companylist;
            return View();
        }

        [HttpPost]
        public ActionResult CreateUpdateUser(UserModel usermodel)
        {
            RoleBAL objroleBAL = new RoleBAL();
            CompanyRepository _companyRepository = new CompanyRepository();
            UserDTO userDTO = new UserDTO();
            userDTO.UserId = usermodel.UserId;
            userDTO.UserName = usermodel.UserName;
            userDTO.FirstName = usermodel.FirstName;
            userDTO.LastName = usermodel.LastName;
            userDTO.EmailId = usermodel.EmailId;
            userDTO.Password = usermodel.Password;
            userDTO.Location = usermodel.Location;
            userDTO.IsActive = usermodel.IsActive;
            userDTO.IsDeleted = usermodel.IsDeleted;
            userDTO.CompanyId = usermodel.CompanyId;
            userDTO.RoleId = usermodel.RoleId;
            userDTO.CreatedDate = usermodel.CreatedDate;

            if (usermodel.UserId == 0)
            {
                int adduser = _userRepository.CreateUser(userDTO);
            }
            else
            {
                //bool updateuser = _userRepository.UpdateUser(userDTO);
                 _userRepository.UpdateUser(userDTO);
            }
            return RedirectToAction("Index", "User");
        }

        [HttpGet]
        public ActionResult EditUser(int id)
        {
            RoleBAL objroleBAL = new RoleBAL();
            IEnumerable<SelectListItem> roleList = objroleBAL.GetRoleOption().ToList().Select(x => new SelectListItem { Text = x.RoleName.ToString(), Value = x.RoleId.ToString() });
            ViewBag.RoleList = roleList;

            CompanyRepository _companyRepository = new CompanyRepository();
            IEnumerable<SelectListItem> companylist = _companyRepository.GetCompanyOption().ToList().Select(x => new SelectListItem { Text = x.CompanyName.ToString(), Value = x.CompanyId.ToString() });
            ViewBag.CompanyList = companylist;

            User user = _userRepository.getUserById(id);
            UserModel usermodel = new UserModel();
            usermodel.UserId = user.UserId;
            usermodel.UserName = user.UserName;
            usermodel.FirstName = user.FirstName;
            usermodel.LastName = user.LastName;
            usermodel.EmailId = user.EmailId;
            usermodel.Password = user.Password;
            usermodel.Location = user.Location;
            usermodel.IsActive = user.IsActive;
            usermodel.IsDeleted = user.IsDeleted;
            usermodel.CompanyId = user.CompanyId;
            usermodel.RoleId = user.RoleId;
            usermodel.CreatedDate = user.CreatedDate;
            return View("EditUser", usermodel);
        }

        public ActionResult DeleteUser(int id)
        {
            _userRepository.DeleteUser(id);
            return RedirectToAction("Index", "User");
        }

    }
}
