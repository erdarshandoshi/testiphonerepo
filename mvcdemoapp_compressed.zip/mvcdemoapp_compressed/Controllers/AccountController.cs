﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using MVCDemo.Model;
using MVCDemo.BAL;
using MVCDemoApp.Models;

namespace MVCDemoApp.Controllers
{
    public class AccountController : Controller
    {

        #region Fields
        UserBAL objuserBAL = new UserBAL();
        #endregion
        //
        // GET: /Account/

        public ActionResult Login()
        {
            return View();
        }

        //[AcceptVerbs(HttpVerbs.Post)]
        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            LoginModel model = new LoginModel();
            model.EmailAddress = collection["EmailAddress"];
            model.Password = collection["Password"];



            User userentity = objuserBAL.ValidateUser(model.EmailAddress, model.Password);
            Session["LoggedUser"] = userentity;
            if (Session["LoggedUser"] != null)
            {
                if (userentity.Role.RoleName.Trim().ToLower() == "admin")
                {
                    return RedirectToAction("Index", "Home");
                    
                }
                else
                {
                    return RedirectToAction("Login");
                    //ViewBag.errormessage("you have enter wrong email id or password ");
                    //TempData["error"] = "rtwtrw";
                    //ModelState.AddModelError("error.error", "sghjgfjhf");
                }

            }
            else
            {
                return RedirectToAction("Login");
                ViewBag.errormessage("you have enter wrong email id or password ");
                //TempData["error"] = "rtwtrw";
                //ModelState.AddModelError("error.error", "sghjgfjhf");
            }


           // User userentity = objuserBAL.getUser(model.EmailAddress, model.Password);

            //bool result = objuserBAL.ValidateUser(model.EmailAddress, model.Password);
            //if (result == true)
            //{
                //if (userentity.Role.RoleName.Trim().ToLower() == "admin")
                //if(userentity.EmailId == model.EmailAddress && userentity.Password == model.Password)
                //{
                //    return RedirectToAction("Index", "Home");
                //}
                //else
                //{
                //    ModelState.AddModelError("EmailAddress", "email address is incorrect");
                //    return RedirectToAction("Login");
                //}
           // }
            //else
            //{
            //    ModelState.AddModelError("EmailAddress", "Incorrect Email");
            //    return RedirectToAction("Login");
            //}
            //return View();
        }
    }






}
//}
