﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCDemo.Repository;
using MVCDemoApp.Models;
using MVCDemo.Model;

namespace MVCDemoApp.Controllers
{
    public class CompanyController : Controller
    {

        private CompanyRepository _companyRepository;

        public CompanyController()
        {
            _companyRepository = new CompanyRepository();
        }

        //
        // GET: /Company/

        public ActionResult Index()
        {
            return View("Company");
        }

        [HttpPost]
        public JsonResult CompanyList(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            int totalrecord = 0;
            var Options = _companyRepository.CompanyList(ref totalrecord);
            #region Paging
            if (jtPageSize > 0)
            {
                Options = Options.Skip(jtStartIndex).Take(jtPageSize).ToList();
            }
            else
            {
                Options = Options.ToList();
            }
            #endregion

            #region sorting
            if (jtSorting == "CompanyName ASC")
            {

                Options = Options.OrderBy(p => p.CompanyName).ToList();
            }
            else if (jtSorting == "CompanyName DESC")
            {
                Options = Options.OrderByDescending(p => p.CompanyName).ToList();
            }
            else if (jtSorting == "Physical Adress ASC ")
            {
                Options = Options.OrderBy(P => P.PhysicalAddress).ToList();
            }
            else if (jtSorting == "Physical Adress DESC")
            {
                Options = Options.OrderByDescending(P => P.PhysicalAddress).ToList();
            }
            else if (jtSorting == "BillingAdress ASC")
            {
                Options = Options.OrderBy(p => p.BillingAddress).ToList();
            }
            else if (jtSorting == "BillingAdress DESC")
            {
                Options = Options.OrderByDescending(p => p.BillingAddress).ToList();
            }
            else if (jtSorting == "IsCustomer ASC")
            {
                Options = Options.OrderBy(p => p.IsCustomer).ToList();
            }
            else if (jtSorting == "IsCustomer DESC ")
            {
                Options = Options.OrderByDescending(p => p.IsCustomer).ToList();
            }
            else if (jtSorting == "IsActive ASC")
            {
                Options = Options.OrderBy(p => p.IsActive).ToList();
            }
            else if (jtSorting == "IsActive DESC")
            {
                Options = Options.OrderByDescending(p => p.IsActive).ToList();
            }
            else if (jtSorting == "CreatedDate ASC")
            {
                Options = Options.OrderBy(p => p.CreatedDate).ToList();
            }
            else if (jtSorting == "CreatedDate DESC")
            {
                Options = Options.OrderByDescending(p => p.CreatedDate).ToList();
            }
            else if (jtSorting == "ModifiedDate ASC")
            {
                Options = Options.OrderBy(p => p.ModifiedDate).ToList();
            }
            else if (jtSorting == "ModifiedDate DESC")
            {
                Options = Options.OrderByDescending(p => p.ModifiedDate).ToList();
            }

            #endregion


            return Json(new { Result = "OK", Records = Options, TotalRecordCount = totalrecord });
        }

        [HttpPost]
        public JsonResult Delete(int CompanyId)
        {
            _companyRepository.Delete(CompanyId);
            return Json(new { Result = "OK" });
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateCompany(CompanyModel model)
        {
            Company company = new Company();
            company.CompanyId = model.CompanyId;
            company.CompanyName = model.CompanyName;
            company.IsActive = model.IsActive;
            company.IsCustomer = model.IsCustomer;
            company.PhysicalAddress = model.PhysicalAddress;
            company.BillingAddress = model.BillingAddress;
            company.CreatedDate = model.CreatedDate;
            company.ModifiedDate = model.ModifiedDate;
            if (model.CompanyId == 0)
            {
                _companyRepository.CreateCompany(company);
            }
            else
            {
                _companyRepository.UpdateCompany(company);
            }
            return RedirectToAction("Index", "Company");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            Company company = _companyRepository.getById(id);
            CompanyModel model = new CompanyModel();
            model.CompanyId = company.CompanyId;
            model.CompanyName = company.CompanyName;
            model.IsActive = company.IsActive;
            model.IsCustomer = company.IsCustomer;
            model.PhysicalAddress = company.PhysicalAddress;
            model.BillingAddress = company.BillingAddress;
            model.CreatedDate = company.CreatedDate;
            company.ModifiedDate = model.ModifiedDate;
            return View(model);
            
        }

        //[HttpPost]
        //public ActionResult Edit(CompanyModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        Company company = new Company();
        //        company.CompanyId = model.CompanyId;
        //        company.CompanyName = model.CompanyName;
        //        company.IsActive = model.IsActive;
        //        company.PhysicalAddress = model.PhysicalAddress;
        //        company.BillingAddress = model.BillingAddress;
        //        company.CreatedDate = model.CreatedDate;
        //        _companyRepository.UpdateCompany(company);
        //        return RedirectToAction("Index", "Company");
        //    }
        //    return View(model);
        //}



    }
}
