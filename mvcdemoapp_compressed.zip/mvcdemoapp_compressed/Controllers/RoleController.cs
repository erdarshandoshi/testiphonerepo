﻿using MVCDemo.BAL;
using MVCDemo.Model;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace MVCDemoApp.Controllers
{
    public class RoleController : Controller
    {
        //
        // GET: /Role/

        public ActionResult Index()
        {
            return View("Role");

        }

        #region Fields
        RoleBAL objRoleBAL = new RoleBAL();
        #endregion


        [HttpPost]
        public JsonResult RoleList(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            try
            {
                int totalRecords = 0;
                int recordcount = 0;
                List<RoleModel> lstrolemodel = new List<RoleModel>();
                //List<MVCDemo.Model.RoleDTO> lstrolemodel = new List<MVCDemo.Model.RoleDTO>();

                List<Role> rolelist = objRoleBAL.RoleList(ref totalRecords);
                recordcount = rolelist.Count();
                foreach (var item in rolelist)
                {
                   // MVCDemo.Model.RoleDTO rolemodel = new MVCDemo.Model.RoleDTO();
                    RoleModel rolemodel = new RoleModel();
                    rolemodel.RoleId = item.RoleId;
                    rolemodel.RoleName = item.RoleName;
                    rolemodel.IsActive = item.IsActive;
                    rolemodel.IsDeleted = item.IsDeleted;
                    rolemodel.CreatedDate = item.CreatedDate;
                    lstrolemodel.Add(rolemodel);
                }

                //** using entity **//
               //List<Role> lstrole = new List<Role>();
               // lstrole = objRoleBAL.RoleList(ref totalRecords);
                //var rolelst = objRoleBAL.RoleList(ref totalRecords);
                //recordcount = rolelst.Count();


                //Role newObj = new Role(); 
                //foreach (var item in lstrole)
                //{
                //    RoleModel rolemodel = new RoleModel();
                //    rolemodel.RoleId = item.RoleId;
                //    rolemodel.RoleName = item.RoleName;
                //    rolemodel.IsActive = item.IsActive;
                //    rolemodel.IsDeleted = item.IsDeleted;
                //    rolemodel.CreatedDate = item.CreatedDate;
                //    //lstrole.Add(rolemodel);
                //}
                //objRoleBAL.RoleList(totalRecords);

                #region Paging
                if (jtPageSize > 0)
                {
                    lstrolemodel = lstrolemodel.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    lstrolemodel = lstrolemodel.ToList();
                }
                #endregion

                #region Sorting
                if (jtSorting == "RoleName ASC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.RoleName).ToList();
                }
                else if (jtSorting == "RoleName DESC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.RoleName).ToList();
                }
                else if (jtSorting == "IsActive ASC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.IsActive).ToList();
                }
                else if (jtSorting == "IsActive DESC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.IsActive).ToList();
                }
                else if (jtSorting == "IsDelete ASC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.IsDeleted).ToList();
                }
                else if (jtSorting == "IsDelete DESC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.IsDeleted).ToList();
                }
                else if (jtSorting == "Created Date ASC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "Created Date DESC")
                {
                    lstrolemodel = lstrolemodel.OrderBy(p => p.CreatedDate).ToList();
                }
                #endregion




                return Json(new { Result = "OK", Records = lstrolemodel, TotalRecordCount = totalRecords });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult DeleteRole(int RoleId)
        {
            try
            {
                objRoleBAL.DeleteRole(RoleId);
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {

                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult CreateRole(RoleDTO record)
        {
            try
            {
                RoleBAL objRoleBAL = new RoleBAL();
                //objRoleBAL.CreateRole(role);
                //return Json(new { Result = "OK" });
                int addedrole = objRoleBAL.CreateRole(record);
                return Json(new { Result = "OK", Record = addedrole });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }

        }
        [HttpPost]
        public JsonResult UpdateRole(RoleDTO record)
        {
            try
            {
                RoleBAL objRoleBAL = new RoleBAL();
                objRoleBAL.UpdateRole(record);
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }


    }
}

