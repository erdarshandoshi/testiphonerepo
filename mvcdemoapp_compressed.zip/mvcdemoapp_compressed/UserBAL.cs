﻿using MVCDemo.Model;
using MVCDemo.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCDemo.BAL
{
    public class UserBAL
    {
        #region Fields
        private UserRepository m_dao = null;
        #endregion
        public UserBAL()
        {
            m_dao = new UserRepository();
        }
        public User ValidateUser(string emailid, string password)
        {

            return m_dao.ValidateUser(emailid, password);

        }

        //public bool ValidateUser(string emailid, string password)
        //{
        //    bool result = m_dao.ValidateUser(emailid, password);
        //    return result;

        //}



        //public User getUser(string email,string pwd)
        //{
        //    return m_dao.getUser(email, pwd);
        //}
    }
}
