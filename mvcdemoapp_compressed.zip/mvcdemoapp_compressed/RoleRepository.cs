﻿using MVCDemo.Model;
using MVCDemo.Repository.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCDemo.Repository
{
    public class RoleRepository : Common
    {
        public void DeleteRole(int id)
        {
            try
            {
                var role = DBContext.Roles.Where(x => x.RoleId == id).FirstOrDefault();
                DBContext.Roles.Remove(role);
                DBContext.SaveChanges();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public int CreateRole(Role roleobj)
        {
            try
            {
                var addedRole = DBContext.Roles.Add(roleobj);
                return DBContext.SaveChanges();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public List<Role> RoleList(ref int totalRecords)
        {
            try
            {
                var foundrole = DBContext.Roles.ToList();
                totalRecords = foundrole.Count();
                return foundrole;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public void UpdateRole(RoleDTO record)
        {
            //var foundobj = DBContext.Roles.FirstOrDefault(u =>u.RoleId.Equals(record.RoleId));
            try
            {
                var foundobj = DBContext.Roles.FirstOrDefault(u => u.RoleId == record.RoleId);
                if (foundobj != null)
                {
                    DBContext.Roles.Attach(foundobj);
                    foundobj.RoleId = Convert.ToInt16(record.RoleId);
                    foundobj.RoleName = record.RoleName;
                    foundobj.IsActive = record.IsActive;
                    foundobj.IsDeleted = record.IsDeleted;
                    foundobj.CreatedDate = record.CreatedDate;
                    DBContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            
        }

        public List<Role> GetRoleOption()
        {
            return DBContext.Roles.Where(r => r.IsActive && !r.IsDeleted).ToList();
        }
    }
}
