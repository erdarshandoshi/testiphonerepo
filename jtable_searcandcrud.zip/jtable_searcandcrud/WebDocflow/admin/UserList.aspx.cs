﻿using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using WebDocflow.BAL;
using WebDocflow.Models;
using System.IO;


namespace WebDocflow.admin
{
    public partial class UserList : System.Web.UI.Page
    {
        #region fields
        UserBAL objuserBAL = new UserBAL();
        #endregion

        #region Listing
        [WebMethod(EnableSession = true)]
        public static object UserListing(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = "UserName ASC", string SearchOption = null, string SearchValue = null)
        {
            try
            {
                int totalrecord = 0;

                UserBAL objuserBAL = new UserBAL();
                int recordscount = 0;
                #region Filter
                System.Linq.Expressions.Expression<Func<User, bool>> whereClause = WhereClauseBuilder.True<Models.User>();
                if (!string.IsNullOrEmpty(SearchValue))
                {
                    switch (SearchOption)
                    {
                        case "UserName":
                            whereClause = whereClause.And<Models.User>(p => p.UserName.Trim().ToLower().Contains(SearchValue.Trim().ToLower().Replace("*", string.Empty)));
                            break;
                        case "Location":
                            whereClause = whereClause.And<Models.User>(p => p.Location.Trim().ToLower().Contains(SearchValue.Trim().ToLower().Replace("*", string.Empty)));
                            break;
                    }
                }
                #endregion
                System.Collections.Generic.List<UserDTO> userDTOlst = objuserBAL.GetAllUser(ref totalrecord, whereClause);
                recordscount = userDTOlst.Count();
                #region sorting
                if (jtSorting == "UserName  ASC")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.UserName).ToList();
                }
                else if (jtSorting == "UserName  DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.UserName).ToList();
                }
                else if (jtSorting == "FirstName ASC")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.FirstName).ToList();
                }
                else if (jtSorting == "FirstName DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.FirstName).ToList();
                }
                else if (jtSorting == "LastName ASC ")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.LastName).ToList();
                }
                else if (jtSorting == "LastName DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.LastName).ToList();
                }
                else if (jtSorting == "Location ASC")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.Location).ToList();
                }
                else if (jtSorting == "Location DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.Location).ToList();

                }

                else if (jtSorting == "IsActive Status ASC ")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.IsActive).ToList();
                }

                else if (jtSorting == "IsActive Status DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.IsActive).ToList();

                }

                else if (jtSorting == "IsDeleted Status ASC")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.IsDeleted).ToList();
                }
                else if (jtSorting == "IsDeleted Status DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.IsDeleted).ToList();
                }
                else if (jtSorting == "CreatedDate Asc")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "CreatedDate DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "ModifiedDate Asc")
                {
                    userDTOlst = userDTOlst.OrderBy(p => p.ModifiedDate).ToList();
                }
                else if (jtSorting == "ModifiedDate DESC")
                {
                    userDTOlst = userDTOlst.OrderByDescending(p => p.ModifiedDate).ToList();
                }
                #endregion

                #region paging
                if (jtPageSize > 0)
                {
                    userDTOlst = userDTOlst.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    userDTOlst = userDTOlst.ToList();
                }
                #endregion


                return new { Result = "OK", Records = userDTOlst, TotalRecordCount = totalrecord };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }


        }
        [WebMethod(EnableSession = true)]
        public static object CreateUser(UserDTO record)
        {
            try
            {
                if (record == null)
                {
                    throw new Exception("Recieved user record is null...");
                }
                UserBAL userobjBAL = new UserBAL();
                record.CreatedDate = DateTime.Now;
                int addeduser = userobjBAL.CreateUser(record);
                return new { Result = "OK", Record = addeduser };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object UpdateUser(UserDTO record)
        {
            try
            {
                UserBAL objuserBAL = new UserBAL();
                objuserBAL.UpdateUser(record);

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }
        }
        [WebMethod(EnableSession = true)]
        public static object DeleteUser(int UserId)
        {
            try
            {
                UserBAL objuserBAL = new UserBAL();
                objuserBAL.DeleteUserById(UserId);
                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object GetRoleOptions()
        {
            try
            {
                RoleBAL roleobjBAL = new RoleBAL();
                var roleoption = roleobjBAL.GetRoleOptions().Select(x => new { DisplayText = x.RoleName, Value = x.RoleId });
                return new { Result = "OK", Options = roleoption };
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object GetCompanyOptions()
        {
            try
            {
                CompanyBAL companyobjBAL = new CompanyBAL();
                var lstcompny = companyobjBAL.GetCompanyOptions().Select(x => new { DisplayText = x.CompanyName, Value = x.CompanyId });
                return new { Result = "OK", Options = lstcompny };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        #endregion
    }

}