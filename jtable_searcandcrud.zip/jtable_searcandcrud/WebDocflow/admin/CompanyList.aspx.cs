﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebDocflow.BAL;
using WebDocflow.Models;
using System.IO;

namespace WebDocflow.admin
{
    public partial class CompanyList : System.Web.UI.Page
    {
        #region Fields
        private CompanyBAL objcompanyBAL = new CompanyBAL();
        #endregion

        #region Listing
        [WebMethod(EnableSession = true)]
        public static object CompanyListing(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = "CompanyName ASC", string SearchOption = null, string SearchValue = null)
        //public static object CompanyListing(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = "CompanyName ASC")
        {
            try
            {
                int totalrecord = 0;
                CompanyBAL objcompanyBAl = new CompanyBAL();
                int companyCount = 0;
                List<CompanyDTO> listcompany = new List<CompanyDTO>();

                #region Filter
                System.Linq.Expressions.Expression<Func<Company, bool>> whereClause = WhereClauseBuilder.True<Models.Company>();
                   
                if (!string.IsNullOrEmpty(SearchValue))
                {
                    switch (SearchOption)
                    {
                        case "CompanyName":
                            whereClause = whereClause.And<Models.Company>(p => p.CompanyName.Trim().ToLower().Contains(SearchValue.Trim().ToLower().Replace("*", string.Empty)));
                            break;
                        case "PhysicalAddress":
                            whereClause = whereClause.And<Models.Company>(p => p.PhysicalAddress.Trim().ToLower().Contains(SearchValue.Trim().ToLower().Replace("*", string.Empty)));
                            break;
                        case "BillingAdress":
                            whereClause = whereClause.And<Models.Company>(p => p.BillingAddress.Trim().ToLower().Contains(SearchValue.Trim().ToLower().Replace("*", string.Empty)));
                            break;
                    }
                }
                #endregion

                IEnumerable<Company> newlist = objcompanyBAl.GetALLCompnyList(ref totalrecord, whereClause);
                companyCount = newlist.Count();
                foreach (var lst in newlist)
                {
                    CompanyDTO objcompanyDTO = new CompanyDTO();
                    objcompanyDTO.companyId = lst.CompanyId;
                    objcompanyDTO.CompanyName = lst.CompanyName;
                    objcompanyDTO.PhysicalAddress = lst.PhysicalAddress;
                    objcompanyDTO.BillingAdress = lst.BillingAddress;
                    objcompanyDTO.IsCustomer = lst.IsCustomer;
                    objcompanyDTO.IsActive = lst.IsActive;
                    objcompanyDTO.CreatedDate = lst.CreatedDate;

                    objcompanyDTO.ModifiedDate = Convert.ToDateTime(lst.ModifiedDate);
                    //objcompanyDTO.ModifiedDate = lst.ModifiedDate;
                    listcompany.Add(objcompanyDTO);
                }
                #region sorting
                if (jtSorting == "CompanyName ASC")
                {

                    listcompany = listcompany.OrderBy(p => p.CompanyName).ToList();
                }
                else if (jtSorting == "CompanyName DESC")
                {
                    listcompany = listcompany.OrderByDescending(p => p.CompanyName).ToList();
                }
                else if (jtSorting == "Physical Adress ASC ")
                {
                    listcompany = listcompany.OrderBy(P => P.PhysicalAddress).ToList();
                }
                else if (jtSorting == "Physical Adress DESC")
                {
                    listcompany = listcompany.OrderByDescending(P => P.PhysicalAddress).ToList();
                }
                else if (jtSorting == "BillingAdress ASC")
                {
                    listcompany = listcompany.OrderBy(p => p.BillingAdress).ToList();
                }
                else if (jtSorting == "BillingAdress DESC")
                {
                    listcompany = listcompany.OrderByDescending(p => p.BillingAdress).ToList();
                }
                else if (jtSorting == "IsCustomer ASC")
                {
                    listcompany = listcompany.OrderBy(p => p.IsCustomer).ToList();
                }
                else if (jtSorting == "IsCustomer DESC ")
                {
                    listcompany = listcompany.OrderByDescending(p => p.IsCustomer).ToList();
                }
                else if (jtSorting == "IsActive ASC")
                {
                    listcompany = listcompany.OrderBy(p => p.IsActive).ToList();
                }
                else if (jtSorting == "IsActive DESC")
                {
                    listcompany = listcompany.OrderByDescending(p => p.IsActive).ToList();
                }
                else if (jtSorting == "CreatedDate ASC")
                {
                    listcompany = listcompany.OrderBy(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "CreatedDate DESC")
                {
                    listcompany = listcompany.OrderByDescending(p => p.CreatedDate).ToList();
                }
                else if (jtSorting == "ModifiedDate ASC")
                {
                    listcompany = listcompany.OrderBy(p => p.ModifiedDate).ToList();
                }
                else if (jtSorting == "ModifiedDate DESC")
                {
                    listcompany = listcompany.OrderByDescending(p => p.ModifiedDate).ToList();
                }

                #region Paging
                if (jtStartIndex > 0)
                {
                    listcompany = listcompany.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    listcompany = listcompany.ToList();
                }
                #endregion
                #endregion
                return new { Result = "OK", Records = listcompany, TotalRecordCount = totalrecord };
                //return listcompany;
            }

            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object CompanyDeleteById(int companyId)
        {
            try
            {
                CompanyBAL companyobjBAL = new CompanyBAL();
                companyobjBAL.CompanyDeleteById(companyId);
                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object CreateCompany(CompanyDTO record)
        {
            try
            {
                CompanyBAL companyobjBAL = new CompanyBAL();
                //int companyrecord = companyobjBAL.CreateCompany(record);
                int companyrecord = companyobjBAL.CreateCompanyById(record);
                return new { Result = "OK", Record = record };
            }
            catch (Exception ex)
            {
                return new { Result = "Error", Message = ex.Message };
            }
        }

        [WebMethod(EnableSession = true)]
        public static object UpdateCompany(CompanyDTO record)
        {
            try
            {
                CompanyBAL companyobjBAL = new CompanyBAL();
                companyobjBAL.UpdateCompany(record);
                return new { Result = "OK" };
            }
            catch (Exception ex)
            {

                return new { Result = "Error", Message = ex.Message };
            }
        }
        #endregion

        #region Private Methods
       
       
        #endregion

    }
}