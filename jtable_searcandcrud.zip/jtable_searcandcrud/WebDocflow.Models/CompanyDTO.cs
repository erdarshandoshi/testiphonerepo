﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDocflow.Models
{
    public class CompanyDTO
    {
        public Int16 companyId { get; set; }
        public string CompanyName { get; set; }
        public string PhysicalAddress { get; set; }
        public string BillingAdress { get; set; }
        public bool IsCustomer{ get; set; }
        public bool  IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public CompanyDTO()
        {
            CreatedDate = DateTime.Now;
            ModifiedDate = DateTime.Now;
        }
        
    }
}
