﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Models;
using WebDocflow.Repository;

namespace WebDocflow.BAL
{
    public class UserBAL
    {
        #region Fields
        private UserRepository m_dao = null;
        #endregion

        #region Constructor
        public UserBAL()
        {
            m_dao = new UserRepository();
        }
        #endregion

        public User ValidateUser(string userName, string password)
        {
            try
            {
                return m_dao.ValidateUser(userName, password);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<UserDTO> GetAllUser(ref int totalrecord, System.Linq.Expressions.Expression<Func<User, bool>> whereClause)
        {
            return m_dao.GetAllUser(ref totalrecord, whereClause);
        }

        public void DeleteUser(int UserId)
        {
            try
            {
                m_dao.DeleteUser(UserId);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        public int CreateUser(UserDTO record)
        {
            try
            {
                int addeduser;
                addeduser = m_dao.CreateUser(record);
                return addeduser;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }







        public bool UpdateUser(UserDTO record)
        {
            try
            {
                m_dao = new UserRepository();
                return m_dao.UpdateUserById(record);
                //return b;
            }
            catch (Exception ex)
            {

                throw ex;
            }

            //throw new NotImplementedException();
        }


        public void DeleteUserById(int userId)
        {

            m_dao.DeleteUserById(userId);
        }
    }
}
