﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Repository;
using WebDocflow.Models;


namespace WebDocflow.BAL
{
    public class RoleBAL
    {
        #region Private Members
        private RoleRepository _roleRepository;
        #endregion

        #region Constructor

        #endregion

        public IEnumerable<Role> GetAllRoles(ref int totalRecords)
        {
            try
            {
                _roleRepository = new RoleRepository();

                return _roleRepository.GetAllRoles(ref totalRecords);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void DeleteRole(int RoleId)
        {
            try
            {
                _roleRepository = new RoleRepository();
                _roleRepository.DeleteRoleById(RoleId);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            // throw new NotImplementedException();
        }


        public int CreateRole(RoleDTO roleData)
        {
            try
            {
                _roleRepository = new RoleRepository();
                Role roleobj = new Role();
                roleobj.RoleId = Convert.ToInt16(roleData.RoleId);
                roleobj.RoleName = roleData.RoleName;
                roleobj.IsActive = roleData.IsActive;
                roleobj.IsDeleted = roleData.IsDelete;
                roleobj.CreatedDate = roleData.CreatedDate;
                return _roleRepository.CreateRole(roleobj);
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public bool UpdateRole(RoleDTO roleDTOobj)
      
        {
            try
            {
                _roleRepository = new RoleRepository();
                return _roleRepository.UpdateRoleById(roleDTOobj);
               
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public List<Role> GetRoleOptions()
        {
            try
            {
               
                _roleRepository = new RoleRepository();
                return _roleRepository.GetRoleOptions();
               
            }
            catch (Exception)
            {

                throw;
            }

        }

    }
}
