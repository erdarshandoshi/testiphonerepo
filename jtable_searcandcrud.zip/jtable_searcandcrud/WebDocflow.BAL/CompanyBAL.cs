﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Models;
using WebDocflow.Repository;


namespace WebDocflow.BAL
{
    public class CompanyBAL
    {
        #region Private Members
        private CompanyRepository _companyrepository;
        #endregion

        //public IEnumerable<Company> GetALLCompnyList()//int ref companyCount)
        //{
        //        _companyrepository = new CompanyRepository();
        //        return _companyrepository.GetALLCompnyList();
        //   // throw new NotImplementedException();
        //}
        //public List<Company> GetALLCompnyList(ref int totalrecord)
        public IEnumerable<Company> GetALLCompnyList(ref int totalrecord, System.Linq.Expressions.Expression<Func<Company, bool>> whereClause)
        {
            try
            {
                _companyrepository = new CompanyRepository();
                return _companyrepository.GetALLCompnyList(ref totalrecord, whereClause);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void CompanyDeleteById(int CompanyId)
        {
            try
            {
                _companyrepository = new CompanyRepository();
                _companyrepository.DeleteCompanyById(CompanyId);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            //throw new NotImplementedException();
        }

        //public int CreateCompany(CompanyDTO companyDTO)
        //{
        //    try
        //    {
        //        _companyrepository = new CompanyRepository();
        //        //pass data from dto to table
        //        Company companyobj = new Company();
        //        companyobj.CompanyId = companyDTO.companyId;
        //        companyobj.CompanyName = companyDTO.CompanyName;
        //        companyobj.PhysicalAddress = companyDTO.PhysicalAddress;
        //        companyobj.BillingAddress = companyDTO.BillingAdress;
        //        companyobj.IsCustomer = companyDTO.IsCustomer;
        //        companyobj.IsActive = companyDTO.IsActive;
        //        companyobj.CreatedDate = companyDTO.CreatedDate;



        //        return _companyrepository.CreateCompany(companyobj);
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    //throw new NotImplementedException();
        //}

        public bool UpdateCompany(CompanyDTO compnyDTO)
        {
            try
            {
                _companyrepository = new CompanyRepository();
                return _companyrepository.UpdateCompany(compnyDTO);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            //throw new NotImplementedException();


        }

        public List<Company> GetCompanyOptions()
        {
            List<Company> lstcompany;
            _companyrepository = new CompanyRepository();
            lstcompany = _companyrepository.GetCompanyOption();
            return lstcompany;
        }



        public int CreateCompanyById(CompanyDTO record)
        {
            try
            {
                _companyrepository = new CompanyRepository();
                Company companyobj = new Company();
                companyobj.CompanyId = record.companyId;
                companyobj.CompanyId = record.companyId;
                companyobj.CompanyName = record.CompanyName;
                companyobj.PhysicalAddress = record.PhysicalAddress;
                companyobj.BillingAddress = record.BillingAdress;
                companyobj.IsCustomer = record.IsCustomer;
                companyobj.IsActive = record.IsActive;
                companyobj.CreatedDate = record.CreatedDate;
                int _affectedRows = _companyrepository.CreateCompany(companyobj);
                record.companyId = companyobj.CompanyId;
                return _affectedRows;

            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            //throw new NotImplementedException();
        }
    }
}
