﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Models;
namespace WebDocflow.Repository
{
    public class RoleRepository : Common
    {
        public object DeleteRole;


        public IEnumerable<WebDocflow.Models.Role> GetAllRoles(ref int totalRecords)
        {
            try
            {
                var foundRoles = DBContext.Roles.ToList();
                totalRecords = foundRoles.Count;
                return foundRoles;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public void DeleteRoleById(int RoleId)
        {

            try
            {
                var role = DBContext.Roles.Where(u => u.RoleId == RoleId).FirstOrDefault();
                DBContext.Roles.Remove(role);
                DBContext.SaveChanges();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            

        }

        public int CreateRole(Role rolerecord)
        {
            try
            {
                DBContext.Roles.Add(rolerecord);
                return DBContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }   
        public bool UpdateRoleById(RoleDTO roleDTOobj)
        {
            try
            {
                var foundObj = DBContext.Roles.FirstOrDefault(p => p.RoleId == roleDTOobj.RoleId);
                if (foundObj != null)
                {
                    DBContext.Roles.Attach(foundObj);
                    foundObj.RoleId = Convert.ToInt16(roleDTOobj.RoleId);
                    foundObj.RoleName = roleDTOobj.RoleName;
                    foundObj.IsActive = roleDTOobj.IsActive;
                    foundObj.IsDeleted = roleDTOobj.IsDelete;
                    foundObj.CreatedDate = roleDTOobj.CreatedDate;
                    DBContext.SaveChanges();
                }
                return true;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public List<Role> GetRoleOptions()
        {
            try
            {
             
                return DBContext.Roles.Where(p => p.IsActive && !p.IsDeleted).ToList();
             
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
