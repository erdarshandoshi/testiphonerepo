﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Models;

namespace WebDocflow.Repository
{
    public class UserRepository : Common
    {
        #region Fields

        #endregion

        #region Constructor
        public UserRepository()
        {
        }
        #endregion

        #region Methods
        public User ValidateUser(string userName, string password)
        {
            User obj = null;
            try
            {
                obj = this.DBContext.Users.FirstOrDefault(u => u.UserName.Trim().Equals(userName.Trim()) && u.Password.Trim() == password.Trim());

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return obj;
        }
        #endregion

        #region UDF

        public List<UserDTO> GetAllUser(ref int totalrecord, System.Linq.Expressions.Expression<Func<User, bool>> whereClause)
        {
            try
            {
                var res = from u in DBContext.Users.Where(whereClause.Compile())
                          join c in DBContext.Companies on u.CompanyId equals c.CompanyId
                          join r in DBContext.Roles on u.RoleId equals r.RoleId
                          select new UserDTO()
                          {
                              UserId = u.UserId,
                              RoleId = r.RoleId,
                              RoleName = r.RoleName,
                              CompanyId = c.CompanyId,
                              CompanyName = c.CompanyName,
                              UserName = u.UserName,
                              FirstName = u.FirstName,
                              LastName = u.LastName,
                              IsActive = u.IsActive,
                              IsDeleted = u.IsDeleted,
                              EmailId = u.EmailId,
                              Password = u.Password,
                              Location = u.Location,
                              CreatedDate = u.CreatedDate,

                          };
                totalrecord = res.Count();
                return res.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public void DeleteUser(int UserId)
        {
            try
            {
                var result = DBContext.Users.Where(u => u.UserId == UserId).FirstOrDefault();
                DBContext.Users.Remove(result);
                DBContext.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public int CreateUser(UserDTO userDTOobj)
        {
            try
            {
                User objuser = new User();
                objuser.UserName = userDTOobj.UserName;
                objuser.UserId = userDTOobj.UserId;
                objuser.RoleId = userDTOobj.RoleId;
                objuser.CompanyId = userDTOobj.CompanyId;
                objuser.FirstName = userDTOobj.FirstName;
                objuser.LastName = userDTOobj.LastName;
                objuser.Password = userDTOobj.Password;
                objuser.Location = userDTOobj.Location;
                objuser.EmailId = userDTOobj.EmailId;
                objuser.IsActive = userDTOobj.IsActive;
                objuser.IsDeleted = userDTOobj.IsDeleted;
                objuser.CreatedDate = userDTOobj.CreatedDate;
                DBContext.Users.Add(objuser);
                return DBContext.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        public bool UpdateUserById(UserDTO record)
        {
            try
            {
                var getid = DBContext.Users.FirstOrDefault(r => r.UserId == record.UserId);
                if (getid != null)
                {
                    DBContext.Users.Attach(getid);
                    getid.UserId = Convert.ToInt16(record.UserId);
                    getid.UserName = record.UserName;
                    getid.RoleId = record.RoleId;
                    getid.CompanyId = record.CompanyId;
                    getid.FirstName = record.FirstName;
                    getid.LastName = record.LastName;
                    getid.Password = record.Password;
                    getid.Location = record.Location;
                    getid.EmailId = record.EmailId;
                    getid.IsActive = record.IsActive;
                    getid.IsDeleted = record.IsDeleted;
                    //getid.ModifiedDate = record.ModifiedDate;
                    DBContext.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {

                throw;
            }

            // throw new NotImplementedException();
        }


        public void DeleteUserById(int userId)
        {
            try
            {
                var usr = DBContext.Users.Where(u => u.UserId == userId).FirstOrDefault();
                DBContext.Users.Remove(usr);
                DBContext.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion
    }
}


