﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDocflow.Models;

namespace WebDocflow.Repository
{
     public class CompanyRepository :Common
    {
         public IEnumerable<WebDocflow.Models.Company> GetALLCompnyList(ref int totalRecords, System.Linq.Expressions.Expression<Func<Company, bool>> whereClause)
         {
             try
             {
                 var foundcmpny = DBContext.Companies.Where(whereClause.Compile()).ToList();
                 totalRecords = foundcmpny.Count;
                 return foundcmpny;
             }
             catch (Exception ex)
             {
                 
                 throw ex;
             }
         }


         
         public void DeleteCompanyById(int CompanyId)
         {
             //DBContext.Companies.Where(U =>U.CompanyId == CompanyId)
             try
             {
                 var company = DBContext.Companies.Where(u => u.CompanyId == CompanyId).FirstOrDefault();
                 DBContext.Companies.Remove(company);
                 DBContext.SaveChanges();
             }
             catch (Exception ex)
             {
                 
                 throw ex;
             }
             //throw new NotImplementedException();
         }

         public int CreateCompany(Models.Company companyobj)
         {
             try
             {

                 DBContext.Companies.Add(companyobj);
                 return DBContext.SaveChanges();
             }
             catch (Exception ex)
             {
                 
                 throw ex;
             }
             //throw new NotImplementedException();
         }

         public bool UpdateCompany(Models.CompanyDTO compnyDTO)
         {
             try
             {
                 var obj = DBContext.Companies.FirstOrDefault(u => u.CompanyId == compnyDTO.companyId);
                 if (obj != null)
                 {
                     DBContext.Companies.Attach(obj);
                     obj.CompanyId = compnyDTO.companyId;
                     obj.CompanyName = compnyDTO.CompanyName;
                     obj.PhysicalAddress = compnyDTO.PhysicalAddress;
                     obj.BillingAddress = compnyDTO.BillingAdress;
                     obj.IsCustomer = compnyDTO.IsCustomer;
                     obj.IsActive = compnyDTO.IsActive;
                     obj.CreatedDate = compnyDTO.CreatedDate;
                     //obj.ModifiedDate = compnyDTO.ModifiedDate;
                     DBContext.SaveChanges();

                 }
                 return true;
             }
             catch (Exception ex)
             {
                 
                 throw ex;
             }
            // throw new NotImplementedException();
         }

         public List<Models.Company> GetCompanyOption()
         {
            List<Models.Company> lstcompany;
            lstcompany = DBContext.Companies.Where(c => c.IsActive && c.IsCustomer).ToList();
            return lstcompany;
             //throw new NotImplementedException();
         }
    }
}
