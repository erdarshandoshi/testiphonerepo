﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplicationEmployees.Model;
using WindowsFormsApplicationEmployees.BAL;
//using WindowsFormsApplicationEmployees.Employee;


namespace WindowsFormsApplicationEmployees
{
    public partial class EmployeeList : Form
    {
        #region Fields
        EmployeeBAL e_bal;
        EmployeeModel e_mdl;
        Employee obj;
      
        #endregion

        #region Constructor
        public EmployeeList()
        {
            InitializeComponent();
            dataGridView1.AutoGenerateColumns = false;
        }
        
        #endregion

        #region Properties
        #endregion

        #region Methods
        private void EmployeeList_Load(object sender, EventArgs e)
        {
            GetEmployees();
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            GetEmployees();
        }
        #region Add button
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Employee objEmployee = new Employee();
            objEmployee.MdiParent = this.MdiParent;
            objEmployee.Show();
        } 
        #endregion
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > -1 && e.RowIndex > -1)
            {
                if (dataGridView1.Columns[e.ColumnIndex].Name == dgvcEdit.Name)
                {
                    //code of edit
                    int _id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["dgvcId"].Value);
                    Employee objEmployeeEdit = new Employee(_id);
                    DialogResult dresult = objEmployeeEdit.ShowDialog();

                    objEmployeeEdit.Show();
                    if (dresult == System.Windows.Forms.DialogResult.OK)
                    {
                        MessageBox.Show("Record Updated...");
                        GetEmployees();
                        
                    }
                    else
                    {
                        if (dresult == System.Windows.Forms.DialogResult.Cancel)
                        {
                            //MessageBox.Show("cancel editing.....");
                            objEmployeeEdit.Close();
                        }
                    }

                }
                if (e.ColumnIndex > -1 && e.RowIndex > -1)
                {
                    if (dataGridView1.Columns[e.ColumnIndex].Name == dgvcDelete.Name)
                    {
                        int _id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["dgvcId"].Value);
                      
                        DialogResult res = MessageBox.Show("delete data?....", "delete mode", MessageBoxButtons.OKCancel);
                        if (res == System.Windows.Forms.DialogResult.OK)
                        {
                            DeleteEmp(_id);
                            GetEmployees();
                        }
                    }
                }
            }
        }

       
        #endregion

        #region Private UDF
        public void GetEmployees()
        {
            string name = txtsearch.Text.Trim();
            EmployeeBAL e_bal = new EmployeeBAL();
            List<EmployeeModel> result = e_bal.GetEmployees(name);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = result;
        }
        public void DeleteEmp(int _id)
        {
            EmployeeBAL e_bal = new EmployeeBAL();
            if (e_bal.DeleteEmployeeDetails(_id))
            {
                MessageBox.Show("Deleted...");
            }
            else
            {
                MessageBox.Show("Fail to delete. There is some error please contact your administrator.");
            }
        }
        
        #endregion

        
        
    }
}
