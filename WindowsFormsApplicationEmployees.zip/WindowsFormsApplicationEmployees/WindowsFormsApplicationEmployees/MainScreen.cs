﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplicationEmployees
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
            EmployeeList objEmplist = new EmployeeList();
            objEmplist.MdiParent = this;
            objEmplist.Show();
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {

        }

        
    }
}
