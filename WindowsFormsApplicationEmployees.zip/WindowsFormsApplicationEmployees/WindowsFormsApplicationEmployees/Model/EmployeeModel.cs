﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplicationEmployees
{
    public class EmployeeModel
    {
        public EmployeeModel()
        {
            this.Edit = "Edit";
            this.Delete = "Delete";
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public DateTime JoiningDate { get; set; }
       // public string ProfilePicture { get; set; }
        public string DesignationName { get; set; }
        public int desId { get; set; }
        
        public string JoiningDateString
        {
            get
            {
                //return this.JoiningDate.ToString("dd/MM/yyyy");
                return this.JoiningDate.ToString("dd MMM yyyy");
            }
        }
        public string DOBString 
        {
            get 
            {
                 return this.DOB.ToString("dd-MMM-yyyy");
            }
        }
        public string EName
        {
            get
            {
                return string.Format("{0} {1}", this.FirstName, this.LastName);
            }
        }
        //public string DesignationNameString
        //{
        //    get
        //    {
        //        return this.desId.ToString();
        //    }
        //}

        public string Edit { get; set; }
        public string Delete { get; set; }
        //public List<EmployeeModel> EmpModel { get; set; }
    }
 
    //class designation
    //{
    //    public int Id { get; set; }
    //    public string DesignationName { get; set; }
    //}
}
