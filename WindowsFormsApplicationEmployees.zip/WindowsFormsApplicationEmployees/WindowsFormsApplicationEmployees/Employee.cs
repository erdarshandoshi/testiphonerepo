﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplicationEmployees.BAL;

namespace WindowsFormsApplicationEmployees
{
    public partial class Employee : Form
    {

        EmployeeBAL m_EmployeeBAL;
        int m_employeeId = 0;

        // public List<EmployeeModel> showEmpData { get; set; }
        #region Constructor
        public Employee()
        {
            InitializeComponent();
            m_EmployeeBAL = new EmployeeBAL();
            bind();
        }
        public Employee(int empId)
            : this()
        {
            this.m_employeeId = empId;
            btnAddEmployee.Text = "Save Changes";
            this.Text = "Update Record";

            #region Get employee detail from database by id and load all data to control
            EmployeeModel mdl = m_EmployeeBAL.GetEmpById(m_employeeId);
            txtFirstName.Text = mdl.FirstName;
            txtLastName.Text = mdl.LastName;
            txtDOB.Text = mdl.DOB.ToShortDateString();
            dateTimePicker1.Value = mdl.JoiningDate;
            cmbDesignation.SelectedValue = mdl.desId;
            //var _ds = cmbDesignation.DataSource as DataTable;
            //for (int i = 0; i < _ds.Rows.Count; i++)
            //{

            //}
            #endregion
        }

        private void bind()
        {
            System.Data.DataSet ds = m_EmployeeBAL.GetAllDesignations();
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                cmbDesignation.DisplayMember = "DesignationName";
                cmbDesignation.ValueMember = "Id";
                cmbDesignation.DataSource = ds.Tables[0];
            }
        }
        #endregion

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            EmployeeModel mdl = new EmployeeModel();
            m_EmployeeBAL = new EmployeeBAL();
            mdl.Id = m_employeeId;

            DateTime _dob;
            if (DateTime.TryParseExact(txtDOB.Text.Trim(), "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _dob))
            {
                mdl.DOB = _dob;
            }
            else
            {
                MessageBox.Show("Invalid Date !!! Please enter in format of dd/MM/yyyy");
                return;
            }
            //mdl.DOB = Parse.ToDate(Convert.ToDateTime(txtDOB.Text));
            mdl.FirstName = txtFirstName.Text;
            mdl.LastName = txtLastName.Text;
            mdl.JoiningDate = dateTimePicker1.Value.Date;
            mdl.Gender = rbMale.Checked ? rbMale.Text : rbFemale.Text;
            mdl.desId = Convert.ToInt32(cmbDesignation.SelectedValue);

            bool result = m_EmployeeBAL.InsertUpdateEmployeeDetails(mdl);
            if (result)
            {
                MessageBox.Show("Employee details added successfully...");

                this.Close();

            }
            else
            {
                MessageBox.Show("Fail to save data... Please contact your administrator...");
            }
        }



        private void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            //if (rbMale.Checked)
            //{
            //    mdl.Gender = rbMale.Text;
            //}

        }

        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            //if (rbFemale.Checked)
            //{
            //    mdl.Gender = rbFemale.Text;
            //}

        }
        #region picture
        private void llBrowsePhoto_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                pictureBox1.ImageLocation = openFileDialog1.FileName;
            }
        }
        #endregion

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (m_employeeId > 0)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            else
            {
                this.Close();
            }
        }

      
    }
}
