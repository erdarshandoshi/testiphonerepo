﻿namespace WindowsFormsApplicationEmployees
{
    partial class EmployeeList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgvcId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcEmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcDOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcJoiningDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcDesignation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvcEdit = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dgvcDelete = new System.Windows.Forms.DataGridViewLinkColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnAdd);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel1.Controls.Add(this.txtsearch);
            this.splitContainer1.Panel1.Controls.Add(this.lblSearch);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Size = new System.Drawing.Size(643, 563);
            this.splitContainer1.SplitterDistance = 59;
            this.splitContainer1.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(565, 24);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(230, 24);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(124, 27);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(100, 20);
            this.txtsearch.TabIndex = 1;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(31, 30);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(87, 13);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Search By Name";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvcId,
            this.dgvcEmployeeName,
            this.dgvcGender,
            this.dgvcDOB,
            this.dgvcJoiningDate,
            this.dgvcDesignation,
            this.dgvcEdit,
            this.dgvcDelete});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(643, 500);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dgvcId
            // 
            this.dgvcId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dgvcId.DataPropertyName = "Id";
            this.dgvcId.HeaderText = "Id";
            this.dgvcId.Name = "dgvcId";
            this.dgvcId.ReadOnly = true;
            this.dgvcId.Visible = false;
            // 
            // dgvcEmployeeName
            // 
            this.dgvcEmployeeName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dgvcEmployeeName.DataPropertyName = "EName";
            this.dgvcEmployeeName.HeaderText = "Employee Name";
            this.dgvcEmployeeName.Name = "dgvcEmployeeName";
            this.dgvcEmployeeName.ReadOnly = true;
            // 
            // dgvcGender
            // 
            this.dgvcGender.DataPropertyName = "Gender";
            this.dgvcGender.HeaderText = "Gender";
            this.dgvcGender.Name = "dgvcGender";
            this.dgvcGender.ReadOnly = true;
            this.dgvcGender.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvcGender.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dgvcGender.Width = 60;
            // 
            // dgvcDOB
            // 
            this.dgvcDOB.DataPropertyName = "DOBString";
            this.dgvcDOB.HeaderText = "DOB";
            this.dgvcDOB.Name = "dgvcDOB";
            this.dgvcDOB.ReadOnly = true;
            // 
            // dgvcJoiningDate
            // 
            this.dgvcJoiningDate.DataPropertyName = "JoiningDateString";
            this.dgvcJoiningDate.HeaderText = "JoiningDate";
            this.dgvcJoiningDate.Name = "dgvcJoiningDate";
            this.dgvcJoiningDate.ReadOnly = true;
            // 
            // dgvcDesignation
            // 
            this.dgvcDesignation.DataPropertyName = "DesignationName";
            this.dgvcDesignation.HeaderText = "Designation";
            this.dgvcDesignation.Name = "dgvcDesignation";
            this.dgvcDesignation.ReadOnly = true;
            // 
            // dgvcEdit
            // 
            this.dgvcEdit.DataPropertyName = "Edit";
            this.dgvcEdit.HeaderText = "Edit";
            this.dgvcEdit.Name = "dgvcEdit";
            this.dgvcEdit.ReadOnly = true;
            // 
            // dgvcDelete
            // 
            this.dgvcDelete.DataPropertyName = "Delete";
            this.dgvcDelete.HeaderText = "Delete";
            this.dgvcDelete.Name = "dgvcDelete";
            this.dgvcDelete.ReadOnly = true;
            // 
            // EmployeeList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 563);
            this.Controls.Add(this.splitContainer1);
            this.Name = "EmployeeList";
            this.Text = "EmployeeList";
            this.Load += new System.EventHandler(this.EmployeeList_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcEmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcGender;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcDOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcJoiningDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvcDesignation;
        private System.Windows.Forms.DataGridViewLinkColumn dgvcEdit;
        private System.Windows.Forms.DataGridViewLinkColumn dgvcDelete;
    }
}