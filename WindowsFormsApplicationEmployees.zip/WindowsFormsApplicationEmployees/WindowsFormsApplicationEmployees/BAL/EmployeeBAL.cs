﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HitechDAL;
using System.Configuration;
using WindowsFormsApplicationEmployees;
using System.Data;
using System.Data.SqlClient;


namespace WindowsFormsApplicationEmployees.BAL
{
    public class EmployeeBAL : Model.IEmployee
    {
        #region Fields
        DBManager m_db;

        #endregion

        #region constructor
        public EmployeeBAL()
        {
            string str = ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(str);
        }
        #endregion

        #region UDF
        internal DataSet GetAllDesignations()
        {
            try
            {
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetDesignation");
                return ds;
            }
            catch
            {
                throw;
            }
        }






        public List<EmployeeModel> GetEmployees(string name)//search
        {
            List<EmployeeModel> objList;    // = new List<EmployeeModel>();
            HitechQueryParameter para1 = new HitechQueryParameter();
            para1.AddQueryParameter("@EmployeeName", name);
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetEmployeesDetails", para1);// get all details by id
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                objList = new List<EmployeeModel>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    EmployeeModel obj = new EmployeeModel();
                    obj.Id = Convert.ToInt32(row["Id"]);
                    obj.FirstName = Convert.ToString(row["FirstName"]);
                    obj.LastName = Convert.ToString(row["LastName"]);
                    obj.Gender = Convert.ToString(row["Gender"]);
                    obj.DOB = Convert.ToDateTime(row["DOB"]);
                    obj.JoiningDate = Convert.ToDateTime(row["JoiningDate"]);
                    obj.DesignationName = Convert.ToString(row["DesignationName"]);
                    //obj.desId = Convert.ToInt32(row["Id"]);
                    objList.Add(obj);
                }
                return objList;
            }
                    

            else
            {
                return objList = new List<EmployeeModel>();
            }
            //return objList;
        }
        #endregion

        internal bool InsertUpdateEmployeeDetails(EmployeeModel mdl)//add and update data
        {
            try
            {
                HitechQueryParameter paramList = new HitechQueryParameter();
                paramList.AddQueryParameter("@Id", mdl.Id);
                paramList.AddQueryParameter("@FirstName", mdl.FirstName);
                paramList.AddQueryParameter("@LastName", mdl.LastName);
                paramList.AddQueryParameter("@Gender", mdl.Gender);
                paramList.AddQueryParameter("@DOB", Convert.ToDateTime(mdl.DOB));
                paramList.AddQueryParameter("@JoiningDate", Convert.ToDateTime(mdl.JoiningDate));
                paramList.AddQueryParameter("@desId", mdl.desId);
                m_db.ExecuteNonSPQuery("dbo.InsertUpdateEmployeeDetails", paramList);
                return true;
            }
            catch
            {

                throw;
            }

        }
        internal EmployeeModel GetEmpById(int m_employeeId)//edit
        {
            EmployeeModel mdl = null;
            HitechQueryParameter paramList = new HitechQueryParameter();
            paramList.AddQueryParameter("@Id", m_employeeId);
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetEmpById", paramList);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                mdl = new EmployeeModel();
                mdl.Id = Convert.ToInt32((ds.Tables[0].Rows[0]["Id"]));
                mdl.FirstName = Convert.ToString((ds.Tables[0].Rows[0]["FirstName"]));
                mdl.LastName = Convert.ToString((ds.Tables[0].Rows[0]["LastName"]));
                mdl.Gender = Convert.ToString((ds.Tables[0].Rows[0]["Gender"]));
                mdl.DOB = Convert.ToDateTime((ds.Tables[0].Rows[0]["DOB"]));
                mdl.JoiningDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["JoiningDate"]);
                mdl.desId = Convert.ToInt32(ds.Tables[0].Rows[0]["FK_Id"]);
                //obj.Add(obj);

                return mdl;
            }
            else
            {
                return null;
            }
            
           
        }

        internal bool DeleteEmployeeDetails(int _id)//delete 
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@Id",_id);
            int _result = m_db.ExecuteNonSPQuery("dbo.DeleteEmployeeDetails", param);
            return (_result > 0);
        }
    }
}
