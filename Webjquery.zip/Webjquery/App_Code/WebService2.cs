﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;

/// <summary>
/// Summary description for WebService2
/// </summary>
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class WebService2 : System.Web.Services.WebService
{

    public WebService2()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    ProductBAL objProductBAL = new ProductBAL();
    [WebMethod]

    public List<ProductDTO> GetAllProductDetails(string name, string price)
    {

        List<ProductDTO> lstobjProductDTO = new List<ProductDTO>();
        lstobjProductDTO = objProductBAL.GetAllProductDetails(name, price);
        return lstobjProductDTO;

    }
    [WebMethod]
    public bool InserUpdateProductDetails(ProductDTO objproductDTO)
    {
        bool b = objProductBAL.InserUpdateProductDetails(objproductDTO);
        return true;
    }

     [WebMethod]
    public bool DeleteProductDetailById(int Id)
    {
        bool b = objProductBAL.DeleteProductDetailById(Id);
        return true;
    }
      [WebMethod]
    public ProductDTO GetAllProductDetailsById(int Id)
     {
          ProductDTO objProductDTO = new ProductDTO();
          objProductDTO = objProductBAL.GetAllProductDetailsById(Id);

          return objProductDTO;
     }


}
