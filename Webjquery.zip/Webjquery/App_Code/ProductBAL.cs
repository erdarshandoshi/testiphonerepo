﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAL;
using System.Web.Services;
using System.Data;

/// <summary>
/// Summary description for ProductBAL
/// </summary>
public class ProductBAL
{
    #region MyRegion
    DBManager m_db;
    ProductDTO P_DTO;
    #endregion

    #region Constructor
    public ProductBAL()
    {
      string con = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
      m_db = new DBManager(con);
     
    } 
    #endregion


    #region Methods
    //public List<ProductDTO> GetProductDetails()
    //{
    //    try
    //    {
    //        HitechQueryParameter param = new HitechQueryParameter();
        //    List<ProductDTO> lstobjProductDTO = new List<ProductDTO>();
        //    DataSet ds = new DataSet();
        //    ds = m_db.ExecuteDataSetForProcedure("dbo.GetDetails", param);
        //    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in ds.Tables[0].Rows)
        //        {
        //            ProductDTO objproductDTO = new ProductDTO();
        //            objproductDTO.ProductId = Convert.ToInt32(dr["ProductId"]);
        //            objproductDTO.ProductName = (dr["ProductName"]).ToString();
        //            objproductDTO.Price = Convert.ToInt64(dr["Price"]);
        //            lstobjProductDTO.Add(objproductDTO);
        //        }
        //    }
        //    return lstobjProductDTO;
        //}
    //    catch (Exception ex)
    //    {
            
    //        throw ex;
    //    }
    //} 
    #endregion

    public List<ProductDTO> GetAllProductDetails(string name, string price)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            List<ProductDTO> lstobjProductDTO = new List<ProductDTO>();
            //param.AddQueryParameter("@ProductId", id);
            param.AddQueryParameter("@ProductName", name);
            param.AddQueryParameter("@Price", price);
            DataSet ds = new DataSet();
            ds = m_db.ExecuteDataSetForProcedure("dbo.GetAllProductDetails", param);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0  )
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ProductDTO objproductDTO = new ProductDTO();
                     objproductDTO.ProductId = Convert.ToInt32(dr["ProductId"]);
                    objproductDTO.ProductName = (dr["ProductName"]).ToString();
                    objproductDTO.Price = Convert.ToInt64(dr["Price"]);
                    lstobjProductDTO.Add(objproductDTO);

                }
            }
            return lstobjProductDTO;

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool InserUpdateProductDetails(ProductDTO objproductDTO)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@ProductId", objproductDTO.ProductId);
            param.AddQueryParameter("@ProductName", objproductDTO.ProductName);
            param.AddQueryParameter("@productPrice", objproductDTO.Price);
            m_db.ExecuteNonSPQuery("dbo.InserUpdateProductDetails", param);
            return true;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }


    #region for AddEditProductDetails.aspx
    public ProductDTO GetDetailsById(int GetId)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@ProductId", GetId);
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetProductDetailsById", param);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ProductDTO objProductDTO = new ProductDTO();
                //objProductDTO.ProductId = Convert.ToInt32(ds.Tables[0].Rows[0]["ProductId"]);
                objProductDTO.ProductName = Convert.ToString(ds.Tables[0].Rows[0]["ProductName"]);
                objProductDTO.Price = Convert.ToInt64(ds.Tables[0].Rows[0]["Price"]);
                return objProductDTO;
            }
            else
            {
                return null;
            }

        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    
    #endregion
    internal bool DeleteProductDetailById(int Id)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@ProductId", Id);
            int delete = m_db.ExecuteNonSPQuery("dbo.DeleteProductDetailById", param);
            //if (delete > 0)
            return delete > 0;

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    #region For ShowProductDetails.aspx
    public ProductDTO GetAllProductDetailsById(int Id)
    {
        try
        {
            HitechQueryParameter param = new HitechQueryParameter();
            param.AddQueryParameter("@ProductId", Id);
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetProductDetailsById", param);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ProductDTO objProductDTO = new ProductDTO();
                objProductDTO.ProductId = Convert.ToInt32(ds.Tables[0].Rows[0]["ProductId"]);
                objProductDTO.ProductName = Convert.ToString(ds.Tables[0].Rows[0]["ProductName"]);
                objProductDTO.Price = Convert.ToInt64(ds.Tables[0].Rows[0]["Price"]);
                return objProductDTO;

            }
            else
            {
                return null;
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }

    } 
    #endregion
}