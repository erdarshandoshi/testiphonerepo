﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddEditProductDetails : System.Web.UI.Page
{
    #region MyRegion
    ProductDTO objproductDTO = new ProductDTO();
    ProductBAL objproductBAL = new ProductBAL(); 
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
       if(!IsPostBack)
       { 
        if(!string.IsNullOrEmpty(Request.QueryString["getid"]))
        {
           int  GetId =  Convert.ToInt32(Request.QueryString["getid"]);
           #region Edit
           if (GetId > 0)
           {
               RetriveData(GetId);
           } 
           #endregion
            else
            {
               //add data code....
              
            }
        }
       }
           
           

    }


    #region Private Methods
    private void RetriveData(int GetId)
    {
        objproductBAL = new ProductBAL();
        ProductDTO objproductDTO = objproductBAL.GetDetailsById(GetId);
         txtProductName.Value = objproductDTO.ProductName;
         txtProductPrice.Value = objproductDTO.Price.ToString();
    }

 


    #endregion
   
     
   
}