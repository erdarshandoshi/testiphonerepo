﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Drawing;
using System.IO;
using System.Web.Mvc;
using System.Net.Mail;

namespace DocflowWebTool.Utility
{
    public static class Utilities
    {
        public static System.Drawing.Bitmap ConvertToBitonal(System.Drawing.Bitmap original)
        {
            System.Drawing.Bitmap source = null;

            // If original bitmap is not already in 32 BPP, ARGB format, then convert
            if (original.PixelFormat != System.Drawing.Imaging.PixelFormat.Format32bppArgb)
            {
                source = new System.Drawing.Bitmap(original.Width, original.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                source.SetResolution(original.HorizontalResolution, original.VerticalResolution);
                using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(source))
                {
                    g.DrawImageUnscaled(original, 0, 0);
                }
            }
            else
            {
                source = original;
            }

            // Lock source bitmap in memory
            System.Drawing.Imaging.BitmapData sourceData = source.LockBits(new System.Drawing.Rectangle(0, 0, source.Width, source.Height), System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            // Copy image data to binary array
            int imageSize = sourceData.Stride * sourceData.Height;
            byte[] sourceBuffer = new byte[imageSize];
            System.Runtime.InteropServices.Marshal.Copy(sourceData.Scan0, sourceBuffer, 0, imageSize);

            // Unlock source bitmap
            source.UnlockBits(sourceData);

            // Create destination bitmap
            System.Drawing.Bitmap destination = new System.Drawing.Bitmap(source.Width, source.Height, System.Drawing.Imaging.PixelFormat.Format1bppIndexed);
            destination.SetResolution(original.HorizontalResolution, original.VerticalResolution);

            // Lock destination bitmap in memory
            System.Drawing.Imaging.BitmapData destinationData = destination.LockBits(new System.Drawing.Rectangle(0, 0, destination.Width, destination.Height), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format1bppIndexed);

            // Create destination buffer
            imageSize = destinationData.Stride * destinationData.Height;
            byte[] destinationBuffer = new byte[imageSize];

            int sourceIndex = 0;
            int destinationIndex = 0;
            int pixelTotal = 0;
            byte destinationValue = 0;
            int pixelValue = 128;
            int height = source.Height;
            int width = source.Width;
            int threshold = 500;

            // Iterate lines
            for (int y = 0; y < height; y++)
            {
                sourceIndex = y * sourceData.Stride;
                destinationIndex = y * destinationData.Stride;
                destinationValue = 0;
                pixelValue = 128;

                // Iterate pixels
                for (int x = 0; x < width; x++)
                {
                    // Compute pixel brightness (i.e. total of Red, Green, and Blue values) - Thanks murx
                    //                           B                             G                              R
                    pixelTotal = sourceBuffer[sourceIndex] + sourceBuffer[sourceIndex + 1] + sourceBuffer[sourceIndex + 2];
                    if (pixelTotal > threshold)
                    {
                        destinationValue += (byte)pixelValue;
                    }
                    if (pixelValue == 1)
                    {
                        destinationBuffer[destinationIndex] = destinationValue;
                        destinationIndex++;
                        destinationValue = 0;
                        pixelValue = 128;
                    }
                    else
                    {
                        pixelValue >>= 1;
                    }
                    sourceIndex += 4;
                }
                if (pixelValue != 128)
                {
                    destinationBuffer[destinationIndex] = destinationValue;
                }
            }

            // Copy binary image data to destination bitmap
            System.Runtime.InteropServices.Marshal.Copy(destinationBuffer, 0, destinationData.Scan0, imageSize);

            // Unlock destination bitmap
            destination.UnlockBits(destinationData);

            // Dispose of source if not originally supplied bitmap
            if (source != original)
            {
                source.Dispose();
            }

            // Return
            return destination;
        }
        public static Image RotateImage(Image img, int rotationIndex)
        {
            if (rotationIndex > 4)
            {
                rotationIndex = rotationIndex % 4;
            }
            switch (rotationIndex)
            {
                case 1:
                    img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case 2:
                    img.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
                case 3:
                    img.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
                default:
                    break;

            }

            return img;
        }
        public static void CopyValues<TSource, TTarget>(TSource source, TTarget target)
        {
            var sourceProperties = typeof(TSource).GetProperties().Where(p => p.CanRead);

            foreach (var property in sourceProperties)
            {
                var targetProperty = typeof(TTarget).GetProperty(property.Name);

                if (targetProperty != null && targetProperty.CanWrite && targetProperty.PropertyType.IsAssignableFrom(property.PropertyType))
                {
                    var value = property.GetValue(source, null);

                    targetProperty.SetValue(target, value, null);
                }
            }
        }
        public static string EncodeTo64(string toEncode)
        {
            byte[] toEncodeAsBytes = System.Text.Encoding.Unicode.GetBytes(toEncode);
            string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            return returnValue;
        }
        public static string DecodeFrom64(string encodedData)
        {
            byte[] encodedDataAsBytes = System.Convert.FromBase64String(encodedData);
            string returnValue = System.Text.Encoding.Unicode.GetString(encodedDataAsBytes);
            return returnValue;
        }
        public static System.Collections.Specialized.NameValueCollection GetDecodedQueryStringCollection(string _queryString)
        {
            System.Collections.Specialized.NameValueCollection collection = new System.Collections.Specialized.NameValueCollection();
            var _allQueryString = _queryString.Split('&');
            for (int i = 0; i < _allQueryString.Length; i++)
            {
                var _nameValue = _allQueryString[i].Split('=');
                if (_nameValue.Length == 2)
                {
                    collection.Add(_nameValue[0], _nameValue[1]);
                }
            }
            return collection;
        }

        public static int SafeCastToInt(object value)
        {
            int result = 0;
            try
            {
                result = Convert.ToInt32(value);
            }
            catch
            {
                result = 0;
            }
            return result;
        }
        public static float SafeCastToFloat(object value)
        {
            float result = 0;
            try
            {
                result = Convert.ToSingle(value);
            }
            catch
            {
                result = 0;
            }
            return result;
        }
        public static long SafeCastToLong(object value)
        {
            long result = 0;
            try
            {
                result = Convert.ToInt64(value);
            }
            catch
            {
                result = 0;
            }
            return result;
        }
        public static decimal SafeCastToDecimal(object value)
        {
            decimal result = 0;
            try
            {
                result = Convert.ToDecimal(value);
            }
            catch
            {
                result = 0;
            }
            return result;
        }
        internal static DateTime? SafeCastToDateTime(object value)
        {
            DateTime? result = null;
            try
            {
                result = Convert.ToDateTime(value);
            }
            catch
            {
                result = null;
            }
            return result;
        }
        public static System.Drawing.Image GetImageNoLock(string path)
        {
            try
            {
                if (!string.IsNullOrEmpty(path) && System.IO.File.Exists(path))
                {
                    using (var ms = new System.IO.MemoryStream(System.IO.File.ReadAllBytes(path)))
                    {
                        System.Drawing.Image tmpimg = System.Drawing.Image.FromStream(ms);
                        System.Drawing.Image tmp = (System.Drawing.Image)tmpimg.Clone();
                        System.Threading.Thread.Sleep(10);
                        return tmp;
                    }
                }
                else
                {
                    throw new FileNotFoundException("File not found @ " + path);
                }
            }
            catch (Exception ex)
            {
                throw new System.Exception("Unable to Get Image object without Lock", ex);
            }
        }
        public static bool SafeCastBoolean(object value)
        {
            bool result = false;
            try
            {
                result = Convert.ToBoolean(value);
            }
            catch
            {
                result = false;
            }
            return result;
        }
        public static string ToBase64String(System.Drawing.Image bmp)
        {
            string base64String = string.Empty;
            MemoryStream memoryStream = null;

            try { bmp = bmp.ConvertToBitonal(); }
            catch { }
            try
            {
                memoryStream = new MemoryStream();
                bmp.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
            }
            catch
            {
                return String.Empty;
            }

            memoryStream.Position = 0;
            byte[] byteBuffer = memoryStream.ToArray();

            memoryStream.Close();

            base64String = Convert.ToBase64String(byteBuffer, Base64FormattingOptions.InsertLineBreaks);
            byteBuffer = null;

            return base64String;
        }
        public static int SafeCastInt(object value)
        {
            int result = 0;
            try
            {
                result = Convert.ToInt32(value);
            }
            catch
            {
                result = 0;
            }
            return result;
        }
        #region SaveImage
        public static bool SaveImageAsTiff(this System.Drawing.Bitmap image, string destFileName)
        {
            try
            {
                System.Drawing.Imaging.ImageCodecInfo myImageCodecInfo;
                System.Drawing.Imaging.Encoder myEncoder;
                System.Drawing.Imaging.EncoderParameter myEncoderParameter;
                System.Drawing.Imaging.EncoderParameters myEncoderParameters;

                // Get an ImageCodecInfo object that represents the TIFF codec.
                myImageCodecInfo = GetEncoderInfo("image/tiff");

                // Create an Encoder object based on the GUID 
                // for the Compression parameter category.
                myEncoder = System.Drawing.Imaging.Encoder.Compression;

                // Create an EncoderParameters object. 
                // An EncoderParameters object has an array of EncoderParameter 
                // objects. In this case, there is only one 
                // EncoderParameter object in the array.
                myEncoderParameters = new System.Drawing.Imaging.EncoderParameters(1);

                // Save the bitmap as a TIFF file with LZW compression.
                myEncoderParameter = new System.Drawing.Imaging.EncoderParameter(myEncoder, (long)System.Drawing.Imaging.EncoderValue.CompressionCCITT4);
                // myEncoderParameter = new System.Drawing.Imaging.EncoderParameter(myEncoder, (long)System.Drawing.Imaging.EncoderValue.CompressionLZW);
                myEncoderParameters.Param[0] = myEncoderParameter;
                image.Save(destFileName, myImageCodecInfo, myEncoderParameters);

                //System.Drawing.Imaging.EncoderParameters codecParamsTif = new System.Drawing.Imaging.EncoderParameters(1);
                //codecParamsTif.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Compression, ((long)System.Drawing.Imaging.EncoderValue.CompressionCCITT4));
                //System.Drawing.Imaging.ImageCodecInfo tiffCodec = GetEncoderInfo("image/tiff");
                //System.Threading.Thread.Sleep(30);
                //image.Save(destFileName, tiffCodec, codecParamsTif);
                return true;
            }
            catch
            {
                image.Save(destFileName, System.Drawing.Imaging.ImageFormat.Tiff);
                return true;
                //throw ex;
            }
        }
        public static bool SaveImageASJpeg(this System.Drawing.Image image, string destFileName, long quality)
        {
            try
            {
                System.Drawing.Imaging.ImageCodecInfo myImageCodecInfo;
                System.Drawing.Imaging.Encoder myEncoder;
                System.Drawing.Imaging.EncoderParameter myEncoderParameter;
                System.Drawing.Imaging.EncoderParameters myEncoderParameters;

                // Get an ImageCodecInfo object that represents the JPEG codec.
                myImageCodecInfo = GetEncoderInfo("image/jpeg");

                // Create an Encoder object based on the GUID 
                // for the Quality parameter category.
                myEncoder = System.Drawing.Imaging.Encoder.Quality;

                // Create an EncoderParameters object. 
                // An EncoderParameters object has an array of EncoderParameter 
                // objects. In this case, there is only one 
                // EncoderParameter object in the array.
                myEncoderParameters = new System.Drawing.Imaging.EncoderParameters(1);

                myEncoderParameter = new System.Drawing.Imaging.EncoderParameter(myEncoder, quality);
                myEncoderParameters.Param[0] = myEncoderParameter;
                image.Save(destFileName, myImageCodecInfo, myEncoderParameters);

                //System.Drawing.Imaging.EncoderParameters codecPara = new System.Drawing.Imaging.EncoderParameters(1);
                //codecPara.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
                //System.Drawing.Imaging.ImageCodecInfo jpegCodec = GetEncoderInfo("image/jpeg");
                //System.Threading.Thread.Sleep(10);
                //image.Save(destFileName, jpegCodec, codecPara);
                return true;
            }
            catch
            {
                image.Save(destFileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                return true;
                //throw ex;
            }
        }
        public static System.Drawing.Imaging.ImageCodecInfo GetEncoderInfo(string encoderName)
        {
            System.Drawing.Imaging.ImageCodecInfo[] codecs = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders();
            return codecs.ToList().Find(p => p.MimeType == encoderName);
        }
        public static Bitmap ConvertToBitonal(this System.Drawing.Image original)
        {
            Bitmap bmp = (Bitmap)original;
            return ConvertToBitonal(bmp);
        }
        #endregion

        public static void ClearTemp()
        {
            try
            {
                string _path = System.IO.Path.GetTempPath();
                var _allDir = System.IO.Directory.GetDirectories(_path);
                foreach (var d in _allDir)
                {
                    try
                    {
                        System.IO.Directory.Delete(d, true);
                    }
                    catch { }
                }
                var _allfiles = System.IO.Directory.GetFiles(_path);
                foreach (var f in _allfiles)
                {
                    try
                    {
                        System.IO.File.Delete(f);
                    }
                    catch { }
                }
            }
            catch
            { }
        }

        public static bool DeleteFile(string FileName, int attempt)
        {
            if (attempt != 0)
            {
                try
                {
                    if (File.Exists(FileName))
                    {
                        File.Delete(FileName);
                    }
                    return true;
                }
                catch
                {
                    System.Threading.Thread.Sleep(attempt * 1000);
                    attempt--;
                    return DeleteFile(FileName, attempt);
                }
            }
            else
            {
                return false;
            }
        }
    }

    public class TextValueCollection
    {
        public TextValueCollection()
        {
            this.Text = string.Empty;
            this.Value = string.Empty;
        }
        public TextValueCollection(string text, string value)
        {
            this.Text = text;
            this.Value = value;
        }
        public string Text { get; set; }
        public string Value { get; set; }
    }

    public class TextValue
    {
        public TextValue()
        {
            this.Id = 0;
            this.Value = string.Empty;
        }

        public TextValue(int Id, string value)
        {
            this.Id = Id;
            this.Value = value;
        }

        public int Id { get; set; }
        public string Value { get; set; }
    }

    public static class ObjectExtension
    {
        public static int SafeCastToInt(this Object value)
        {
            int result = 0;
            try
            {
                result = Convert.ToInt32(value);
            }
            catch
            { }
            return result;
        }
        public static long SafeCastToLong(this Object value)
        {
            long result = 0;
            try
            {
                result = Convert.ToInt64(value);
            }
            catch
            { }
            return result;
        }
        public static decimal SafeCastToDecimal(this Object value)
        {
            decimal result = 0;
            try
            {
                result = Convert.ToDecimal(value);
            }
            catch
            { }
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static int SafeCastInt(string str)
        {
            int x = 0;
            try
            {
                x = Convert.ToInt32(str);
                return x;
            }
            catch
            {
                return 0;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static int SafeCastInt(object value)
        {
            int x = 0;
            try
            {
                x = Convert.ToInt32(value);
                return x;
            }
            catch
            {
                return 0;
            }
        }

    }

    public static class MailHelper
    {
        public static bool SendMail(string from, List<string> to, List<string> cc, string body, string subject, string username, string password, string host, List<string> attachments)
        {
            return SendMail(from, to, cc, body, subject, username, password, host, 587, true, attachments);
        }

        public static bool SendMail(string from, List<string> to, List<string> cc, string body, string subject, string username, string password, string host, int port, bool enableSSL, List<string> attachments)
        {
            using (MailMessage mailMessage = new MailMessage())
            {
                mailMessage.From = new MailAddress(from);
                to.ForEach((x) =>
                {
                    if (Convert.ToString(x).Trim() != string.Empty)
                    {
                        mailMessage.To.Add(new MailAddress(x));
                    }
                });
                if (cc != null && cc.Count > 0)
                {
                    cc.ForEach((x) =>
                    {
                        if (Convert.ToString(x).Trim() != string.Empty)
                        {
                            mailMessage.CC.Add(new MailAddress(x));
                        }
                    });
                }
                mailMessage.Body = body;
                mailMessage.Subject = subject;

                try
                {
                    SmtpClient SmtpServer = new SmtpClient();
                    SmtpServer.Credentials = new System.Net.NetworkCredential(username, password);
                    SmtpServer.Port = port; //587;
                    SmtpServer.Host = host;
                    SmtpServer.EnableSsl = enableSSL;

                    mailMessage.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                    mailMessage.IsBodyHtml = true;
                    mailMessage.ReplyToList.Add(new MailAddress(from));

                    if (attachments != null && attachments.Count > 0)
                    {
                        attachments.ForEach(x => mailMessage.Attachments.Add(new Attachment(x)));
                    }

                    SmtpServer.Send(mailMessage);
                }
                catch (Exception ex)
                {
                    throw new Exception("Unable to send mail. ", ex);
                }
            }
            return true;
        }
    }
}