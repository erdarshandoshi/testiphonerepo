﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DocflowWebTool.Utility
{
    /// <summary>
    /// 
    /// </summary>
    public static class Logger
    {
        /// <summary>
        /// 
        /// </summary>
        private static string _logPath;

        /// <summary>
        /// 
        /// </summary>
        public static string LogPath
        {
            get { return _logPath; }
            set { _logPath = value; }
        }

        private static bool IsBusy = false;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        public static void WriteLog(Exception ex)
        {
            if (ex != null && !string.IsNullOrEmpty(ex.Message))
            {
                if (ex.Message.Contains("Thread was being aborted"))
                {
                    return;
                }
                if (IsBusy)
                {
                    System.Threading.Thread.Sleep(1000);
                }
                try
                {
                    IsBusy = true;
                    string sLogFormat = null;
                    string sPathName;
                    sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";
                    string sYear = DateTime.Now.Year.ToString();
                    string sMonth = DateTime.Now.Month.ToString();
                    string sDay = DateTime.Now.Day.ToString();
                    string sErrorTime = sYear + sMonth + sDay; //+ DocflowLoginDetails.UserName;
                    string logFileName = sErrorTime;

                    if (HttpContext.Current != null && HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null)
                    {
                        /*Start Change By Niyati*/
                        var loggedUser = HttpContext.Current.Session["LoggedUser"];
                        if (loggedUser != null)
                        {
                            var _allProps = loggedUser.GetType().GetProperties();
                            if (_allProps.Length > 0)
                            {
                                var foundLoggedUser = _allProps.FirstOrDefault(p => p.Name == "UserName");
                                if (foundLoggedUser != null)
                                {
                                    string _userName = Convert.ToString(foundLoggedUser.GetValue(loggedUser, null));
                                    logFileName = sErrorTime + "_" + _userName;
                                }
                            }
                        }
                        /*Start Change By Niyati*/
                    }


                    sPathName = (string.IsNullOrEmpty(_logPath)) ? HttpContext.Current.Request.PhysicalApplicationPath + "\\ErrorLog\\" : _logPath;
                    if (!System.IO.Directory.Exists(sPathName)) System.IO.Directory.CreateDirectory(sPathName);
                    sPathName = System.IO.Path.Combine(sPathName, (logFileName + ".log"));
                    using (System.IO.StreamWriter sw = new System.IO.StreamWriter(sPathName, true))
                    {
                        sw.WriteLine();
                        sw.WriteLine(sLogFormat);
                        sw.WriteLine("Error : " + ex.Message.ToString());
                        sw.WriteLine();
                        if (ex.InnerException != null)
                        {
                            sw.WriteLine("InnerException : " + ex.InnerException.Message);
                            sw.WriteLine();
                            if (ex.InnerException.InnerException != null)
                            {
                                sw.WriteLine("InnerException2 : " + ex.InnerException.InnerException.Message);
                                sw.WriteLine();
                            }
                        }
                        sw.WriteLine("Stack Trace : " + (string.IsNullOrEmpty(ex.StackTrace) ? string.Empty : Convert.ToString(ex.StackTrace).Trim()));
                        sw.WriteLine("***************************************************************************************************************");
                        sw.Flush();
                    }
                }
                catch (System.IO.IOException err)
                {
                    throw new Exception("Unable to create error log. " + err.Message, err);
                }
                finally
                {
                    IsBusy = false;
                }
            }
        }
    }



}