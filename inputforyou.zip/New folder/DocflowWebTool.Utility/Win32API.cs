﻿using System;
using System.Security.Principal;
using System.Linq;
using System.Web;
using System.Collections;

namespace DocflowWebTool.Utility
{
    public static class Win32API
    {
        #region Impersonate Code
        public const int LOGON32_LOGON_INTERACTIVE = 2;
        public const int LOGON32_PROVIDER_DEFAULT = 0;
        static WindowsImpersonationContext impersonationContext;
        [System.Runtime.InteropServices.DllImport("advapi32.dll")]
        public static extern int LogonUserA(String lpszUserName, String lpszDomain, String lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);
        [System.Runtime.InteropServices.DllImport("advapi32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        public static extern int DuplicateToken(IntPtr hToken, int impersonationLevel, ref IntPtr hNewToken);
        [System.Runtime.InteropServices.DllImport("advapi32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        public static extern bool RevertToSelf();
        [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern bool CloseHandle(IntPtr handle);
        public static bool ImpersonateValidUser(String userName, String domain, String password)
        {
            WindowsIdentity tempWindowsIdentity;
            IntPtr token = IntPtr.Zero;
            IntPtr tokenDuplicate = IntPtr.Zero;

            if (RevertToSelf())
            {
                if (LogonUserA(userName, domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, ref token) != 0)
                {
                    if (DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                    {
                        tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                        impersonationContext = tempWindowsIdentity.Impersonate();
                        if (impersonationContext != null)
                        {
                            CloseHandle(token);
                            CloseHandle(tokenDuplicate);
                            return true;
                        }
                    }
                }
            }
            if (token != IntPtr.Zero)
                CloseHandle(token);
            if (tokenDuplicate != IntPtr.Zero)
                CloseHandle(tokenDuplicate);
            return false;
        }
        /*pass projectname as parameter because of multiple Projects*/
        //public static bool ImpersonateValidUser(string projectName)
        //{
        //    try
        //    {
        //        bool _impersonateSuccessful = false;

        //        //UserDTO _userDTO = null;
        //        if (System.Web.HttpContext.Current != null && System.Web.HttpContext.Current.Session != null)
        //        {
        //           var  _userDTO = (System.Web.HttpContext.Current.Session["LoggedUser"] as UserDTO);
        //        }
        //        foreach (var _key in System.Configuration.ConfigurationManager.AppSettings.AllKeys)
        //        {
        //            if (_key.StartsWith("DataPath_"))
        //            {
        //                System.Diagnostics.Debug.WriteLine("Key Matched : " + _key);
        //                string[] _strArr = _key.Split('_');
        //                if (_strArr.Length > 2)
        //                {
        //                    string _path = _strArr[1];
        //                    string _domainName = _strArr[2];
        //                    if (_userDTO == null)
        //                    {
        //                        string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
        //                        string _decryptedCredintials = Utility.Utilities.DecodeFrom64(_encryptedCredintials);
        //                        string[] _credintials = _decryptedCredintials.Split('_');
        //                        _impersonateSuccessful = ImpersonateValidUser(_credintials[0], _domainName, _credintials[1]);
        //                        break;
        //                    }
        //                    else //if (_userDTO.ProjectPaths[0].Contains(_path))
        //                    {
        //                        string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
        //                        string _decryptedCredintials = Utility.Utilities.DecodeFrom64(_encryptedCredintials);
        //                        System.Diagnostics.Debug.WriteLine(_decryptedCredintials);
        //                        string[] _credintials = _decryptedCredintials.Split('_');
        //                        //string _domain = System.Configuration.ConfigurationManager.AppSettings["ImporsonateDomain"];
        //                        //string _userName = System.Configuration.ConfigurationManager.AppSettings["ImporsonateUserName"];
        //                        //string _password = System.Configuration.ConfigurationManager.AppSettings["ImporsonateUserPassword"];

        //                        /*Start Change by Niyati*/
        //                        ProjectDTO _projectDTO = _userDTO.Projects.FirstOrDefault(x => x.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
        //                        if (_projectDTO != null)
        //                        {
        //                            foreach (string _dataPath in _projectDTO.ProjectPaths)
        //                            {
        //                                /*End Change by Niyati*/

        //                                if (_dataPath.Contains(_path))
        //                                {
        //                                    _impersonateSuccessful = ImpersonateValidUser(_credintials[0], _domainName, _credintials[1]);
        //                                    System.Diagnostics.Debug.WriteLine("call final ImpersonateValidUser() => " + _credintials[0] + _domainName + _credintials[1]);
        //                                    if (_impersonateSuccessful)
        //                                    {
        //                                        break;
        //                                    }
        //                                }
        //                            }
        //                        }
        //                        break;
        //                    }
        //                }
        //            }
        //        }
        //        return _impersonateSuccessful;
        //        //}
        //        //else
        //        //{
        //        //    return false;
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        Utility.Logger.WriteLog(ex);
        //        System.Diagnostics.Debug.WriteLine("Error:" + ex.Message);

        //        throw ex;
        //    }
        //}


        public static bool ImpersonateValidUser(string projectName)
        {
            try
            {
                bool _impersonateSuccessful = false;

                //UserDTO _userDTO = null;
                if (System.Web.HttpContext.Current != null && System.Web.HttpContext.Current.Session != null)
                {
                    var loggedUser = (System.Web.HttpContext.Current.Session["LoggedUser"]);
                    if (loggedUser != null)
                    {
                        var _allProps = loggedUser.GetType().GetProperties();
                        //if (_allProps.Length > 0)
                        //{
                        //    var foundLoggedUser = _allProps.FirstOrDefault(p => p.Name == "UserName");

                        //}

                        foreach (var _key in System.Configuration.ConfigurationManager.AppSettings.AllKeys)
                        {
                            if (_key.StartsWith("DataPath_"))
                            {
                                System.Diagnostics.Debug.WriteLine("Key Matched : " + _key);
                                string[] _strArr = _key.Split('_');
                                if (_strArr.Length > 2)
                                {
                                    string _path = _strArr[1];
                                    string _domainName = _strArr[2];
                                    if (loggedUser == null)
                                    {
                                        string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
                                        string _decryptedCredintials = Utility.Utilities.DecodeFrom64(_encryptedCredintials);
                                        string[] _credintials = _decryptedCredintials.Split('_');
                                        _impersonateSuccessful = ImpersonateValidUser(_credintials[0], _domainName, _credintials[1]);
                                        break;
                                    }
                                    else //if (_userDTO.ProjectPaths[0].Contains(_path))
                                    {
                                        string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
                                        string _decryptedCredintials = Utility.Utilities.DecodeFrom64(_encryptedCredintials);
                                        System.Diagnostics.Debug.WriteLine(_decryptedCredintials);
                                        string[] _credintials = _decryptedCredintials.Split('_');
                                        //string _domain = System.Configuration.ConfigurationManager.AppSettings["ImporsonateDomain"];
                                        //string _userName = System.Configuration.ConfigurationManager.AppSettings["ImporsonateUserName"];
                                        //string _password = System.Configuration.ConfigurationManager.AppSettings["ImporsonateUserPassword"];

                                        /*Start Change by Niyati*/
                                        var _allProjectsProp = loggedUser.GetType().GetProperty("Projects");
                                        if(_allProjectsProp != null)
                                        {
                                            IList  _allProjects = _allProjectsProp.GetValue(loggedUser, null) as IList;
                                            foreach (var item in _allProjects)
                                            {
                                                if (item.GetType().GetProperty("ProjectName").GetValue(item, null).ToString().ToLower() == projectName.Trim().ToLower())
                                                {
                                                    var _projectPaths = item.GetType().GetProperty("ProjectPaths");

                                                    break;
                                                }
                                            }
                                        }
                                        //ProjectDTO _projectDTO = loggedUser.Projects.FirstOrDefault(x => x.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
                                        //if (_projectDTO != null)
                                        //{
                                        //    foreach (string _dataPath in _projectDTO.ProjectPaths)
                                        //    {
                                        //        /*End Change by Niyati*/

                                        //        if (_dataPath.Contains(_path))
                                        //        {
                                        //            _impersonateSuccessful = ImpersonateValidUser(_credintials[0], _domainName, _credintials[1]);
                                        //            System.Diagnostics.Debug.WriteLine("call final ImpersonateValidUser() => " + _credintials[0] + _domainName + _credintials[1]);
                                        //            if (_impersonateSuccessful)
                                        //            {
                                        //                break;
                                        //            }
                                        //        }
                                        //    }
                                        //}
                                        //break;
                                    }
                                }
                            }
                        }
                    }
                }
                return _impersonateSuccessful;
                //}
                //else
                //{
                //    return false;
                //}
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                System.Diagnostics.Debug.WriteLine("Error:" + ex.Message);

                throw ex;
            }
        }



        public static void UndoImpersonation()
        {
            impersonationContext.Undo();
        }
        #endregion
    }
}