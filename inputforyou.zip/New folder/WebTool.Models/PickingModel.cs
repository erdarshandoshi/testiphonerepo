﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using DocflowWebTool.Utility;


namespace WebTool.Models
{
    public class PickingModel
    {
        [Required(ErrorMessage = "*")]
        [Remote("IsValidBox", "Picking", AdditionalFields = "BoxNo,BoxLength", ErrorMessage = "Invalid Box !!!")]
        public string BoxNo { get; set; }
        public string BoxLength { get; set; }

        [RequiredIf("IsPickingAvailable", true, ErrorMessage = "*")]
        public string Barcode { get; set; }
        public string RecieveDate { get; set; }
        public bool IsPickingAvailable { get; set; }
        [Required(ErrorMessage = "*")]
        public string Operator { get; set; }

        public DateTime? RecieveDateTime
        {
            get
            {
                DateTime? _vl = null;
                if (!string.IsNullOrEmpty(this.RecieveDate))
                {
                    DateTime _outDT;
                    if (DateTime.TryParseExact(this.RecieveDate, "dd MMMM yyyy - hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _outDT))
                    {
                        _vl = _outDT;
                    }
                }
                return _vl;
            }
        }
    }

    public class PickingModelDTO
    {
        public int Id { get; set; }
        public int No { get; set; }
        public string BoxNo { get; set; }
        public string Barcode { get; set; }
        public string RecievedTime { get; set; }

        public string Free1 { get; set; }
        public string Free2 { get; set; }
        public string Free3 { get; set; }
        public string Free4 { get; set; }
        public string Free5 { get; set; }
        public string Free6 { get; set; }
        public string Free7 { get; set; }
        public string Free8 { get; set; }
        public string Free9 { get; set; }
        public string Free10 { get; set; }
    }
}