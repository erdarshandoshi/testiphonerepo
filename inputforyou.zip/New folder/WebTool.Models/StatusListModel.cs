﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebTool.Models
{
    public class StatusListModel
    {
        public long CifId { get; set; }
        public string BoxId { get; set; }
        public string FolderId { get; set; }

        /* start code by niyati for  retrive images*/
        public int TotalImages { get; set; }
        /*end code by niyati*/

        public List<StatusListDTO> LstStatusListDTO = new List<StatusListDTO>();
        public List<DynamicControlDetailsDTO> lstDynamicControlDetailsDTO = new List<DynamicControlDetailsDTO>();


    }
    public class StatusListDTO
    {
        public StatusListDTO()
        {
            //ProductionView = "View";
            //RawView = "Raw View";
            //MoreDetails = "More";
        }
        public long CifId { get; set; }
        public int RowNumber { get; set; }
        public string BoxId { get; set; }
        public string FolderId { get; set; }
        public string TotalImages { get; set; }
        public string ScannedDate { get; set; }
        public string Free1 { get; set; }
        public string Free2 { get; set; }
        public string Free3 { get; set; }
        public string Free4 { get; set; }
        public string Free5 { get; set; }
        public string Free6 { get; set; }
        public string Free7 { get; set; }
        public string Free8 { get; set; }
        public string Free9 { get; set; }
        public string Free10 { get; set; }
        public string FolderStatus { get; set; }
        //public string MoreDetails { get; set; }
        //public string RawView { get; set; }
        //public string ProductionView { get; set; }
    }

    public class DynamicControlDetailsDTO
    {
        public string ControlName { get; set; }
        public string Name { get; set; }
        public string TEXT { get; set; }
        public string DataSource { get; set; }
        public bool status { get; set; }

    }

    public class HeaderDTO
    {
        public string HeaderName { get; set; }
        public string width { get; set; }
    }

    public class ProcessModel
    {
        //public int ProcessId { get; set; }
        public string ProcessName { get; set; }
        public bool IsCompleted { get; set; }
        public string ProcessOperator { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string TimeTaken { get; set; }
    }

    public class TextValueCollection
    {
        public TextValueCollection()
        {
            this.Text = string.Empty;
            this.Value = string.Empty;
        }
        public TextValueCollection(string text, string value)
        {
            this.Text = text;
            this.Value = value;
        }
        public string Text { get; set; }
        public string Value { get; set; }
    }
}