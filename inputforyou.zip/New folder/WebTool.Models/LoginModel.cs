﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace WebTool.Models
{
    public class LoginModel
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class UserModel
    {
        public UserModel()
        {
            this.UserId = 0;
            this.LogId = 0;
            this.UserName = string.Empty;
            this.FirstName = string.Empty;
            this.LastName = string.Empty;
            this.UserType = string.Empty;
            this.EmailId = string.Empty;
            this.Location = string.Empty;
            this.IsActive = true;
            this.ProfilePhotoPath = string.Empty;
        }

        public virtual long UserId { get; set; }
        [Display(Name = "Email Id")]
        [Required(ErrorMessage = "*")]
        public virtual string UserName { get; set; }
        public virtual long LogId { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public int UserTypeId { get; set; }
        public virtual string UserType { get; set; }
        [Display(Name = "Email Id")]
        [Required(ErrorMessage = "*")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public virtual string EmailId { get; set; }

        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }

        public virtual string Location { get; set; }
        public virtual string ProfilePhotoPath { get; set; }
    }

    public class UserDTO : UserModel
    {
        public UserDTO()
        {
            this.Projects = new List<ProjectDTO>();
        }
        public List<ProjectDTO> Projects { get; set; }
    }

    public class PartnerModel : UserModel
    {
        public string Password { get; set; }
    }



    public class PreparatorModel : UserModel
    {
        [Required(ErrorMessage = "*")]
        public long PartnerId { get; set; }
        [Required(ErrorMessage = "*")]
        public string PartnerName { get; set; }
    }



    public class ProjectDTO
    {
        public ProjectDTO()
        {
            this.ProjectPaths = new List<string>();
            this.Modules = new List<ModuleDTO>();
            this.IsActive = true;
            this.Documents = new List<ProjectDocuments>();
            /*Start Change By Niyati*/
            this.ProjectScanPartners = new List<ProjectPartners>();
            /*End Change By Niyati*/
        }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string CompanyName { get; set; }
        public string StartingLocation { get; set; }
        public string BoxStructure { get; set; }
        public string BoxLength { get; set; }
        public bool IsPickingList { get; set; }
        public bool IsPatchInData { get; set; }
        public bool IsFtpSftpScan { get; set; }
        public bool IsBox { get; set; }
        public bool IsBagBatchBox { get; set; }
        public bool IsBoxBatchBox { get; set; }
        public bool IsProjectNameInBarcode { get; set; }
        public string ScanDPI { get; set; }
        public string DataPath { get; set; }
        public string ProductionPath { get; set; }
        public DateTime DevelopMentDate { get; set; }
        public DateTime TestingDate { get; set; }
        public DateTime LiveDate { get; set; }
        public string NetworkPath { get; set; }
        public string Partner { get; set; }
        public string TransferProtocol { get; set; }
        public string TransferEncryption { get; set; }
        public int TransferPort { get; set; }
        public string TransferHost { get; set; }
        public string TransferUsername { get; set; }
        public string TransferPassword { get; set; }

        public string ProjectConnectionString { get; set; }
        public List<string> ProjectPaths { get; set; }
        public List<ModuleDTO> Modules { get; set; }
        public string IconClass { get; set; }

        public List<SelectListItem> ProcessDetailNames { get; set; }
        public string SiteURL { get; set; }
        public bool IsActive { get; set; }


        public string ProjectDescription { get; set; }

        public List<ProjectDocuments> Documents { get; set; }
        /*Strat Change by Niyati*/
        public List<ProjectPartners> ProjectScanPartners { get; set; }
        public Int16 ProjectStateId { get; set; }
        /*End Change by Niyati*/

    }

    public class ProjectListDTO
    {
        public ProjectListDTO()
        {
            this.ProjectName = string.Empty;
            this.CompanyName = string.Empty;
            this.StartingLocation = string.Empty;
            this.BoxStructure = string.Empty;
        }
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string CompanyName { get; set; }
        public string StartingLocation { get; set; }
        public string BoxStructure { get; set; }
    }

    public class ProcessFlowDTO
    {
        public string ProcessGroupName { get; set; }
        public string ProcessDetailName { get; set; }
        public int ProcessDetailId { get; set; }
    }

    public class ModuleDTO
    {
        public string ModuleName { get; set; }
        public string IconClass { get; set; }
        // Start change by Niyati
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
        // End change by Niyati
    }

    public class DashboardDTO
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string ProjectURL { get; set; }
        public string CompanyName { get; set; }
        public string StartingLocation { get; set; }
        public string WebSiteUrl { get; set; }
        public string ProjectLogoPath { get; set; }
        public bool IsPickingList { get; set; }
        public DateTime? LiveDate { get; set; }
        public int MailInput { get; set; }
        public int FtpSftpInput { get; set; }
        public string ProjectDescription { get; set; }
        public string Logistic { get; set; }
        /*Start Change By Niyati*/
        public Int16 ProjectStateId { get; set; }
        /*End Change By Niyati*/
        public string ShortLocation
        {
            get
            {
                if (!string.IsNullOrEmpty(StartingLocation) && StartingLocation.Length > 60)
                {
                    return StartingLocation.Substring(0, 60) + "...";
                }
                return StartingLocation;
            }
        }
    }

    /*Start Change By Niyati*/
    public enum ProjectStatus
    {
        None = 0,
        Under_Development = 1,
        Under_Testing = 2,
        Live = 3,
        Completed = 4,
        Archieved = 5,
        On_Hold = 6
    }
    /*End Change By Niyati*/
}