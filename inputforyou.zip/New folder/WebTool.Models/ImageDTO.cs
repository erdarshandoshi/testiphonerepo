﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebTool.Models
{
    public class ImageDTO
    {
        public ImageDTO()
        {
            RegistrationId = 0;
            FileName = string.Empty;
            ImageLocation = string.Empty;
            ConjugateFileName = string.Empty;
            IsColored = false;
            IsDeleted = 0;
            RotationIndex = 0;
            BoxNo = string.Empty;
            FolderNo = string.Empty;
            SourceRootPath = string.Empty;
            BookMark = string.Empty;
            //Base64 = string.Empty;
            this.Height = 0;
            this.Width = 0;
            this.DisplayName = string.Empty;
        }
        #region Properties
        /// <summary>
        /// 
        /// </summary>
        public int CifId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int RegistrationId { get; set; }
        /// <summary>
        /// File name that should be display on screen
        /// </summary>
        public string DisplayName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FileName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ConjugateFileName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool IsColored { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int IsDeleted { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int RotationIndex { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BoxNo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FolderNo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string SourceRootPath { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ImageLocation { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string BookMark { get; set; }

        public int Height { get; set; }
        public int Width { get; set; }

        /// <summary>
        /// 
        /// </summary>
        //  private int m_treeBookMarkId = 0;
        //public int TreeBookMarkId
        //{
        //    get { return m_treeBookMarkId; }
        //    set { m_treeBookMarkId = value; }
        //}


        //public string Base64 { get; set; }


        #endregion
    }
}