﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebTool.Models
{
    public class FolderDeleteModel
    {
        public int Id { get; set; }

        public string Box { get; set; }
        public string Folder { get; set; }
        public string FolderStatus { get; set; }

    }
    public class RetriveReasonDTO
    {
        public int FolderDeleteReasonId { get; set; }
        public string FolderDeleteReason { get; set; }
    }

    public class RoleTypeDTO
    {
        public int userTypeId { get; set; }
        public string userType { get; set; }
    }
}