﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebTool.Models
{
    public class RightsModel
    {
        public RightsModel()
        {
            this.ModuleDetailNames = new List<SelectListItem>();
        }
        public bool IsSelectType { get; set; }
        public bool Box { get; set; }
        public List<SelectListItem> ModuleDetailNames { get; set; }
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public string Status { get; set; }
        public bool MarkAsDeleted { get; set; }
        public long RightsId { get; set; }
        public long UserId { get; set; }
        public string UserName { get; set; }
        public bool ModuleStatus{ get; set; }
       // public List<RoleGroupDTO> roleDTO = new List<RoleGroupDTO>();
    }
    public class RightsDTO
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public string Status { get; set; }
        // public string MarkAsDeleted { get; set; }
        //public bool Status { get; set; }
        public bool MarkAsDeleted { get; set; }
    }

    //public class RoleGroupDTO
    //{
    //    public int UserTypeId { get; set; }
    //    public string UserType { get; set; }
    //}

    public class UserGroupDTO
    {
        public long userId { get; set; }
        public string UserName { get; set; }
       
    }

}