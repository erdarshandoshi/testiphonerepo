﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebTool.Models
{
    public class PickingListResult
    {
        public PickingListResult()
        {
            this.Data = new List<PickingListDTO>();
        }
        public Exception Error { get; set; }
        public string CustomErrorMessage { get; set; }
        public List<PickingListDTO> Data { get; set; }
        public int TotalRecordCount { get; set; }
        public List<string> Columns { get; set; }
    }

    public class PickingListDTO
    {
        public PickingListDTO()
        {
            this.Id = 0;
            this.No = 0;
            this.BoxNo = string.Empty;
        }

        public long Id { get; set; }
        public int No { get; set; }
        [Required]
        public string BoxNo { get; set; }
        public string Free1 { get; set; }
        public string Free2 { get; set; }
        public string Free3 { get; set; }
        public string Free4 { get; set; }
        public string Free5 { get; set; }
        public string Free6 { get; set; }
        public string Free7 { get; set; }
        public string Free8 { get; set; }
        public string Free9 { get; set; }
        public string Free10 { get; set; }
        public string Free11 { get; set; }
        public string Free12 { get; set; }
        public string Free13 { get; set; }
        public string Free14 { get; set; }
        public string Free15 { get; set; }
        public string Free16 { get; set; }
        public string Free17 { get; set; }
        public string Free18 { get; set; }
        public string Free19 { get; set; }
        public string Free20 { get; set; }
    }
}