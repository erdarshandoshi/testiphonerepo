﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebTool.Models
{
    public class DashboardModel
    {
        /*class copy from loginmodel by niyati*/
        public class DashboardDTO
        {
            public int ProjectId { get; set; }
            public string ProjectName { get; set; }
            public string ProjectURL { get; set; }
            public string CompanyName { get; set; }
            public string StartingLocation { get; set; }
            public string WebSiteUrl { get; set; }
            public string ProjectLogoPath { get; set; }
            public bool IsPickingList { get; set; }
            public DateTime? LiveDate { get; set; }
            public int MailInput { get; set; }
            public int FtpSftpInput { get; set; }
            public string ProjectDescription { get; set; }
            public string Logistic { get; set; }
            /*Start Change By Niyati*/
            public Int16 ProjectStateId { get; set; }
            /*End Change By Niyati*/
            public string ShortLocation
            {
                get
                {
                    if (!string.IsNullOrEmpty(StartingLocation) && StartingLocation.Length > 60)
                    {
                        return StartingLocation.Substring(0, 60) + "...";
                    }
                    return StartingLocation;
                }
            }
        }

    }


}