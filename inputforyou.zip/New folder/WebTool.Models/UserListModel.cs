﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebTool.Models
{
    public class UserListModel
    {
        public long userId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Location { get; set; }
        public string EmailId { get; set; }
        public bool status { get; set; }
        public bool IsWebAccess { get; set; }
        public DateTime CreatedDate { get; set; }
        public short CompanyId { get; set; }
        public short UserTypeId { get; set; }
        public string CompanyName { get; set; }
        public string UserType { get; set; }
        public List<RoleDTO> roleDTO = new List<RoleDTO>();
        public List<CompanyDTO> companyDTO = new List<CompanyDTO>();
    }

    public class RoleDTO
    {
        public int UserTypeId { get; set; }
        public string UserType { get; set; }
    }

    public class CompanyDTO
    {
        public short CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}