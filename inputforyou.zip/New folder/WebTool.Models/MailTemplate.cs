﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebTool.Models
{
    public class MailTemplate
    {
        public MailTemplate(string templateName, string htmlBody)
        {
            m_TemplateName = templateName;
            m_HTMLBody = htmlBody;
            this.ToRecipient = new List<string>();
            this.CcRecipient = new List<string>();
            this.BccRecipient = new List<string>();
        }

        #region Properties
        private string m_TemplateName;
        public string TemplateName
        {
            get { return m_TemplateName; }
        }

        private string m_HTMLBody;
        public string HTMLBody
        {
            get { return m_HTMLBody; }
        }

        public List<string> ToRecipient { get; set; }
        public List<string> CcRecipient { get; set; }
        public List<string> BccRecipient { get; set; }
        #endregion
    }
    public class MailProfile
    {
        public MailProfile(string profileName, string protocol, string mailHost, int port, string emailId, string password, bool enableSSL)
        {
            m_profileName = profileName;
            m_protocol = protocol;
            m_mailHost = mailHost;
            m_port = port;
            m_emailId = emailId;
            m_mailPassword = password;
            m_enableSSL = enableSSL;
        }

        #region Properties
        private string m_mailHost;
        public string MailHost
        {
            get { return m_mailHost; }
        }

        private string m_mailPassword;
        public string MailPassword
        {
            get { return m_mailPassword; }
        }

        private string m_emailId;
        public string EmailId
        {
            get { return m_emailId; }
        }

        private int m_port;
        public int Port
        {
            get { return m_port; }
        }

        private bool m_enableSSL;
        public bool EnableSSL
        {
            get { return m_enableSSL; }
        }

        private string m_profileName;
        public string ProfileName
        {
            get { return m_profileName; }
        }

        private string m_protocol;
        public string Protocol
        {
            get { return m_protocol; }
        }
        #endregion
    }
}
