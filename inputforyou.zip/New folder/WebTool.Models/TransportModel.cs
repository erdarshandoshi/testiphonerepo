﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using DocflowWebTool.Utility;

namespace WebTool.Models
{
    public class TransporterModel
    {
        public string ProjectName { get; set; }
        public string TransporterName { get; set; }
        [Required(ErrorMessage = "*")]
        [Remote("IsValidTransportBox", "Transporter", AdditionalFields = "BoxNo,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string BoxNo { get; set; }
        public string Folders { get; set; }
        public string BoxLength { get; set; }
        [RequiredIf("IsBoxBatchBox", true, ErrorMessage = "*")]
        [Remote("IsValidTransportBatch", "Transporter", AdditionalFields = "Batch,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string Batch { get; set; }
        public string StartLocation { get; set; }
        [Required(ErrorMessage = "*")]
        public string DestinationLocation { get; set; }
        public string PickDate { get; set; }
        public string Operator { get; set; }
        public bool IsBox { get; set; }
        public bool IsBagBatchBox { get; set; }
        public bool IsBoxBatchBox { get; set; }

        public int RecordId { get; set; }

        public DateTime? PickDateTime
        {
            get
            {
                DateTime? _vl = null;
                if (!string.IsNullOrEmpty(this.PickDate))
                {
                    DateTime _outDT;
                    if (DateTime.TryParseExact(this.PickDate, "dd MMMM yyyy - hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _outDT))
                    {
                        _vl = _outDT;
                    }
                }
                return _vl;
            }
        }
    }

    public class TransporterDTO
    {
        public TransporterDTO()
        {
            this.EditLink = "Edit";
            this.DeleteLink = "Delete";
        }
        public int Id { get; set; }
        public int No { get; set; }
        public string BoxNo { get; set; }
        public string Batch { get; set; }
        public string TotalFolder { get; set; }
        public string StartLocation { get; set; }
        public string DestinationLocation { get; set; }
        public string TransportDate { get; set; }
        public string ReceptionDate { get; set; }
        public string EditLink { get; set; }
        public string DeleteLink { get; set; }
        public bool IsReceptionDateAvailable { get; set; }
    }
}