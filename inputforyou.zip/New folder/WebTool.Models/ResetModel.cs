﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebTool.Models
{
    public class ResetModel
    {
        //[Required]
        public string Box { get; set; }
        public string Folder { get; set; }
        public int Status { get; set; }
        //public string Status { get; set; }

        public List<StatusDTO> StatusListDTO = new List<StatusDTO>();
        public List<ResetDTO> resetlistDTO = new List<ResetDTO>();
        public List<ResetStatusDTO> resetstatuslistDTO = new List<ResetStatusDTO>();
    }
    public class StatusDTO
    {
        public int StatusId { get; set; }
        public string Status { get; set; }
    }

    public class ResetDTO
    {
        public int Id { get; set; }
        public string Box { get; set; }
        public string Folder { get; set; }
        public int Status { get; set; }


       // public string Status { get; set; }
    }

    public class ReasonDTO
    {
        public int ReasonId { get; set; }
        public string Reason { get; set; }
    }
    public class ResetStatusDTO
    {
        public int id { get; set; }
        public string statusName { get; set; }
        public int status { get; set; }
    }
    public class SaveDTO
    {
        public int CurrentStatus { get; set; }
        public int Reason { get; set; }
        public string Remark { get; set; }
        public int ResetToStatus { get; set; }
    }


}
