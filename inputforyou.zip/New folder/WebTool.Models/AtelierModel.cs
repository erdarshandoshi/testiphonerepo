﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using DocflowWebTool.Utility;

namespace WebTool.Models
{
    #region Class For Reception

    public class AtelierReceptionModel
    {
        [RequiredIf("IsBagBatchBox", false, ErrorMessage = "*")]
        //[Remote("IsValidBox", "Atelier", AdditionalFields = "BoxNo,BoxLength", ErrorMessage = "Invalid Box !!!")]
        [Remote("IsValidTransportBox", "Atelier", AdditionalFields = "BoxNo,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string BoxNo { get; set; }
        public string BoxLength { get; set; }
        [RequiredIf("IsBoxBatchBox", true, ErrorMessage = "*")]
        [Remote("IsValidTransportBatch", "Atelier", AdditionalFields = "Batch,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string Batch { get; set; }
        public string Folders { get; set; }
        public string RecieveDate { get; set; }
        public bool IsBox { get; set; }
        public bool IsBagBatchBox { get; set; }
        public bool IsBoxBatchBox { get; set; } //barcode required
        public bool IsProjectNameInBarcode { get; set; }

        [Required(ErrorMessage = "*")]
        public string Operator { get; set; }

        public DateTime? RecieveDateTime
        {
            get
            {
                DateTime? _vl = null;
                if (!string.IsNullOrEmpty(this.RecieveDate))
                {
                    DateTime _outDT;
                    if (DateTime.TryParseExact(this.RecieveDate, "dd MMMM yyyy - hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _outDT))
                    {
                        _vl = _outDT;
                    }
                }
                return _vl;
            }
        }
    }

    public class AtelierReceptionDTO
    {
        public AtelierReceptionDTO()
        {
            this.BackToIfyStatus = string.Empty;
            this.DeleteLink = "Delete";
        }

        public int Id { get; set; }
        public int No { get; set; }
        public string BoxBagNo { get; set; }
        public string Batch { get; set; }
        public string TotalFolder { get; set; }
        public string RecievedTime { get; set; }
        public string BackToIfyStatus { get; set; }
        public string OperatorName { get; set; }
        public string DeleteLink { get; set; }
    }

    #endregion

    #region Class For Preparation
    public class PreparationDTO
    {
        public int PreparationId { get; set; }
        public int No { get; set; }
        public string BoxBatch { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string PreparatorName { get; set; }
    }

    public class AtelierPreparationModel
    {
        public AtelierPreparationModel()
        {
            this.IsBatchAlreadyStarted = false;
        }

        [Remote("IsValidPreparationBoxBatch", "Atelier", AdditionalFields = "BoxBatchNo,BoxBatchLength,IsBatchAlreadyStarted")]
        [Required]
        public string BoxBatchNo { get; set; }
        public string BoxBatchLength { get; set; }
        public string RecieveDate { get; set; }
        public bool IsBag { get; set; } //if true then batch and false then box
        public bool IsBatchAlreadyStarted { get; set; }
        public bool IsProjectNameInBarcode { get; set; }
        public bool IsBoxBatchBox { get; set; }
        [Required(ErrorMessage = "*")]
        public string Operator { get; set; }
        public DateTime? RecieveDateTime
        {
            get
            {
                DateTime? _vl = null;
                if (!string.IsNullOrEmpty(this.RecieveDate))
                {
                    DateTime _outDT;
                    if (DateTime.TryParseExact(this.RecieveDate, "dd MMMM yyyy - hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _outDT))
                    {
                        _vl = _outDT;
                    }
                }
                return _vl;
            }
        }
    }

    public class AtelierPreparationDTO
    {
        public int Id { get; set; }
        public int No { get; set; }
        public string BoxBatchNo { get; set; }
        public string RecievedTime { get; set; }
    }

    #endregion

    #region Class For Transporter

    public class TransportDTO
    {
        public TransportDTO()
        {
            this.RecievedDate = string.Empty;
            this.Destination = string.Empty;
            this.BoxBatch = string.Empty;
            this.Batch = string.Empty;
            this.DeleteLink = "Delete";
        }

        public int No { get; set; }
        public int TransportId { get; set; }
        public string Destination { get; set; }
        public string BoxBatch { get; set; }
        public string Batch { get; set; }
        public string RecievedDate { get; set; }
        public string DeleteLink { get; set; }
    }

    public class TransportDestinationDTO
    {
        public string Destination { get; set; }
    }

    public class AtelierTransportModel
    {
        public AtelierTransportModel()
        {
            this.Destination = string.Empty;
            this.RecieveDate = string.Empty;
            this.BoxBatch = string.Empty;
            this.BoxLength = string.Empty;
        }


        public int TransportId { get; set; }
        public string Destination { get; set; }
        [Required(ErrorMessage = "*")]
        [Remote("IsValidTransportBoxForAttelierFoes", "Atelier", AdditionalFields = "BoxBatch,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string BoxBatch { get; set; }
        [RequiredIf("IsBox", false, ErrorMessage = "*")]
        [Remote("IsValidTransportBatch", "Atelier", AdditionalFields = "Batch,BoxLength,IsBox", ErrorMessage = "Invalid Box !!!")]
        public string Batch { get; set; }
        public string BoxLength { get; set; }
        public string RecieveDate { get; set; }
        [Required(ErrorMessage = "*")]
        public string Operator { get; set; }
        public bool IsBox { get; set; }
        public bool IsBagBatchBox { get; set; }
        public bool IsBoxBatchBox { get; set; }
        public bool IsProjectNameInBarcode { get; set; }

        public DateTime? RecieveDateTime
        {
            get
            {
                DateTime? _vl = null;
                if (!string.IsNullOrEmpty(this.RecieveDate))
                {
                    DateTime _outDT;
                    if (DateTime.TryParseExact(this.RecieveDate, "dd MMMM yyyy - hh:mm tt", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _outDT))
                    {
                        _vl = _outDT;
                    }
                }
                return _vl;
            }
        }
        public List<TransportDestinationDTO> DestinationList = new List<TransportDestinationDTO>();

    }

    #endregion

    #region Class For BoxList

    public class BoxListDTO
    {
        public int Id { get; set; }
        public string RNo { get; set; }
        public string BoxNo { get; set; }
        public string Batch { get; set; }
        public string PaletteNumber { get; set; }
        public string TransportDate { get; set; }
        public string Destination { get; set; }
        public string ReceptionDate { get; set; }
        public string PreparatorName { get; set; }
        public string ReceptionName { get; set; }
        public string PreparationStartDate { get; set; }
        public string PrepartionEndDate { get; set; }
        public string ScanningDate { get; set; }
        public string IntegrationDate { get; set; }
        public string BoxStatus { get; set; }
        public string BackToIfyStatus { get; set; }
    }
    #endregion

    #region Class For Palette

    public class AttlierPaletteModel
    {
        public AttlierPaletteModel()
        {
            this.Id = 0;
            this.PaletteNo = string.Empty;
            this.TotalBoxes = string.Empty;

        }


        public int Id { get; set; }
        public string PaletteNo { get; set; }
        public string TotalBoxes { get; set; }
        public string TotalFolder { get; set; }
        public string TotalSheet { get; set; }
        public string PaletteStatus { get; set; }
        public string Destruction { get; set; }
        public string DestructionDate { get; set; }
    }


    public class PaletteDTO
    {
        public int Id { get; set; }
        public int PaletteId { get; set; }
        public string PaletteNo { get; set; }
        public string BoxId { get; set; }
        public string TotalBoxes { get; set; }
        public string TotalFolder { get; set; }
        public string TotalSheet { get; set; }
        public string PaletteStatus { get; set; }
        public string Destruction { get; set; }
        public string DestructionDate { get; set; }
        public string PaletteIntegrateDate { get; set; }
        public string BoxDetail { get; set; }
    }


    public class AssignPaletteDTO
    {
        public string BoxId { get; set; }
        public string PaletteNumber { get; set; }
        public string PaletteStatus { get; set; }
    }

    #endregion

    #region Class For Scanning
    public class AtelierScanningModel
    {
        public string BoxNo { get; set; }
        public string BoxLength { get; set; }
    }

    public class AtelierScanningDTO
    {
        public int Id { get; set; }
        public int No { get; set; }
        public string BoxNo { get; set; }
        public string Batch { get; set; }
        public string PreparationStartDate { get; set; }
        public string PreparationEndDate { get; set; }
        public string BoxScanDate { get; set; }
    }

    #endregion
}
