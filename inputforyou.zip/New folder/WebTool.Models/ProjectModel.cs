﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using DocflowWebTool.Utility;

namespace WebTool.Models
{
    public class ProjectModel
    {
        public ProjectModel()
        {
            this.DpiList = new List<SelectListItem>() { new SelectListItem() { Text = "--Select--", Value = "0", Selected = true }, new SelectListItem() { Text = "200", Value = "200" }, new SelectListItem() { Text = "240", Value = "240" }, new SelectListItem() { Text = "300", Value = "300" } };
            this.ProcessFlow = new List<ProcessDTO>();
            this.IsFtpSftpScan = false;
            //this.PartnerList = new List<PartnerDTO>();
            //this.MailDetailsList = new List<MailDetailDTO>();
            this.ProjectName = string.Empty;
            this.CompanyName = string.Empty;
            this.StartingLocation = string.Empty;
            this.BoxLength = "0";
            this.DevelopmentDate = DateTime.Now.ToString("dd/MM/yyyy");
            this.TestingDate = DateTime.Now.AddDays(15).ToString("dd/MM/yyyy");
            this.LiveDate = DateTime.Now.AddMonths(1).ToString("dd/MM/yyyy");
            this.NetworkPath = string.Empty;
            this.InputInbound = new InputInboundDTO();
            this.ProcessDetailNames = new List<SelectListItem>();
            this.Documents = new List<ProjectDocuments>();
            this.ProjectScanPartners = new List<ProjectPartners>();
            this.ProjectStateList = new List<SelectListItem>();
        }

        public int Id { get; set; }
        [Required(ErrorMessage = "*")]
        //[Remote("IsProjectExist", "Project", AdditionalFields = "ProjectName,Id", ErrorMessage = "Already Exist...")]
        public string ProjectName { get; set; }
        [Required(ErrorMessage = "*")]
        public string StartingLocation { get; set; }
        [Required(ErrorMessage = "*")]
        public string BoxStructure { get; set; }
        [Required(ErrorMessage = "*")]
        public string BoxLength { get; set; }
        [Required(ErrorMessage = "*")]
        public string ScanningDPI { get; set; }
        [Required(ErrorMessage = "*")]
        public bool IsPatchInData { get; set; }
        [Required(ErrorMessage = "*")]
        public bool IsPickingList { get; set; }
        [Required(ErrorMessage = "*")]
        public bool IsFtpSftpScan { get; set; }
        [Required(ErrorMessage = "*")]
        public string DataPath { get; set; }
        [Required(ErrorMessage = "*")]
        public string ProductionPath { get; set; }
        [RequiredIf("IsFtpSftpScan", false, ErrorMessage = "*")]
        public string NetworkPath { get; set; }
        [RequiredIf("IsFtpSftpScan", true, ErrorMessage = "*")]
        //[RegularExpression(@"/(^\(\d{1-5})?)$/", ErrorMessage = "Please enter proper port number [0-65535].")]
        public int Port { get; set; }

        public bool IsInBoundDetails { get; set; }

        [RequiredIf("IsFtpSftpScan", true, ErrorMessage = "*")]
        [StringLength(50, ErrorMessage = "Ftp/Sftp Url cannot be longer than 50 characters.")]
        public string Url { get; set; }

        [RequiredIf("IsFtpSftpScan", true, ErrorMessage = "*")]
        [StringLength(30, ErrorMessage = "UserName cannot be longer than 30 characters.")]
        public string UserName { get; set; }

        [RequiredIf("IsFtpSftpScan", true, ErrorMessage = "*")]
        [StringLength(30, ErrorMessage = "Password cannot be longer than 30 characters.")]
        public string Password { get; set; }

        [StringLength(100, ErrorMessage = "Default Path cannot be longer than 100 characters.")]
        public string Path { get; set; }

        public string CompanyName { get; set; }
        [Required(ErrorMessage = "*")]
        public int PartnerId { get; set; }
        /*start change by niyati*/
        public string PartnerIds { get; set; }
        [Display(Name = "ProjectStatus")]
        public Int16 ProjectStateId { get; set; }
        public IEnumerable<SelectListItem> ProjectStateList { get; set; }
        /*end change by niyati*/

        #region General - FTP SFTP - Will be used for Transfer
        public int FtpSftpId { get; set; }
        public string Protocol { get; set; }
        public string ProtocolEncryption { get; set; }

        #endregion

        #region Input InBound

        #region Input InBound - Email
        public string IsInputInBoundJobName { get; set; }
        public bool IsInputInBoundEmail { get; set; }
        public string InputInBoundEmailHostUrl { get; set; }
        [RequiredIf("IsInputInBoundEmail", true, ErrorMessage = "*")]
        public string InputInBoundEmailId { get; set; }
        [RequiredIf("IsInputInBoundEmail", true, ErrorMessage = "*")]
        public string InputInBoundEmailPassword { get; set; }
        #endregion

        #region Input InBound - FtpSftp
        public bool IsInputInBoundFtpSftp { get; set; }

        public int InputInBoundFtpSftpId { get; set; }
        public string InputInBoundFtpSftpProtocol { get; set; }
        public string InputInBoundFtpSftpProtocolEncryption { get; set; }

        [RequiredIf("IsInputInBoundFtpSftp", true, ErrorMessage = "*")]
        //[RegularExpression(@"/(^\(\d{1-5})?)$/", ErrorMessage = "Please enter proper port number [0-65535].")]
        public int InputInBoundFtpSftpPort { get; set; }

        [RequiredIf("IsInputInBoundFtpSftp", true, ErrorMessage = "*")]
        [StringLength(50, ErrorMessage = "Ftp/Sftp Url cannot be longer than 50 characters.")]
        public string InputInBoundFtpSftpUrl { get; set; }

        [RequiredIf("IsInputInBoundFtpSftp", true, ErrorMessage = "*")]
        [StringLength(30, ErrorMessage = "UserName cannot be longer than 30 characters.")]
        public string InputInBoundFtpSftpUserName { get; set; }

        [RequiredIf("IsInputInBoundFtpSftp", true, ErrorMessage = "*")]
        [StringLength(30, ErrorMessage = "Password cannot be longer than 30 characters.")]
        public string InputInBoundFtpSftpPassword { get; set; }

        [StringLength(100, ErrorMessage = "Default Path cannot be longer than 100 characters.")]
        public string InputInBoundFtpSftpPath { get; set; }
        #endregion

        #region Input InBound - Scan
        public bool IsInputInBoundScan { get; set; }
        #endregion

        #endregion

        public string Logistic { get; set; }
        public string FK_Partner { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string IsActive { get; set; }
        public string CreatedDate { get; set; }
        public string ModifyDate { get; set; }


        public string LiveDate { get; set; }
        public string TestingDate { get; set; }
        public string DevelopmentDate { get; set; }

        public List<System.Web.Mvc.SelectListItem> DpiList { get; set; }
        public List<PartnerModel> PartnerList { get; set; }
        public List<ProcessDTO> ProcessFlow { get; set; }
        public List<ProjectDTO> ProjectDTOList { get; set; }
        //public List<MailDetailDTO> MailDetailsList { get; set; }

        public bool Box { get; set; }
        public bool BagBatchBox { get; set; }
        public bool BoxBatchBag { get; set; }

        public List<SelectListItem> ProcessDetailNames { get; set; }
        public List<SelectListItem> ProcessDetailId { get; set; }

        #region ProcessDetails
        public string ProcessId { get; set; }
        public int ProjectId { get; set; }
        public int ProcessOrder { get; set; }
        #endregion


        #region Email Jobs To Display
        /// <summary>
        /// Use for incoming data source details
        /// </summary>
        public InputInboundDTO InputInbound { get; set; }
        #endregion

        public string ProjectDescription { get; set; }

        public List<ProjectDocuments> Documents { get; set; }
        /*Start change by Niyati*/
        public List<ProjectPartners> ProjectScanPartners { get; set; }
        /*End change by Niyati*/
    }

    public class ProcessDTO
    {
        public int Id { get; set; }
        public string ProcessName { get; set; }
        public int SortOrder { get; set; }
    }

    public class InputInboundDTO
    {
        public InputInboundDTO()
        {
            this.IsScan = true;
            this.EmailJobs = new List<InputInboundEmailJobDTO>();
            this.FtpSftpJobs = new List<InputInboundFtpSftpDTO>();
        }
        public bool IsScan { get; set; }
        public List<InputInboundEmailJobDTO> EmailJobs { get; set; }
        public List<InputInboundFtpSftpDTO> FtpSftpJobs { get; set; }
    }

    public class InputInboundEmailJobDTO
    {
        public int Id { get; set; }
        public string JobName { get; set; }
        public string MailHost { get; set; }
        public string EmailId { get; set; }
        public string EmailPassword { get; set; }
        public int ProjectId { get; set; }
    }


    public class InputInboundFtpSftpDTO
    {
        public int Id { get; set; }
        public string Protocol { get; set; }
        public string Encryption { get; set; }
        public int Port { get; set; }
        public string Host { get; set; }
        public string FTPUserName { get; set; }
        public string FTPPassword { get; set; }
        public string FTPPath { get; set; }
        public int ProjectId { get; set; }
    }


    public class SecondLoginModel
    {
        public string UserType { get; set; }
        [Required(ErrorMessage = "*")]
        [Remote("IsProjectExist", "Account", AdditionalFields = "ProjectName", ErrorMessage = "Project Not Found !!!")]
        public string ProjectName { get; set; }
        [Required(ErrorMessage = "*")]
        public string Operator { get; set; }
        [Required(ErrorMessage = "*")]
        public string Process { get; set; }
    }

    public class ProjectDocuments
    {
        public ProjectDocuments()
        {
            this.Id = 0;
            this.DocName = string.Empty;
            this.DocSize = "0 KB";
            this.ContentType = string.Empty;
            this.DocPath = string.Empty;
        }
        public int Id { get; set; }
        public string DocName { get; set; }
        public string DocPath { get; set; }
        public string DocSize { get; set; }
        public string ContentType { get; set; }
        public int ProjectId { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    /*start change by Niyati*/
    public class ProjectPartners
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public bool IsPalleteRequiredOnReception { get; set; }
        public bool IsPalleteRequiredOnTransport { get; set; }
    }
    /*end change by Niyati*/

    /*start change by Niyati*/
    //public enum ProjectState
    //{
    //    None = 0,
    //    Under_Development = 1,
    //    Under_Testing = 2,
    //    Live = 3,
    //    Completed = 4,
    //    Archieved = 5,
    //    On_Hold = 6
    //}
    /*end change by Niyati*/
}