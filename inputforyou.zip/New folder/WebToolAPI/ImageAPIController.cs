﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Routing;


namespace WebToolAPI
{
    public class ImageAPIController : ApiController
    {
        [HttpPost]
        [ActionName("ToBase64ThumbString")]

        public object ToBase64ThumbString([FromBody] ArgsImageDTO item)
        //public string ToBase64ThumbString([FromBody] string value)
        {
            //string _path = System.Web.HttpContext.Current.Server.MapPath(string.Format("~/Data/{0}/{1}/{2}", item.BoxNo, item.FolderNo, item.ImageName));
            string _path = System.Web.HttpContext.Current.Server.MapPath(string.Format("~/Data/{0}/{1}/{2}", item.BoxNo, item.FolderNo, item.ImageName));
            string base64string = string.Empty;
            try
            {
                //return path.ToString();
                //if (utility.win32api.impersonatevaliduser())
                //{
                base64string = Utility.ImageHelper.GetMagickImageBase64String(_path, true, true);
                //utility.win32api.undoimpersonation();
                //}
                //else
                //{
                //    utility.logger.writelog(new exception("imperonating fail..."));
                //}
            }
            catch (Exception ex)
            {
                base64string = string.Empty;
                throw ex;
            }
            return new { result = "Success", base64 = base64string };
            //return path.ToString();
        }


    }

    public class ArgsImageDTO
    {
        public string BoxNo { get; set; }
        public string FolderNo { get; set; }
        public string ImageName { get; set; }
    }
   
}
