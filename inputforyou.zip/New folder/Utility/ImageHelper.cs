﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DocflowWebTool.Utility
{
    public class ImageHelper
    {
        public static string GetMagickImageBase64String(string path, bool isThumb, bool addBase64Header)
        {
            string base64String = string.Empty;
            ImageMagick.MagickImage obj = new ImageMagick.MagickImage(path);
            try
            {
                obj.RePage();
                if (obj.Format.ToString().Trim().ToLower().StartsWith("tif")) // == ImageMagick.MagickFormat.Tiff)
                {
                    obj.Format = ImageMagick.MagickFormat.Png;
                    //obj.Scale(new ImageMagick.Percentage(90));
                    //obj.ReduceNoise();

                    //obj.AutoLevel();
                    if (isThumb)
                    {
                        obj.Thumbnail(140, 180);
                        obj.Sharpen();
                    }
                    else
                    {
                        obj.Sharpen();
                        obj.Grayscale(ImageMagick.PixelIntensityMethod.Average);
                    }

                    obj.Resample(300F, 300F);
                    obj.CompressionMethod = ImageMagick.CompressionMethod.LZW;
                    //obj.Normalize();
                    base64String = obj.ToBase64();
                    if (addBase64Header)
                    {
                        base64String = "data:image/png;base64," + base64String;
                    }
                }
                else
                {
                    obj.Format = ImageMagick.MagickFormat.Jpeg;
                    if (isThumb)
                    {
                        obj.Thumbnail(140, 180);
                    }
                    else
                    {
                        //if (obj.FileSize > 512)
                        //{
                        obj.Resize(new ImageMagick.Percentage(60));
                        //}
                    }
                    obj.Resample(300F, 300F);
                    obj.Sharpen();
                    //obj.ChangeColorSpace(ImageMagick.ColorSpace.RGB);
                    obj.CompressionMethod = ImageMagick.CompressionMethod.LZW;
                    obj.Normalize();

                    base64String = obj.ToBase64();
                    if (addBase64Header)
                    {
                        base64String = "data:image/jpeg;base64," + base64String;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                try
                {
                    obj.Dispose();
                }
                catch
                { }
            }
            return base64String;
        }
    }
}