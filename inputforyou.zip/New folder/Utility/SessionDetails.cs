﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebTool.BAL;
using WebTool.Models;
namespace DocflowWebTool.Utility
{
    public static class SessionDetails
    {
        public static string UserName
        {
            get
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null && HttpContext.Current.Session["LoggedUser"] is UserDTO)
                {
                    UserDTO _loggedUser = HttpContext.Current.Session["LoggedUser"] as UserDTO;
                    return _loggedUser.UserName;
                }
                return string.Empty;
            }
        }

        public static long UserId
        {
            get
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null && HttpContext.Current.Session["LoggedUser"] is UserDTO)
                {
                    UserDTO _loggedUser = HttpContext.Current.Session["LoggedUser"] as UserDTO;
                    return _loggedUser.UserId;
                }
                return 0;
            }
        }

        public static string UserType
        {
            get
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null && HttpContext.Current.Session["LoggedUser"] is UserDTO)
                {
                    UserDTO _loggedUser = HttpContext.Current.Session["LoggedUser"] as UserDTO;
                    return _loggedUser.UserType;
                }
                return string.Empty;
            }
        }

        public static string ProfilePhotoPath
        {
            get
            {
                if (HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null && HttpContext.Current.Session["LoggedUser"] is UserDTO)
                {
                    UserDTO _loggedUser = HttpContext.Current.Session["LoggedUser"] as UserDTO;
                    //return _loggedUser.ProfilePhotoPath;
                    string _profilePhotoPath = System.IO.Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, "Images", "ProfilePicture", "DocflowWebTool", SessionDetails.UserId.ToString(), ".jpg");
                    return HttpContext.Current.Request.MapPath(string.Format("~Images/ProfilePicture/DocflowWebTool/{0}.jpg", ((System.IO.File.Exists(_profilePhotoPath) ? SessionDetails.UserId : 0))));
                }
                return string.Empty;
            }
        }

        public static class SecondLoginInfo
        {
            public static string ProjectName
            {
                get
                {
                    if (HttpContext.Current.Session != null && HttpContext.Current.Session["SecondLoginModel"] != null && HttpContext.Current.Session["SecondLoginModel"] is SecondLoginModel)
                    {
                       SecondLoginModel _loggedUser = HttpContext.Current.Session["SecondLoginModel"] as SecondLoginModel;
                        return _loggedUser.ProjectName;
                    }
                    return string.Empty;
                }
            }

            public static string Operator
            {
                get
                {
                    if (HttpContext.Current.Session != null && HttpContext.Current.Session["SecondLoginModel"] != null && HttpContext.Current.Session["SecondLoginModel"] is SecondLoginModel)
                    {
                        SecondLoginModel _loggedUser = HttpContext.Current.Session["SecondLoginModel"] as SecondLoginModel;
                        return _loggedUser.Operator;
                    }
                    return string.Empty;
                }
            }
        }
    }

    public static class ProjectDetails
    {
        private static ProjectInfo m_project = new ProjectInfo();
        public static ProjectInfo ProjectInfo
        {
            get { return m_project; }
        }
    }

    public class ProjectInfo
    {
        public WebTool.Models.ProjectDTO this[string projectName]
        {
            //get
            //{
            //    Models.ProjectDTO foundProject = null;
            //    if (!string.IsNullOrEmpty(projectName) && HttpContext.Current.Session != null && HttpContext.Current.Session["LoggedUser"] != null && HttpContext.Current.Session["LoggedUser"] is Models.UserDTO)
            //    {
            //        Models.UserDTO _loggedUser = HttpContext.Current.Session["LoggedUser"] as Models.UserDTO;
            //        if (_loggedUser.Projects != null && _loggedUser.Projects.Count > 0)
            //        {
            //            foundProject = _loggedUser.Projects.Find(p => p.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
            //        }
            //        if (foundProject == null)
            //        {
            //            throw new Exception(string.Format("{0} project doesn't exist.", projectName));
            //        }
            //    }
            //    return foundProject;
            //}
            get
            {
                ProjectBAL obj = new ProjectBAL();
                var foundProject = obj.GetProjectDetailsByName(projectName);
                if (foundProject == null)
                {
                    throw new Exception("No project exist with name " + projectName);
                }
                return foundProject;
            }
        }
    }

    public class ApplicationConfig
    {
        public static bool IsBarcodeEnable
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["IsBarcodeEnable"] != null && System.Configuration.ConfigurationManager.AppSettings["IsBarcodeEnable"] == "1";
            }
        }
    }
}