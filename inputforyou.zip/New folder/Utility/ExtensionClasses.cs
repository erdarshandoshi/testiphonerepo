﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.Models;

namespace DocflowWebTool.Utility
{
    public static class ActiveLinkHelper
    {
        public static MvcHtmlString ListItemAction(this HtmlHelper helper, string name, string actionName, string controllerName, string iconClass = "")
        {
            var currentControllerName = (string)helper.ViewContext.RouteData.Values["controller"];
            var currentActionName = (string)helper.ViewContext.RouteData.Values["action"];
            var sb = new System.Text.StringBuilder();

            //bool isSelected = currentControllerName.Equals(controllerName, StringComparison.CurrentCultureIgnoreCase) && currentActionName.Equals(actionName, StringComparison.CurrentCultureIgnoreCase);
            bool isSelected = currentControllerName.Equals(controllerName, StringComparison.CurrentCultureIgnoreCase);

            sb.AppendFormat("<li{0}", (isSelected ? " class=\"start active\">" : ">"));
            var url = new UrlHelper(HttpContext.Current.Request.RequestContext);
            sb.AppendFormat("<a href=\"{0}\">", url.Action(actionName, controllerName));

            if (!string.IsNullOrEmpty(iconClass))
            {
                sb.AppendFormat("<i class=\"{0}\"></i>", iconClass);
            }

            sb.AppendFormat("<span class=\"title\">{0}</span>", name);

            if (isSelected)
            {
                sb.AppendFormat("<span class=\"selected\"> </span>");
            }

            sb.Append("</a></li>");
            return new MvcHtmlString(sb.ToString().Trim());
        }

        public static MvcHtmlString ListSubItemAction(this HtmlHelper helper, ProjectDTO item, string actionName, string controllerName)
        {
            var currentControllerName = (string)helper.ViewContext.RouteData.Values["controller"];
            var currentActionName = (string)helper.ViewContext.RouteData.Values["action"];
            var sb = new System.Text.StringBuilder();

            //bool isSelected = currentControllerName.Equals(controllerName, StringComparison.CurrentCultureIgnoreCase) && currentActionName.Equals(actionName, StringComparison.CurrentCultureIgnoreCase);

            if (currentActionName == "PickingList")
            {
                if (HttpContext.Current.Request.Url.Query.Contains(item.ProjectName))
                {
                    sb.AppendFormat("<li class='open'>");
                    sb.AppendFormat("<a id='clicktoopen' href=\"javascript:;\">");
                }
                else
                {
                    sb.AppendFormat("<li>");
                    sb.AppendFormat("<a href=\"javascript:;\">");
                }
            }
            else
            {
                sb.AppendFormat("<li>");
                sb.AppendFormat("<a href=\"javascript:;\">");
            }
            var url = new UrlHelper(HttpContext.Current.Request.RequestContext);


            if (!string.IsNullOrEmpty(item.IconClass))
            {
                sb.AppendFormat("<i class=\"{0}\"></i>", item.IconClass);
            }

            sb.AppendFormat("{0}", item.ProjectName);

            if (item.Modules.Count > 0)
            {
                sb.AppendFormat("<span class=\"arrow\"></span>");
            }
            if (HttpContext.Current.Request.Url.Query.Contains(item.ProjectName))
            {
                sb.AppendFormat("<span class=\"selected\"> </span>");
            }

            sb.Append("</a>");
            if (item.Modules.Count > 0)
            {
                sb.AppendFormat("<ul class=\"sub-menu\">");

                foreach (var module in item.Modules)
                {
                    sb.AppendFormat("<li {0}><a href=\"{1}\">", ((HttpContext.Current.Request.Url.Query.Contains(item.ProjectName)) ? "class='active'" : ""), url.Action(module.ActionName, module.ControllerName, new { ProjectName = item.ProjectName })); // give link here
                    if (!string.IsNullOrEmpty(module.IconClass))
                    {
                        sb.AppendFormat("<i class=\"{0}\"></i>", module.IconClass);
                    }
                    sb.AppendFormat("{0}</a></li>", module.ModuleName);
                }
                sb.AppendFormat("</ul>");
            }

            sb.Append("</li>");

            string _mvcHtmlString = sb.ToString().Trim();
            return new MvcHtmlString(_mvcHtmlString);
        }
    }

    //public static class DyExtension
    //{
    //    public static void AddProperty(ExpandoObject expando, string propertyName, object propertyValue)
    //    {
    //        var expandoDict = expando as IDictionary<string, object>;
    //        if (expandoDict.ContainsKey(propertyName))
    //            expandoDict[propertyName] = propertyValue;
    //        else
    //            expandoDict.Add(propertyName, propertyValue);
    //    }
    //}
}