﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using System.Data.SqlClient;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class BoxListBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public BoxListBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public BoxListBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        //internal List<TransportDTO> GetBoxDetails(string boxBatch, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting, ref long totalRecord)
        public List<BoxListDTO> GetAtelierIFYViewList(string boxNo, string preparatorName, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            List<BoxListDTO> objList = new List<BoxListDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@PreparatorName", preparatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_GetAtelierIFYViewList", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        BoxListDTO obj = new BoxListDTO();
                        obj.RNo = Convert.ToString(item["RNO"]);
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.BoxNo = Convert.ToString(item["BoxNo"]);
                        obj.TransportDate = Convert.ToString(item["TransportDate"]);
                        obj.Destination = Convert.ToString(item["Destination"]);
                        obj.ReceptionDate = Convert.ToString(item["ReceptionDate"]);
                        obj.PreparatorName = Convert.ToString(item["PreparatorName"]);
                        obj.PreparationStartDate = Convert.ToString(item["PreparationStartDate"]);
                        obj.PrepartionEndDate = Convert.ToString(item["PrepartionEndDate"]);
                        obj.BoxStatus = Convert.ToString(item["BoxStatus"]);
                        obj.BackToIfyStatus = Convert.ToString(item["BackToIfyStatus"]);
                        objList.Add(obj);
                    }
                    //if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    //{
                    //    totalRecord = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    //}
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        public bool UpdateAtelierReceptionBackToIfyStatus(AtelierReceptionDTO record)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", record.Id);
                paraList.AddQueryParameter("@BackToIfyStatus", record.BackToIfyStatus);
                m_db.ExecuteNonSPQuery("dbo.IFY_Webtool_UpdateAtelierBackToIfyStatus", paraList, 300);
                return true;
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }


        public List<BoxListDTO> GetAtelierPartnerViewList(string boxNo, string batch, string preparatorName, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            List<BoxListDTO> objList = new List<BoxListDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@Batch", batch);
                paraList.AddQueryParameter("@PreparatorName", preparatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_GetAtelierPartnerViewList", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        BoxListDTO obj = new BoxListDTO();
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.RNo = Convert.ToString(item["RNO"]);
                        obj.BoxNo = Convert.ToString(item["BoxNo"]);
                        obj.Batch = Convert.ToString(item["Batch"]);
                        obj.PaletteNumber = Convert.ToString(item["PaletteNumber"]);
                        obj.ReceptionDate = Convert.ToString(item["ReceptionDate"]);
                        obj.ReceptionName = Convert.ToString(item["ReceptionName"]);
                        obj.PreparatorName = Convert.ToString(item["PreparatorName"]);
                        obj.PreparationStartDate = Convert.ToString(item["PreparationStartDate"]);
                        obj.PrepartionEndDate = Convert.ToString(item["PrepartionEndDate"]);
                        obj.ScanningDate = Convert.ToString(item["ScanningDate"]);
                        obj.IntegrationDate = Convert.ToString(item["IntegratedDate"]);
                        obj.BoxStatus = Convert.ToString(item["BoxStatus"]);
                        obj.BackToIfyStatus = Convert.ToString(item["BackToIfyStatus"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
             Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        public List<TransportDestinationDTO> GetAllTransportDestination()
        {
            List<TransportDestinationDTO> objPartners = new List<TransportDestinationDTO>();
            DataSet ds = null;

            try
            {
                ds = m_db.ExecuteDataSetForProcedure("IFY_WEBTOOL_GetTransportDestinationDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        TransportDestinationDTO obj = new TransportDestinationDTO();
                        obj.Destination = Convert.ToString(item["Destination"]);
                        objPartners.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            objPartners = objPartners.OrderBy(p => p.Destination).ToList();
            return objPartners;
        }


        public bool AddTransportDetails(AtelierTransportModel item, string operators, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxBatch", item.BoxBatch);
                paraList.AddQueryParameter("@Batch", item.BoxBatch);
                paraList.AddQueryParameter("@Destination", item.Destination);
                paraList.AddQueryParameter("@OperatorName", operators);
                paraList.AddQueryParameter("@UserId", userId);

                int result = m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_AddTransportBox", paraList);
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
        }



        public List<AssignPaletteDTO> GetPaletteWiseBoxList(string paletteNumber, string paletteStatus)
        {

            List<AssignPaletteDTO> objList = new List<AssignPaletteDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@PaletteNumber", paletteNumber);
                paraList.AddQueryParameter("@PaletteStatus", paletteStatus);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_PaletteWiseBoxList", paraList, 300);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        AssignPaletteDTO obj = new AssignPaletteDTO();
                        obj.BoxId = Convert.ToString(item["BoxId"]);
                        obj.PaletteNumber = Convert.ToString(item["PaletteNumber"]);
                        obj.PaletteStatus = Convert.ToString(item["PaletteStatus"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        #endregion

    }
}