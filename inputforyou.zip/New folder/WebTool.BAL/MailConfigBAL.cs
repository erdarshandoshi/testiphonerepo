﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using System.Data;
using DocflowWebTool.Utility;
using WebTool.Models;

namespace WebTool.BAL
{
    public class MailConfigBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public MailConfigBAL()
        {
            string _conStr = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(_conStr);
        }
        public MailConfigBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion



        public MailProfile GetMailProfile(string profileName)
        {
            MailProfile obj = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProfileName", profileName);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.Mail_GetMailProfile", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var item = ds.Tables[0].Rows[0];
                    obj = new MailProfile(profileName, Convert.ToString(item["Protocol"]), Convert.ToString(item["MailHost"]), Convert.ToInt32(item["Port"]), Convert.ToString(item["EmailId"]), Convert.ToString(item["Password"]), Convert.ToBoolean(item["EnableSSL"]));
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                //throw ex;
            }
            return obj;
        }

        public MailTemplate GetMailTemplate(string templateName)
        {
            MailTemplate obj = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@TemplateName", templateName);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.Mail_GetMailTemplate", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var item = ds.Tables[0].Rows[0];
                    obj = new MailTemplate(templateName, Convert.ToString(item["MailTemplate"]));
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow mItem in ds.Tables[1].Rows)
                        {
                            if (Convert.ToBoolean(mItem["IsCC"]))
                            {
                                obj.CcRecipient.Add(Convert.ToString(mItem["MailRecipient"]));
                            }
                            else
                            {
                                obj.ToRecipient.Add(Convert.ToString(mItem["MailRecipient"]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                //throw ex;
            }
            return obj;
        }
    }
}