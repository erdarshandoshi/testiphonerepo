﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class ProjectBAL
    {

        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public ProjectBAL()
        {
            string _conStr = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(_conStr);
        }
        public ProjectBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Properties
        public string ConnectionString { get; set; }
        public string Password { get; set; }
        public string UserName { get; set; }
        #endregion

        #region Methods
        public List<ProcessDTO> GetAllProcess()
        {
            List<ProcessDTO> objProcesses = new List<ProcessDTO>();
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.GetAllProcess");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        var _obj = new ProcessDTO();
                        _obj.Id = Convert.ToInt32(item["Id"]);
                        _obj.ProcessName = Convert.ToString(item["ProcessName"]);
                        objProcesses.Add(_obj);
                        _obj.SortOrder = objProcesses.Count;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            objProcesses = objProcesses.OrderBy(x => x.SortOrder).ToList();
            return objProcesses;
        }

        public InputInboundEmailJobDTO GetInsertedEmailDetails(string emailId, string jobName, string mailHost)
        {
            try
            {
                InputInboundEmailJobDTO obj = null;
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@JobName", jobName);
                paraList.AddQueryParameter("@MailHost", mailHost);
                paraList.AddQueryParameter("@EmailId", emailId);
                DataSet ds = m_db.ExecuteDataSetForProcedure("GetInsertedEmailDetails", paraList, 300);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    obj = new InputInboundEmailJobDTO();
                    obj.Id = Convert.ToInt32(ds.Tables[0].Rows[0]["Id"]);
                    obj.JobName = Convert.ToString(ds.Tables[0].Rows[0]["JobName"]);
                    obj.MailHost = Convert.ToString(ds.Tables[0].Rows[0]["MailHost"]);
                    obj.EmailId = Convert.ToString(ds.Tables[0].Rows[0]["EmailId"]);
                    obj.EmailPassword = Convert.ToString(ds.Tables[0].Rows[0]["Password"]);
                    obj.ProjectId = Convert.ToInt32(ds.Tables[0].Rows[0]["FK_ProjectId"]);
                }
                return obj;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public InputInboundFtpSftpDTO GetInsertedFTPSFTPDetails(string protocol, string protocolEncryption, string url, string userName)
        {
            try
            {
                InputInboundFtpSftpDTO obj = null;
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Protocol", protocol);
                paraList.AddQueryParameter("@ProtocolEncryption", protocolEncryption);
                paraList.AddQueryParameter("@Url", url);
                paraList.AddQueryParameter("@UserName", userName);
                DataSet ds = m_db.ExecuteDataSetForProcedure("GetInsertedFTPSFTPDetails", paraList, 300);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    obj = new InputInboundFtpSftpDTO();
                    obj.Id = Convert.ToInt32(ds.Tables[0].Rows[0]["Id"]);
                    obj.Protocol = Convert.ToString(ds.Tables[0].Rows[0]["Protocol"]);
                    obj.Encryption = Convert.ToString(ds.Tables[0].Rows[0]["ProtocolEncryption"]);
                    obj.Port = Convert.ToInt32(ds.Tables[0].Rows[0]["Port"]);
                    obj.Host = Convert.ToString(ds.Tables[0].Rows[0]["Url"]);
                    obj.FTPUserName = Convert.ToString(ds.Tables[0].Rows[0]["UserName"]);
                    obj.FTPPassword = Convert.ToString(ds.Tables[0].Rows[0]["Password"]);
                    obj.FTPPath = Convert.ToString(ds.Tables[0].Rows[0]["Path"]);
                    obj.ProjectId = Convert.ToInt32(ds.Tables[0].Rows[0]["FK_ProjectId"]);
                }
                return obj;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool InsertEmailDetails(List<InputInboundEmailJobDTO> _emailDetails, int ProjectId)
        {
            try
            {
                int result = 0;
                if (_emailDetails.Count > 0)
                {
                    for (int i = 0; i < _emailDetails.Count; i++)
                    {
                        HitechQueryParameter paraList = new HitechQueryParameter();
                        paraList.AddQueryParameter("@JobName", _emailDetails[i].JobName);
                        paraList.AddQueryParameter("@MailHost", _emailDetails[i].MailHost);
                        paraList.AddQueryParameter("@EmailId", _emailDetails[i].EmailId);
                        paraList.AddQueryParameter("@Password", _emailDetails[i].EmailPassword);
                        paraList.AddQueryParameter("@ProjectId", ProjectId);

                        result = m_db.ExecuteNonSPQuery("InsertEmailDetails", paraList, 300);
                    }
                }

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }

        public bool InsertFTPSFTPDetails(List<InputInboundFtpSftpDTO> _ftpSftpDetails, int ProjectId)
        {
            try
            {
                int result = 0;
                if (_ftpSftpDetails.Count > 0)
                {
                    for (int i = 0; i < _ftpSftpDetails.Count; i++)
                    {
                        HitechQueryParameter paraList = new HitechQueryParameter();
                        paraList.AddQueryParameter("@Protocol", _ftpSftpDetails[i].Protocol);
                        paraList.AddQueryParameter("@ProtocolEncryption", _ftpSftpDetails[i].Encryption);
                        paraList.AddQueryParameter("@Port", _ftpSftpDetails[i].Port);
                        paraList.AddQueryParameter("@URL", _ftpSftpDetails[i].Host);
                        paraList.AddQueryParameter("@UserName", _ftpSftpDetails[i].FTPUserName);
                        paraList.AddQueryParameter("@Password", _ftpSftpDetails[i].FTPPassword);
                        paraList.AddQueryParameter("@ProjectId", ProjectId);
                        paraList.AddQueryParameter("@IsInBoundDetails", 1);
                        result = m_db.ExecuteNonSPQuery("InsertFTPSFTPDetails", paraList, 300);
                    }
                }
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw;
            }
        }

        public bool InsertProjectProcessList(string ProcessId, int ProjectId, int ProcessOrder)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProcessId", ProcessId);
                paraList.AddQueryParameter("@ProjectId", ProjectId);
                paraList.AddQueryParameter("@ProcessOrder", ProcessOrder);
                int result = m_db.ExecuteNonSPQuery("InsertProjectProcessList", paraList, 300);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }

        public bool DeleteProjectProcessList(int ProcessId, int ProjectId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProcessId", ProcessId);
                paraList.AddQueryParameter("@ProjectId", ProjectId);
                int result = m_db.ExecuteNonSPQuery("DeleteProjectProcessList", paraList, 300);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }

        public bool InsertFTPSFTPDetailsOutBound(ProjectModel model, int ProjectId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Protocol", model.Protocol);
                paraList.AddQueryParameter("@ProtocolEncryption", model.ProtocolEncryption);
                paraList.AddQueryParameter("@Port", model.Port);
                paraList.AddQueryParameter("@URL", model.Url);
                paraList.AddQueryParameter("@UserName", model.UserName);
                paraList.AddQueryParameter("@Password", model.Password);
                paraList.AddQueryParameter("@ProjectId", ProjectId);
                paraList.AddQueryParameter("@IsInBoundDetails", model.IsInBoundDetails);
                int result = m_db.ExecuteNonSPQuery("InsertFTPSFTPDetails", paraList, 300);

                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }

        public int InsertProjectDetails(ProjectModel projectModel)
        {
            try
            {
                DateTime _ddate = new DateTime();
                string _dateFormat = "dd/MM/yyyy";
                if (projectModel.DevelopmentDate.Length == 10)
                {
                    if (DateTime.TryParseExact(projectModel.DevelopmentDate.Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ddate))
                    {
                        projectModel.DevelopmentDate = _ddate.ToString(_dateFormat);

                    }
                }

                DateTime _tdate = new DateTime();
                if (projectModel.TestingDate.Length == 10)
                {
                    if (DateTime.TryParseExact(projectModel.TestingDate.Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _tdate))
                    {
                        projectModel.TestingDate = _tdate.ToString(_dateFormat);
                    }
                }

                DateTime _ldate = new DateTime();
                if (projectModel.LiveDate.Length == 10)
                {
                    if (DateTime.TryParseExact(projectModel.LiveDate.Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ldate))
                    {
                        projectModel.LiveDate = _ldate.ToString(_dateFormat);
                    }
                }


                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProjectId", projectModel.Id);
                paraList.AddQueryParameter("@ProjectName", projectModel.ProjectName);
                paraList.AddQueryParameter("@CompanyName", projectModel.CompanyName);
                paraList.AddQueryParameter("@StartingLocation", projectModel.StartingLocation);
                paraList.AddQueryParameter("@PickingList", projectModel.IsPickingList);
                paraList.AddQueryParameter("@BoxStructure", projectModel.BoxStructure);
                paraList.AddQueryParameter("@BoxLength", projectModel.BoxLength);
                paraList.AddQueryParameter("@ScanningDPI", projectModel.ScanningDPI);
                paraList.AddQueryParameter("@PatchInData", projectModel.IsPatchInData);
                paraList.AddQueryParameter("@DevelopmentDate", _ddate);
                paraList.AddQueryParameter("@TestingDate", _tdate);
                paraList.AddQueryParameter("@LiveDate", _ldate);
                paraList.AddQueryParameter("@IsFtpSftpScan", projectModel.IsFtpSftpScan);
                paraList.AddQueryParameter("@PartnerId", projectModel.PartnerId);
                paraList.AddQueryParameter("@LogisticType1", projectModel.Box);
                paraList.AddQueryParameter("@LogisticType2", projectModel.BagBatchBox);
                paraList.AddQueryParameter("@LogisticType3", projectModel.BoxBatchBag);
                paraList.AddQueryParameter("@Datapath", projectModel.DataPath);
                paraList.AddQueryParameter("@ProductionPath", projectModel.ProductionPath);
                paraList.AddQueryParameter("@NetworkPath", projectModel.NetworkPath);
                paraList.AddQueryParameter("@IsScan", projectModel.InputInbound.IsScan);
                paraList.AddQueryParameter("@ProjectDescription", projectModel.ProjectDescription);

                System.Data.SqlClient.SqlParameter output = new System.Data.SqlClient.SqlParameter("@PId", SqlDbType.Int);
                output.Direction = ParameterDirection.Output;
                output.Value = 0;
                paraList.Add(output);

                int _result = m_db.ExecuteNonSPQuery("InsertProjectDetails", paraList, 300);
                int Pid = Convert.ToInt32(output.Value.ToString());
                if (Pid > 0)
                {
                    return Pid;
                }
                else
                {
                    return -1;
                }

            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }

        public ProjectDTO GetProjectDetailsById(int id)
        {
            ProjectDTO obj = new ProjectDTO();
            DataSet ds = null;

            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@id", id);
                ds = m_db.ExecuteDataSetForProcedure("GetAllProjectsById", paraList);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    obj.ProjectId = Convert.ToInt32(ds.Tables[0].Rows[0]["Id"]);
                    obj.ProjectName = Convert.ToString(ds.Tables[0].Rows[0]["ProjectName"]);
                    obj.CompanyName = Convert.ToString(ds.Tables[0].Rows[0]["CompanyName"]);
                    obj.BoxStructure = Convert.ToString(ds.Tables[0].Rows[0]["BoxStructure"]);
                    obj.BoxLength = Convert.ToString(ds.Tables[0].Rows[0]["BoxLength"]);
                    obj.StartingLocation = Convert.ToString(ds.Tables[0].Rows[0]["StartingLocation"]);
                    obj.IsPickingList = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPickingList"]);
                    obj.ScanDPI = Convert.ToString(ds.Tables[0].Rows[0]["ScanningDPI"]);
                    obj.IsPatchInData = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPatchInData"]);
                    obj.IsFtpSftpScan = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsFtpSftpScan"]);
                    obj.IsBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType1"]);
                    obj.IsBoxBatchBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType2"]);
                    obj.IsBagBatchBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType3"]);
                    obj.DataPath = Convert.ToString(ds.Tables[0].Rows[0]["DataPath"]);
                    obj.NetworkPath = Convert.ToString(ds.Tables[0].Rows[0]["NetworkPath"]);
                    obj.ProductionPath = Convert.ToString(ds.Tables[0].Rows[0]["ProductionPath"]);
                    //obj.Partner = Convert.ToString(ds.Tables[0].Rows[0]["Fk_Partner"]);
                    obj.DevelopMentDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["DevelopmentStartDate"]);
                    obj.TestingDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["TestDate"]);
                    obj.LiveDate = Convert.ToDateTime(ds.Tables[0].Rows[0]["LiveDate"]);
                    obj.ProjectStateId = Convert.ToInt16(ds.Tables[0].Rows[0]["ProjectState"]);
                    obj.ProjectDescription = Convert.ToString(ds.Tables[0].Rows[0]["ProjectDescription"]);
                }
                if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    obj.TransferProtocol = Convert.ToString(ds.Tables[1].Rows[0]["Protocol"]);
                    obj.TransferEncryption = Convert.ToString(ds.Tables[1].Rows[0]["ProtocolEncryption"]);
                    obj.TransferPort = Convert.ToInt32(ds.Tables[1].Rows[0]["Port"]);
                    obj.TransferHost = Convert.ToString(ds.Tables[1].Rows[0]["Url"]);
                    obj.TransferUsername = Convert.ToString(ds.Tables[1].Rows[0]["Username"]);
                    obj.TransferPassword = Convert.ToString(ds.Tables[1].Rows[0]["Password"]);
                }

                if (ds != null && ds.Tables.Count > 2 && ds.Tables[2].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[2].Rows)
                    {
                        Models.ProjectDocuments proDoc = new ProjectDocuments();
                        proDoc.Id = Convert.ToInt32(item["Id"]);
                        proDoc.DocName = Convert.ToString(item["DocName"]);
                        proDoc.DocSize = Convert.ToString(item["DocSize"]);
                        proDoc.ContentType = Convert.ToString(item["ContentType"]);
                        proDoc.CreatedDate = Convert.ToDateTime(item["CreatedDate"]);
                        obj.Documents.Add(proDoc);
                    }
                }
                /*Start Change by niyati*/
                if (ds != null && ds.Tables.Count > 3 && ds.Tables[3].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[3].Rows)
                    {
                        Models.ProjectPartners ProPartners = new ProjectPartners();
                        ProPartners.Id = Convert.ToInt32(item["Id"]);
                        ProPartners.PartnerId = Convert.ToInt32(item["FK_PartnerId"]);
                        ProPartners.IsPalleteRequiredOnReception = Convert.ToBoolean(item["IsPalleteRequiredOnReception"]);
                        ProPartners.IsPalleteRequiredOnTransport = Convert.ToBoolean(item["IsPalleteRequiredOnTransport"]);
                        ProPartners.PartnerName = Convert.ToString(item["PartnerName"]);
                        obj.ProjectScanPartners.Add(ProPartners);
                    }
                }
                /*End Change by niyati*/
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw;
            }

            return obj;

        }

        public List<ProjectDocuments> GetProjectDocumentsById(int id)
        {
            List<ProjectDocuments> objList = new List<ProjectDocuments>();
            HitechQueryParameter paraList = new HitechQueryParameter();
            paraList.AddQueryParameter("@id", id);
            DataSet ds = m_db.ExecuteDataSetForProcedure("GetProjectDocumentById", paraList);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    Models.ProjectDocuments proDoc = new ProjectDocuments();
                    proDoc.Id = Convert.ToInt32(item["Id"]);
                    proDoc.DocName = Convert.ToString(item["DocName"]);
                    proDoc.DocSize = Convert.ToString(item["DocSize"]);
                    proDoc.ContentType = Convert.ToString(item["ContentType"]);
                    proDoc.CreatedDate = Convert.ToDateTime(item["CreatedDate"]);
                    objList.Add(proDoc);
                }
            }
            return objList;
        }


        public List<ProcessFlowDTO> GetProcessDetailById(int projectId)
        {
            List<ProcessFlowDTO> _objList = new List<ProcessFlowDTO>();
            DataSet ds = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProjectId", projectId);
                ds = m_db.ExecuteDataSetForProcedure("GetAllProcessNameById", paraList);

                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    var obj = new ProcessFlowDTO();
                    obj.ProcessDetailId = Convert.ToInt32(item["Fk_ProcessId"]);
                    _objList.Add(obj);
                }

            }
            catch (Exception)
            {
                throw;
            }

            return _objList;
        }

        public InputInboundDTO GetInputInboundDetails(int projectId)
        {
            InputInboundDTO objResult = new InputInboundDTO();
            try
            {
                HitechQueryParameter _paraList = new HitechQueryParameter();
                _paraList.AddQueryParameter("@ProjectId", projectId);
                DataSet ds = m_db.ExecuteDataSetForProcedure("GetInputInboundDetails", _paraList);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    objResult.IsScan = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsScan"]);
                }

                if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                    {
                        InputInboundEmailJobDTO objEmailJob = new InputInboundEmailJobDTO();
                        objEmailJob.Id = Convert.ToInt32(ds.Tables[1].Rows[i]["Id"]);
                        objEmailJob.JobName = Convert.ToString(ds.Tables[1].Rows[i]["JobName"]);
                        objEmailJob.MailHost = Convert.ToString(ds.Tables[1].Rows[i]["MailHost"]);
                        objEmailJob.EmailId = Convert.ToString(ds.Tables[1].Rows[i]["EmailId"]);
                        objEmailJob.EmailPassword = Convert.ToString(ds.Tables[1].Rows[i]["Password"]);
                        objResult.EmailJobs.Add(objEmailJob);
                    }
                }

                if (ds != null && ds.Tables.Count > 2 && ds.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                    {
                        InputInboundFtpSftpDTO objFtpSftpJob = new InputInboundFtpSftpDTO();
                        objFtpSftpJob.Id = Convert.ToInt32(ds.Tables[2].Rows[i]["Id"]);
                        objFtpSftpJob.Protocol = Convert.ToString(ds.Tables[2].Rows[i]["Protocol"]);
                        objFtpSftpJob.Encryption = Convert.ToString(ds.Tables[2].Rows[i]["ProtocolEncryption"]);
                        objFtpSftpJob.Port = Convert.ToInt32(ds.Tables[2].Rows[i]["Port"]);
                        objFtpSftpJob.Host = Convert.ToString(ds.Tables[2].Rows[i]["Url"]);
                        objFtpSftpJob.FTPUserName = Convert.ToString(ds.Tables[2].Rows[i]["UserName"]);
                        objFtpSftpJob.FTPPassword = Convert.ToString(ds.Tables[2].Rows[i]["Password"]);
                        objResult.FtpSftpJobs.Add(objFtpSftpJob);
                    }
                }

            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw;
            }
            return objResult;
        }

        public List<ProcessFlowDTO> GetAllProcessDetails()
        {
            ConnectionString = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            List<ProcessFlowDTO> _objlist = new List<ProcessFlowDTO>();
            m_db = new DBManager(ConnectionString);
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("GetAllProcessDetails");
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    var obj = new ProcessFlowDTO();
                    obj.ProcessGroupName = Convert.ToString(item["Groupname"]);
                    obj.ProcessDetailName = Convert.ToString(item["ProcessName"]);
                    obj.ProcessDetailId = Convert.ToInt32(item["ProcessFlowId"]);
                    _objlist.Add(obj);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
            return _objlist;
        }

        public List<DashboardDTO> GetProjectDashBoardDetails()
        {
            List<DashboardDTO> objList = new List<DashboardDTO>();
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.GetProjectDashBoardDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        var _obj = new DashboardDTO();
                        _obj.ProjectId = Convert.ToInt32(item["Id"]);
                        _obj.ProjectName = Convert.ToString(item["ProjectName"]);
                        _obj.ProjectURL = Convert.ToString(item["ProjectURL"]);
                        _obj.CompanyName = Convert.ToString(item["CompanyName"]);
                        _obj.StartingLocation = Convert.ToString(item["StartingLocation"]);
                        _obj.WebSiteUrl = Convert.ToString(item["WebSiteUrl"]);
                        _obj.ProjectLogoPath = Convert.ToString(item["ProjectLogoPath"]);
                        _obj.IsPickingList = Convert.ToBoolean(item["IsPickingList"]);
                        _obj.MailInput = Convert.ToInt32(item["MailInput"]);
                        _obj.FtpSftpInput = Convert.ToInt32(item["FtpSftpInput"]);
                        _obj.Logistic = Convert.ToBoolean(item["LogisticType1"]) ? "Box" : (Convert.ToBoolean(item["LogisticType2"]) ? "Box-Batch-Box" : "Bag-Batch-Box");

                        if (item["LiveDate"] != DBNull.Value)
                        {
                            _obj.LiveDate = Convert.ToDateTime(item["LiveDate"]);
                        }
                        _obj.ProjectDescription = Convert.ToString(item["ProjectDescription"]);
                        /*start change by niyati*/
                        _obj.ProjectStateId = Convert.ToInt16(item["ProjectState"]);
                        /*end change by niyati*/
                        objList.Add(_obj);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objList;
        }


        public ProjectDTO GetProjectDetailsByName(string projectName)
        {
            ProjectDTO obj = null;
            int projectLength = 0;
            if (projectName != null && projectName != "")
            {
                projectLength = projectName.Length;
            }
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProjectName", projectName);
                DataSet ds = m_db.ExecuteDataSetForProcedure("GetProjectByName", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    obj = new ProjectDTO();
                    obj.ProjectConnectionString = Convert.ToString(ds.Tables[0].Rows[0]["ConnectionStr"]);
                    obj.ProjectId = Convert.ToInt32(ds.Tables[0].Rows[0]["Id"]);
                    obj.ProjectName = Convert.ToString(ds.Tables[0].Rows[0]["ProjectName"]);
                    obj.CompanyName = Convert.ToString(ds.Tables[0].Rows[0]["CompanyName"]);
                    obj.BoxStructure = Convert.ToString(ds.Tables[0].Rows[0]["BoxStructure"]);
                    obj.IsProjectNameInBarcode = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsProjectNameInBarcode"]);
                    if (obj.IsProjectNameInBarcode)
                    {
                        obj.BoxLength = Convert.ToString(projectLength + Convert.ToInt32(ds.Tables[0].Rows[0]["BoxLength"]));
                    }
                    else
                    {
                        obj.BoxLength = Convert.ToString(ds.Tables[0].Rows[0]["BoxLength"]);
                    }
                    obj.StartingLocation = Convert.ToString(ds.Tables[0].Rows[0]["StartingLocation"]);
                    obj.IsPickingList = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPickingList"]);
                    obj.ScanDPI = Convert.ToString(ds.Tables[0].Rows[0]["ScanningDPI"]);
                    obj.IsPatchInData = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsPatchInData"]);
                    obj.IsFtpSftpScan = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsFtpSftpScan"]);
                    obj.IsBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType1"]);
                    obj.IsBoxBatchBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType2"]);
                    obj.IsBagBatchBox = Convert.ToBoolean(ds.Tables[0].Rows[0]["LogisticType3"]);
                    obj.DataPath = Convert.ToString(ds.Tables[0].Rows[0]["DataPath"]);
                    obj.NetworkPath = Convert.ToString(ds.Tables[0].Rows[0]["NetworkPath"]);
                    obj.ProductionPath = Convert.ToString(ds.Tables[0].Rows[0]["ProductionPath"]);
                    //obj.Partner = Convert.ToString(ds.Tables[0].Rows[0]["Fk_Partner"]);

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
            return obj;
        }
        #endregion

        public bool IsProjectExist(string ProjectName)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProjectName", ProjectName);
                return (Convert.ToInt32(m_db.ExecuteScalerForProcedure("dbo.IsProjectExist", paraList)) == 0);
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }
        }

        #region Delete EMail and FTPSFTP

        public void DeleteEmailById(string emailId)
        {
            string[] _emailId;
            try
            {
                _emailId = emailId.Split(',');
                for (int i = 0; i < _emailId.Count(); i++)
                {
                    HitechQueryParameter paraList = new HitechQueryParameter();
                    paraList.AddQueryParameter("@EmailId", _emailId[i]);
                    m_db.ExecuteNonSPQuery("DeleteEmailById", paraList, 300);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteFtpSftpById(string ftpSftpId)
        {
            try
            {
                string[] _ftpSftpId;
                _ftpSftpId = ftpSftpId.Split(',');
                for (int i = 0; i < _ftpSftpId.Count(); i++)
                {
                    HitechQueryParameter paraList = new HitechQueryParameter();
                    paraList.AddQueryParameter("@FtpSftpId", _ftpSftpId[i]);
                    m_db.ExecuteNonSPQuery("DeleteFtpSftpById", paraList, 300);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteProjectDocumentById(string projectIds)
        {
            try
            {
                string[] _projectDocId;
                _projectDocId = projectIds.Split(',');
                for (int i = 0; i < _projectDocId.Length; i++)
                {
                    HitechQueryParameter paraList = new HitechQueryParameter();
                    paraList.AddQueryParameter("@Id", _projectDocId[i]);
                    m_db.ExecuteNonSPQuery("DeleteProjectDocumentById", paraList, 300);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        public bool InsertUpdateProjectDocument(ProjectDocuments doc)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@DocId", doc.Id, SqlDbType.Int, ParameterDirection.InputOutput);
                paraList.AddQueryParameter("@ProjectId", doc.ProjectId);
                paraList.AddQueryParameter("@DocName", doc.DocName);
                //paraList.AddQueryParameter("@DocPath", doc.DocPath);
                paraList.AddQueryParameter("@DocSize", doc.DocSize);
                paraList.AddQueryParameter("@ContentType", doc.ContentType);
                m_db.ExecuteNonSPQuery("InsertUpdateProjectDocument", paraList, 300);
                if (doc.Id <= 0)
                {
                    doc.Id = Convert.ToInt32(paraList.Find(p => p.ParameterName == "@DocId").Value);
                }

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*Start Change By Niyati*/
        public bool InsertPartnerDetails(List<ProjectPartners> listprojectpartners, int Pid)
        {
            try
            {
                #region Delete record if required...
                string _newSelectedPartnerIds = string.Empty;
                listprojectpartners.ForEach(p => _newSelectedPartnerIds += (_newSelectedPartnerIds == string.Empty ? p.PartnerId.ToString() : "," + p.PartnerId));
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@ProjectId", Pid);
                paraList.AddQueryParameter("@PartnerIds", _newSelectedPartnerIds);
                m_db.ExecuteNonSPQuery("DeletePartnerDetails", paraList);
                #endregion



                int result = 0;
                if (listprojectpartners.Count > 0)
                {
                    for (int i = 0; i < listprojectpartners.Count; i++)
                    {
                        paraList = new HitechQueryParameter();
                        paraList.AddQueryParameter("@IsPalleteRequiredOnReception", listprojectpartners[i].IsPalleteRequiredOnReception);
                        paraList.AddQueryParameter("@IsPalleteRequiredOnTransport", listprojectpartners[i].IsPalleteRequiredOnTransport);
                        paraList.AddQueryParameter("@PartnerId", listprojectpartners[i].PartnerId);
                        paraList.AddQueryParameter("@ProjectId", Pid);

                        result = m_db.ExecuteNonSPQuery("InsertPartnerDetails", paraList);
                    }
                }
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw;
            }
        }
        /*End Change By Niyati*/
    }
}