﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;

namespace WebTool.BAL
{
    public class PreparationBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public PreparationBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public PreparationBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        public List<PreparationDTO> GetPreparationBoxDetails(string boxBatch, string operatorName, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting, ref long totalRecord)
        {
            List<PreparationDTO> objList = new List<PreparationDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxBatch", boxBatch);
                //paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_WEBTOOL_GetPreparation", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        PreparationDTO obj = new PreparationDTO();
                        obj.PreparationId = Convert.ToInt32(item["PreparationId"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxBatch = Convert.ToString(item["BoxBatch"]);
                        obj.StartDate = Convert.ToString(item["StartDate"]);
                        obj.EndDate = Convert.ToString(item["EndDate"]);
                        obj.PreparatorName = Convert.ToString(item["OperatorName"]);
                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        totalRecord = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }
        #endregion

    }
}