﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;



namespace WebTool.BAL
{
    public class PreparatorBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public PreparatorBAL()
        {
            string _conStr = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(_conStr);
        }
        public PreparatorBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        public bool InsertUpdatePreparatorRecord(PreparatorModel item)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", item.UserId);
                paraList.AddQueryParameter("@PartnerId", item.PartnerId);
                paraList.AddQueryParameter("@PreparatorName", item.UserName);
                paraList.AddQueryParameter("@Location", item.Location);
                paraList.AddQueryParameter("@EmailId", item.EmailId);
                paraList.AddQueryParameter("@IsActive", item.IsActive);
                m_db.ExecuteNonSPQuery("dbo.InsertUpdatePreparatorDetails", paraList);
            }
            catch (Exception ex)
            {
             Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }
        #endregion

        public PreparatorModel GetPreparatorDetailById(int Id)
        {
            PreparatorModel obj = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", Id);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetPreparatorDetailById", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var item = ds.Tables[0].Rows[0];
                    obj = new PreparatorModel();
                    obj.PartnerId = Convert.ToInt64(item["PartnerId"]);
                    obj.PartnerName = Convert.ToString(item["PartnerName"]);
                    obj.UserId = Convert.ToInt64(item["UserId"]);
                    obj.UserName = Convert.ToString(item["UserName"]);
                    obj.Location = Convert.ToString(item["Location"]);
                    obj.EmailId = Convert.ToString(item["EmailId"]);
                    obj.IsActive = Convert.ToBoolean(item["IsActive"]);
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return obj;
        }

        public List<PreparatorModel> GetAllPreparators()
        {
            List<PreparatorModel> objList = new List<PreparatorModel>();
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("GetAllPreparators");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        PreparatorModel obj = new PreparatorModel();
                        obj.UserId = Convert.ToInt64(item["UserId"]);
                        obj.UserName = Convert.ToString(item["UserName"]);
                        //obj.FirstName = Convert.ToString(item["FirstName"]);
                        //obj.LastName = Convert.ToString(item["LastName"]);
                        obj.PartnerId = Convert.ToInt32(item["PartnerId"]);
                        obj.PartnerName = Convert.ToString(item["PartnerName"]);
                        obj.Location = Convert.ToString(item["Location"]);
                        obj.EmailId = Convert.ToString(item["EmailId"]);
                        obj.IsActive = Convert.ToBoolean(item["IsActive"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            objList = objList.OrderBy(p => p.UserName).ToList();
            return objList;
        }

    }
}