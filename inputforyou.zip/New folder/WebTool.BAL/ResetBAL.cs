﻿using WebTool.Models;
using HitechDAO;
using System;
using System.Collections.Generic;
using System.Data;

namespace WebTool.BAL
{
    public class ResetBAL
    {
        #region Fields
        DBManager m_db = null;
        private string p;
        #endregion
        #region Constructor
        public ResetBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public ResetBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
        }
        #endregion



        public List<Models.ResetDTO> ResetList(string Box, string Folder, string Status)
        {
            try
            {
                List<ResetDTO> objResetlst = new List<ResetDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@boxId", Box);
                paralist.AddQueryParameter("@folderId", Folder);
                paralist.AddQueryParameter("@status", Status);

                ds = m_db.ExecuteDataSetForProcedure("dbo.FolderReset_GetFolderList", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        ResetDTO objresetDTO = new ResetDTO();
                        objresetDTO.Id = Convert.ToInt32(item["cifId"]);
                        objresetDTO.Box = Convert.ToString(item["BoxNo"]);
                        objresetDTO.Folder = Convert.ToString(item["FolderNo"]);
                        objresetDTO.Status = Convert.ToInt32(item["Status"]);
                        objResetlst.Add(objresetDTO);
                    }

                }
                return objResetlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<StatusDTO> GetStatus(string projectName)
        {
            try
            {

                List<StatusDTO> objStatusDTO = new List<StatusDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@isUnderProcessFetch", false);
                DataSet ds = null;
                ds = m_db.ExecuteDataSetForProcedure("dbo.FolderReset_GetFolderStatus", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        StatusDTO obj = new StatusDTO();
                        obj.Status = Convert.ToString(item["statusName"]);
                        obj.StatusId = Convert.ToInt32(item["status"]);
                        objStatusDTO.Add(obj);
                    }
                }
                return objStatusDTO;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<ReasonDTO> GetReason(string projectName)
        {

            try
            {
                List<ReasonDTO> objList = new List<ReasonDTO>();
                HitechQueryParameter param = new HitechQueryParameter();
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.FolderReset_RetrieveFolderResetReasons", param);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    objList = new List<ReasonDTO>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        ReasonDTO obj = new ReasonDTO();
                        obj.ReasonId = Convert.ToInt32(row["ResetReasonID"]);
                        obj.Reason = Convert.ToString(row["ResetReason"]);
                        objList.Add(obj);
                    }
                }
                return objList;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<ResetStatusDTO> GetResetStatus(string projectName, int CurrentStatus)
        {
            try
            {
                List<ResetStatusDTO> objResetStatusDTO = new List<ResetStatusDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@isUnderProcessFetch", false);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.FolderReset_GetFolderStatus", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {

                        int itemStatus = Convert.ToInt32(item["status"]);
                        if (CurrentStatus > 20) CurrentStatus = CurrentStatus - 20;
                        if (itemStatus <= CurrentStatus)
                        {
                            objResetStatusDTO.Add(new ResetStatusDTO
                            {
                                // id = Convert.ToInt32(item["id"]),
                                statusName = Convert.ToString(item["statusName"]),
                                status = Convert.ToInt32(item["status"]),
                            });
                        }

                        //if (CurrentStatus > 20)
                        //{
                        //    CurrentStatus = CurrentStatus - 20;
                        //    objResetStatusDTO.Add(new ResetStatusDTO
                        //    {
                        //        id = Convert.ToInt32(item["id"]),
                        //        statusName = Convert.ToString(item["statusName"]),
                        //        status = Convert.ToInt32(item["status"]),
                        //    });
                        //}

                        //else if (itemStatus <= CurrentStatus)
                        //{
                        //    objResetStatusDTO.Add(new ResetStatusDTO
                        //    {
                        //        id = Convert.ToInt32(item["id"]),
                        //        statusName = Convert.ToString(item["statusName"]),
                        //        status = Convert.ToInt32(item["status"]),
                        //    });
                        //}


                    }
                }
                return objResetStatusDTO;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool InsertFolderResetLogReason(int CurrentStatus, int ResetToStatus, int Reason, string Remark, long founduserId, long cifId)
        {
            try
            {
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@fromStatus", CurrentStatus);
                paralist.AddQueryParameter("@toStatus", ResetToStatus);
                paralist.AddQueryParameter("@resetReasonId", Reason);
                paralist.AddQueryParameter("@resetRemarks", Remark);
                paralist.AddQueryParameter("@userId", founduserId);
                paralist.AddQueryParameter("@cifId", cifId);
                m_db.ExecuteNonSPQuery("dbo.FolderReset_InsertFolderResetLogReason", paralist);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public bool SetNewFolderStatus(string cifIds, int CurrentStatus, int ResetToStatus, bool ispreservedata, ref int ret, ref string msg)
        {
            try
            {
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@cifIds", cifIds);
                paralist.AddQueryParameter("@currentStatus", CurrentStatus);
                paralist.AddQueryParameter("@newStatus", ResetToStatus);
                paralist.AddQueryParameter("@isPreserveData", ispreservedata);
                paralist.AddQueryParameter("@ret", ret, SqlDbType.Int, ParameterDirection.InputOutput);
                paralist.AddQueryParameter("@msg", msg, SqlDbType.NVarChar, ParameterDirection.InputOutput);
                m_db.ExecuteNonSPQuery("dbo.FolderReset_SetNewFolderStatus", paralist);
                ret = Convert.ToInt32(paralist.Find(p => p.ParameterName == "@ret").Value);
                msg = Convert.ToString(paralist.Find(p => p.ParameterName == "@msg").Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
    }
}