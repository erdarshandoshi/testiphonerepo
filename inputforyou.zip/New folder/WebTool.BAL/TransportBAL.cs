﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class TransportBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public TransportBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public TransportBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        public List<TransportDTO> GetTransportBoxDetails(string boxBatch, string batch, string operatorName, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting, ref long totalRecord)
        {
            List<TransportDTO> objList = new List<TransportDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxBatch", boxBatch);
                paraList.AddQueryParameter("@Batch", batch);
                //paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_WEBTOOL_GetTransport", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        TransportDTO obj = new TransportDTO();
                        obj.TransportId = Convert.ToInt32(item["TransportId"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxBatch = Convert.ToString(item["BoxBatch"]);
                        obj.Batch = Convert.ToString(item["Batch"]);
                        obj.Destination = Convert.ToString(item["Destination"]);
                        obj.RecievedDate = Convert.ToString(item["RecievedDate"]);
                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        totalRecord = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        public List<TransportDestinationDTO> GetAllTransportDestination()
        {
            List<TransportDestinationDTO> objPartners = new List<TransportDestinationDTO>();
            DataSet ds = null;

            try
            {
                ds = m_db.ExecuteDataSetForProcedure("IFY_WEBTOOL_GetTransportDestinationDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        TransportDestinationDTO obj = new TransportDestinationDTO();
                        obj.Destination = Convert.ToString(item["Destination"]);
                        objPartners.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            objPartners = objPartners.OrderBy(p => p.Destination).ToList();
            return objPartners;
        }

        public bool AddTransportDetails(AtelierTransportModel item, string operators, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxBatch", item.BoxBatch);
                paraList.AddQueryParameter("@Batch", item.Batch);
                paraList.AddQueryParameter("@Destination", item.Destination);
                paraList.AddQueryParameter("@OperatorName", operators);
                paraList.AddQueryParameter("@UserId", userId);

                int result = m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_AddTransportBox", paraList);
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
              Logger.WriteLog(ex);
                throw ex;
            }
        }

        public bool DeleteTransportInfo(long trId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@TrasporterId", trId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_DeleteBoxTransportDetails", paraList, 300);
                return true;
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
        }

        #endregion

    }
}