﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;



namespace WebTool.BAL
{
    public class PickingListBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public PickingListBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public PickingListBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
            this.TotalRecordCount = 0;
        }
        #endregion

        #region Methods
        public PickingListResult GetPickingListRecords(int jtStartIndex, int jtPageSize, string jtSorting)
        {
            PickingListResult objPickingList = new PickingListResult();
            DataSet ds = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@StartIndex", jtStartIndex);
                paraList.AddQueryParameter("@PageSize", jtPageSize);
                paraList.AddQueryParameter("@Sorting", jtSorting);
                ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WebTool_GetPickingListRecords", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        var _obj = new PickingListDTO();
                        _obj.Id = Convert.ToInt32(item["Id"]);
                        _obj.No = Convert.ToInt32(item["RNO"]);
                        _obj.BoxNo = Convert.ToString(item["BoxNo"]);
                        _obj.Free1 = ds.Tables[0].Columns.Contains("free1") ? Convert.ToString(item["free1"]) : string.Empty;
                        _obj.Free2 = ds.Tables[0].Columns.Contains("free2") ? Convert.ToString(item["free2"]) : string.Empty;
                        _obj.Free3 = ds.Tables[0].Columns.Contains("free3") ? Convert.ToString(item["free3"]) : string.Empty;
                        _obj.Free4 = ds.Tables[0].Columns.Contains("free4") ? Convert.ToString(item["free4"]) : string.Empty;
                        _obj.Free5 = ds.Tables[0].Columns.Contains("free5") ? Convert.ToString(item["free5"]) : string.Empty;
                        _obj.Free6 = ds.Tables[0].Columns.Contains("free6") ? Convert.ToString(item["free6"]) : string.Empty;
                        _obj.Free7 = ds.Tables[0].Columns.Contains("free7") ? Convert.ToString(item["free7"]) : string.Empty;
                        _obj.Free8 = ds.Tables[0].Columns.Contains("free8") ? Convert.ToString(item["free8"]) : string.Empty;
                        _obj.Free9 = ds.Tables[0].Columns.Contains("free9") ? Convert.ToString(item["free9"]) : string.Empty;
                        _obj.Free10 = ds.Tables[0].Columns.Contains("free10") ? Convert.ToString(item["free10"]) : string.Empty;
                        _obj.Free11 = ds.Tables[0].Columns.Contains("free11") ? Convert.ToString(item["free11"]) : string.Empty;
                        _obj.Free12 = ds.Tables[0].Columns.Contains("free12") ? Convert.ToString(item["free12"]) : string.Empty;
                        _obj.Free13 = ds.Tables[0].Columns.Contains("free13") ? Convert.ToString(item["free13"]) : string.Empty;
                        _obj.Free14 = ds.Tables[0].Columns.Contains("free14") ? Convert.ToString(item["free14"]) : string.Empty;
                        _obj.Free15 = ds.Tables[0].Columns.Contains("free15") ? Convert.ToString(item["free15"]) : string.Empty;
                        _obj.Free16 = ds.Tables[0].Columns.Contains("free16") ? Convert.ToString(item["free16"]) : string.Empty;
                        _obj.Free17 = ds.Tables[0].Columns.Contains("free17") ? Convert.ToString(item["free17"]) : string.Empty;
                        _obj.Free18 = ds.Tables[0].Columns.Contains("free18") ? Convert.ToString(item["free18"]) : string.Empty;
                        _obj.Free19 = ds.Tables[0].Columns.Contains("free19") ? Convert.ToString(item["free19"]) : string.Empty;
                        _obj.Free20 = ds.Tables[0].Columns.Contains("free20") ? Convert.ToString(item["free20"]) : string.Empty;
                        objPickingList.Data.Add(_obj);
                    }
                    objPickingList.TotalRecordCount = Convert.ToInt32(ds.Tables[1].Rows[0][0]);

                    //ds.Tables[1] will contain columns/Header name
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    if (ex.InnerException.Message.StartsWith("Could not find stored procedure"))
                    {
                        objPickingList.CustomErrorMessage = "Database configuration related to this project is not done yet, Please contact IT team to create link.";
                    }
                }
                objPickingList.Error = ex;
            }
            return objPickingList;
        }



        public string CustomErrorMessage { get; set; }
        public Exception Error { get; set; }

        public List<string> GetPickingListHeader()
        {
            List<string> objHeaderList = new List<string>();
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WebTool_GetPickingListHeaders");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        objHeaderList.Add(Convert.ToString(item["Field"]));
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    if (ex.InnerException.Message.StartsWith("Could not find stored procedure"))
                    {
                        CustomErrorMessage = "Database configuration related to this project is not done yet, Please contact IT team to create link.";
                    }
                }
                Error = ex;
                throw ex;
            }
            return objHeaderList;
        }

        #endregion

        public bool UpdatePickingListRecord(PickingListDTO item)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", item.Id);
                paraList.AddQueryParameter("@BoxNo", item.BoxNo);
                var _allProp = item.GetType().GetProperties();
                foreach (var prp in _allProp)
                {
                    if (prp.Name.Trim().ToLower().StartsWith("free"))
                    {
                        paraList.AddQueryParameter("@" + prp.Name, prp.GetValue(item, null));
                    }
                }
                m_db.ExecuteNonSPQuery("dbo.IFY_WebTool_UpdatePickingListRecord", paraList);
            }
            catch (Exception ex)
            {
              Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        public bool AddPickingListRecord(PickingListDTO item)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", item.Id, SqlDbType.BigInt, ParameterDirection.Output);
                paraList.AddQueryParameter("@BoxNo", item.BoxNo);
                var _allProp = item.GetType().GetProperties();
                foreach (var prp in _allProp)
                {
                    if (prp.Name.Trim().ToLower().StartsWith("free"))
                    {
                        paraList.AddQueryParameter("@" + prp.Name, prp.GetValue(item, null));
                    }
                }
                m_db.ExecuteNonSPQuery("dbo.IFY_WebTool_AddPickingListRecord", paraList);
                item.Id = Convert.ToInt64(paraList.Find(p => p.ParameterName == "@Id").Value);
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }


        #region Picking User Type
        public bool AddPickedBox(Models.PickingModel record, string operatorName, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@BoxNo", record.BoxNo);
                paraList.AddQueryParameter("@Barcode", record.Barcode);
                paraList.AddQueryParameter("@RecieveDateTime", record.RecieveDateTime);
                paraList.AddQueryParameter("@UserId", userId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WebTool_AddPickedBoxRecord", paraList);
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }


        public List<PickingModelDTO> GetPickingBoxDetails(string boxNo, string barcode, DateTime? startDate, DateTime? endDate, bool isPickingListAvailable, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            List<PickingModelDTO> objList = new List<PickingModelDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@Barcode", barcode);
                //paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@IsPickingListAvailable", isPickingListAvailable);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBTOOL_GetPickingBoxDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        PickingModelDTO obj = new PickingModelDTO();
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxNo = Convert.ToString(item["BoxId"]);
                        obj.Barcode = Convert.ToString(item["Barcode"]);
                        obj.RecievedTime = Convert.ToString(item["RecievedTime"]);

                        obj.Free1 = (ds.Tables[0].Columns.Contains("Free1") ? Convert.ToString(item["Free1"]) : string.Empty);
                        obj.Free2 = (ds.Tables[0].Columns.Contains("Free2") ? Convert.ToString(item["Free2"]) : string.Empty);
                        obj.Free3 = (ds.Tables[0].Columns.Contains("Free3") ? Convert.ToString(item["Free3"]) : string.Empty);
                        obj.Free4 = (ds.Tables[0].Columns.Contains("Free4") ? Convert.ToString(item["Free4"]) : string.Empty);
                        obj.Free5 = (ds.Tables[0].Columns.Contains("Free5") ? Convert.ToString(item["Free5"]) : string.Empty);
                        obj.Free6 = (ds.Tables[0].Columns.Contains("Free6") ? Convert.ToString(item["Free6"]) : string.Empty);
                        obj.Free7 = (ds.Tables[0].Columns.Contains("Free7") ? Convert.ToString(item["Free7"]) : string.Empty);
                        obj.Free8 = (ds.Tables[0].Columns.Contains("Free8") ? Convert.ToString(item["Free8"]) : string.Empty);
                        obj.Free9 = (ds.Tables[0].Columns.Contains("Free9") ? Convert.ToString(item["Free9"]) : string.Empty);
                        obj.Free10 = (ds.Tables[0].Columns.Contains("Free10") ? Convert.ToString(item["Free10"]) : string.Empty);

                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        this.TotalRecordCount = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }
        public long TotalRecordCount { get; set; }
        #endregion
    }
}