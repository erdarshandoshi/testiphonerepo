﻿using WebTool.Models;
using HitechDAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace WebTool.BAL
{
    public class RightsBAL
    {
        #region Fields
        DBManager m_db = null;
        private string p;
        #endregion
        #region Constructor
        public RightsBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public RightsBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
        }
        #endregion

        public List<WebTool.Models.RightsModel> RightsList(string projectName, string ModuleName)
        {
            try
            {
                List<RightsModel> objRightsDTOlst = new List<RightsModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                // paralist.AddQueryParameter("@moduleName", ModuleName);
                ds = m_db.ExecuteDataSetForProcedure("dbo.Admin_RetrieveModuleList", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RightsModel obj = new RightsModel();
                        obj.ModuleId = Convert.ToInt32(item["ModuleId"]);
                        obj.ModuleName = Convert.ToString(item["ModuleName"]);
                        obj.Status = Convert.ToString(item["Status"]);
                        // obj.Status = Convert.ToBoolean(item["Status"]);
                        obj.MarkAsDeleted = Convert.ToBoolean(item["MarkAsDeleted"]);
                        objRightsDTOlst.Add(obj);
                    }
                }
                return objRightsDTOlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool InsertUpdateRights(string projectName, RightsDTO record)
        {
            try
            {
                List<RightsDTO> objRightsDTOlst = new List<RightsDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@moduleId", record.ModuleId, SqlDbType.Int, ParameterDirection.InputOutput);
                paralist.AddQueryParameter("@moduleName", record.ModuleName);
                m_db.ExecuteNonSPQuery("dbo.Admin_InsertUpdateModule", paralist);
                if (record.ModuleId <= 0)
                {
                    record.ModuleId = Convert.ToInt32(paralist.Find(p => p.ParameterName == "@moduleId").Value);
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }


        public bool DeleteRights(string projectName, int ModuleId)
        {
            try
            {
                HitechQueryParameter para = new HitechQueryParameter();
                para.AddQueryParameter("@moduleId", ModuleId);
                m_db.ExecuteNonSPQuery("dbo.Admin_DeleteModule", para);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        //public List<RoleGroupDTO> GetRoleList(string projectName)
        //{
        //    try
        //    {

        //        List<RoleGroupDTO> objRoleDTO = new List<RoleGroupDTO>();
        //        HitechQueryParameter paralist = new HitechQueryParameter();
        //        DataSet ds = null;
        //        ds = m_db.ExecuteDataSetForProcedure("dbo.UserTypeRetrieveArray", paralist);
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow item in ds.Tables[0].Rows)
        //            {
        //                RoleGroupDTO obj = new RoleGroupDTO();
        //                obj.UserType = Convert.ToString(item["userType"]);
        //                obj.UserTypeId = Convert.ToInt32(item["userTypeId"]);
        //                objRoleDTO.Add(obj);
        //            }
        //        }
        //        return objRoleDTO;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

        public List<UserGroupDTO> GetUserList(string projectName)
        {
            try
            {
                List<UserGroupDTO> objuserlst = new List<UserGroupDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@userId", null);
                paralist.AddQueryParameter("@userName ", null);
                paralist.AddQueryParameter("@password ", null);
                paralist.AddQueryParameter("@userTypeId ", null);
                paralist.AddQueryParameter("@companyId ", null);
                paralist.AddQueryParameter("@status", true);

                ds = m_db.ExecuteDataSetForProcedure("dbo.UsersRetrieveArray", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        UserGroupDTO obj = new UserGroupDTO();
                        obj.userId = Convert.ToInt32(item["userId"]);
                        obj.UserName = Convert.ToString(item["userName"]);
                        objuserlst.Add(obj);
                    }

                }
                return objuserlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Models.RightsModel> GetModuleList(string projectName)
        {
            try
            {
                List<RightsModel> objRightsDTOlst = new List<RightsModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                // paralist.AddQueryParameter("@moduleName", ModuleName);
                ds = m_db.ExecuteDataSetForProcedure("dbo.Admin_RetrieveModuleList", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RightsModel obj = new RightsModel();
                        obj.ModuleId = Convert.ToInt32(item["ModuleId"]);
                        obj.ModuleName = Convert.ToString(item["ModuleName"]);
                        obj.Status = Convert.ToString(item["Status"]);
                        // obj.Status = Convert.ToBoolean(item["Status"]);
                        obj.MarkAsDeleted = Convert.ToBoolean(item["MarkAsDeleted"]);
                        objRightsDTOlst.Add(obj);
                    }
                }
                return objRightsDTOlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Models.RightsModel> GetUserModuleName(string projectName, long userId)
        {
            try
            {
                List<RightsModel> objRightsDTOlst = new List<RightsModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@userId", userId);
                ds = m_db.ExecuteDataSetForProcedure("dbo.Admin_GetUserRightsByUserId", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RightsModel obj = new RightsModel();
                        obj.ModuleId = Convert.ToInt32(item["ModuleId"]);
                        obj.ModuleName = Convert.ToString(item["ModuleName"]);
                        obj.RightsId = Convert.ToInt64(item["RightsId"]);
                        // obj.Status = Convert.ToBoolean(item["Status"]);
                        obj.UserId = Convert.ToInt64(item["UserId"]);
                        objRightsDTOlst.Add(obj);
                    }
                }
                return objRightsDTOlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Models.RightsModel> GetUsersByRole(string projectName, int RoleId)
        {
            try
            {
                List<RightsModel> objRightsDTOlst = new List<RightsModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@userTypeId", RoleId);
                ds = m_db.ExecuteDataSetForProcedure("dbo.Admin_GetUsersByTypeId", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RightsModel obj = new RightsModel();
                        obj.UserName = Convert.ToString(item["userName"]);
                        obj.UserId = Convert.ToInt64(item["UserId"]);
                        objRightsDTOlst.Add(obj);
                    }
                }
                return objRightsDTOlst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool GetInsertUpdateUserRights(string projectName, long _userId, string _moduleid, bool _modulestatus)
        {
            try
            {
                List<RightsModel> objRightsDTOlst = new List<RightsModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@userId", _userId);
                paralist.AddQueryParameter("@moduleId", _moduleid);
                paralist.AddQueryParameter("@moduleStatus", _modulestatus);
                m_db.ExecuteNonSPQuery("dbo.Admin_InsertUpdateUserRights", paralist);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
