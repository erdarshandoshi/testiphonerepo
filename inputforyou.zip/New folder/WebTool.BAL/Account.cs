﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using System.Configuration;
using System.Data;
using WebTool.Models;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class Account
    {

    }

    public class LoginBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor

        public LoginBAL()
        {

        }


        public LoginBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Properties
        public string ConnectionString { get; set; }
        public string Password { get; set; }
        public string UserName { get; set; }
        #endregion

        #region Methods
        //internal List<ProjectDTO> GetAllProjectName()
        //{
        //    List<ProjectDTO> objProjects = new List<ProjectDTO>();
        //    DataSet ds = null;
        //    try
        //    {
        //        ds = m_db.ExecuteDataSetForProcedure("dbo.CTP_GetAllProjects");
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow item in ds.Tables[0].Rows)
        //            {
        //                objProjects.Add(new ProjectDTO()
        //                {
        //                    ProjectId = Convert.ToInt32(item["ProjectId"]),
        //                    ConnectionString = Convert.ToString(item["ConnectionStr"]),
        //                    ProjectName = Convert.ToString(item["ProjectName"])
        //                });
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    objProjects = objProjects.OrderBy(x => x.ProjectName).ToList();
        //    return objProjects;
        //}
        #endregion

        public  UserDTO DoLogin()
        {
            Models.UserDTO result = null;
            m_db = new DBManager(ConnectionString);
            DataSet ds = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@userName", this.UserName);
                paraList.AddQueryParameter("@password", this.Password);
                ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_LoginGetUserDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string _userName = Convert.ToString(ds.Tables[0].Rows[0]["userName"]).Trim();
                    string _password = Convert.ToString(ds.Tables[0].Rows[0]["password"]).Trim();
                    if (_userName == this.UserName && _password == this.Password)
                    {
                        result = new UserDTO();
                        result.UserId = Convert.ToInt64(ds.Tables[0].Rows[0]["userId"]);
                        result.UserName = Convert.ToString(ds.Tables[0].Rows[0]["userName"]).Trim();
                        result.UserType = Convert.ToString(ds.Tables[0].Rows[0]["userType"]).Trim();
                        result.FirstName = Convert.ToString(ds.Tables[0].Rows[0]["firstName"]).Trim();
                        result.LastName = Convert.ToString(ds.Tables[0].Rows[0]["lastName"]).Trim();
                        result.EmailId = Convert.ToString(ds.Tables[0].Rows[0]["emailId"]).Trim();
                        result.Location = Convert.ToString(ds.Tables[0].Rows[0]["location"]).Trim();
                        result.ProfilePhotoPath = Convert.ToString(ds.Tables[0].Rows[0]["ProfilePhotoPath"]).Trim();
                        if (result.UserType == "Administrator" || result.UserType == "Developer")
                        {
                            result.Projects = this.GetAllProject();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }

            return result;
        }

        public bool SaveUserPersonalProfile(UserDTO userInfo)
        {
            bool result = false;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@FirstName", userInfo.FirstName);
                paraList.AddQueryParameter("@LastName", userInfo.LastName);
                paraList.AddQueryParameter("@Location", userInfo.Location);
                paraList.AddQueryParameter("@EmailId", userInfo.EmailId);
                paraList.AddQueryParameter("@UserId", userInfo.UserId);
                int IsUpdated = m_db.ExecuteNonSPQuery("dbo.IFY_WEBVIEWER_SaveUserPersonalProfile", paraList);
                result = (IsUpdated > 0);
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                result = false;
            }
            return result;
        }

        public List<ProjectDTO> GetAllProject()
        {
            List<ProjectDTO> _objlist = new List<ProjectDTO>();
            ConnectionString = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(ConnectionString);
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.GetAllProjects");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        var obj = new ProjectDTO();
                        obj.ProjectId = Convert.ToInt32(item["Id"]);
                        obj.ProjectName = Convert.ToString(item["ProjectName"]);
                        obj.CompanyName = Convert.ToString(item["CompanyName"]);
                        obj.BoxStructure = Convert.ToString(item["BoxStructure"]);
                        obj.BoxStructure = Convert.ToString(item["BoxStructure"]);
                        obj.StartingLocation = Convert.ToString(item["StartingLocation"]);
                        obj.ProjectConnectionString = Convert.ToString(item["ConnectionStr"]);
                        if (obj.ProjectConnectionString != null && obj.ProjectConnectionString != "")
                        {
                            this.RetrieveProjectPath(ref obj);
                        }
                        obj.IconClass = "icon-folder-close";
                        obj.Modules = new List<ModuleDTO>();

                        // Start Change by Niyati
                        
                        obj.Modules.Add(new ModuleDTO() { IconClass = "icon-list-ul", ModuleName = "Folder Reset", ControllerName = "Reset", ActionName = "ResetList" });
                        obj.Modules.Add(new ModuleDTO() { IconClass = "icon-trash", ModuleName = "Folder Delete", ControllerName = "FolderDelete", ActionName = "FolderDeleteList" });
                        obj.Modules.Add(new ModuleDTO() { IconClass = "icon-user", ModuleName = "Manage User", ControllerName = "User", ActionName = "UserList" });
                        obj.Modules.Add(new ModuleDTO() { IconClass = "icon-list-ul", ModuleName = "Manage Rights", ControllerName = "Rights", ActionName = "RightsList" });
                        obj.Modules.Add(new ModuleDTO() { IconClass = "icon-list-ul", ModuleName = "Statuslist", ControllerName = "StatusList", ActionName = "StatusList" });
                        // End Change by Niyati						
                        //obj.Modules.Add(new ModuleDTO()
                        //{
                        //    IconClass = "icon-user",
                        //    ModuleName = "Manage User"
                        //});

                        if (Convert.ToBoolean(item["IsPickingList"]))
                        {
                            obj.Modules.Add(new ModuleDTO() { IconClass = "icon-list-ul", ModuleName = "Manage Picking", ControllerName = "Project", ActionName = "PickingList" });
                        }
                        _objlist.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
              Logger.WriteLog(ex);
                throw ex;
            }
            return _objlist;
        }



        public List<ProjectListDTO> GetProjectList()
        {
            List<ProjectListDTO> _objlist = new List<ProjectListDTO>();
            ConnectionString = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(ConnectionString);
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.GetAllProjects");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        var obj = new ProjectListDTO();
                        obj.ProjectId = Convert.ToInt32(item["Id"]);
                        obj.ProjectName = Convert.ToString(item["ProjectName"]);
                        obj.CompanyName = Convert.ToString(item["CompanyName"]);
                        obj.BoxStructure = Convert.ToString(item["BoxStructure"]);
                        obj.BoxStructure = Convert.ToString(item["BoxStructure"]);
                        obj.StartingLocation = Convert.ToString(item["StartingLocation"]);
                        _objlist.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return _objlist;
        }

        public void RetrieveProjectPath(ref ProjectDTO obj)
        {
            m_db = new DBManager(obj.ProjectConnectionString);
            DataSet ds = null;
            try
            {
                ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveProjectPaths");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        obj.ProjectPaths.Add(Convert.ToString(dr["SourceRoot"]));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
        }
    }
}