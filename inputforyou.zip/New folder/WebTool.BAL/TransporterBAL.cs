﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;



namespace WebTool.BAL
{
    public class TransporterBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public TransporterBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public TransporterBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
            this.TotalRecordCount = 0;
        }
        #endregion

        #region Properties
        public long TotalRecordCount { get; set; }
        #endregion

        //internal PreparatorModel GetPreparatorDetailById(int Id)
        //{
        //    PreparatorModel obj = null;
        //    try
        //    {
        //        HitechQueryParameter paraList = new HitechQueryParameter();
        //        paraList.AddQueryParameter("@Id", Id);
        //        DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetPreparatorDetailById", paraList);
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            var item = ds.Tables[0].Rows[0];
        //            obj = new PreparatorModel();
        //            obj.PartnerId = Convert.ToInt64(item["PartnerId"]);
        //            obj.PartnerName = Convert.ToString(item["PartnerName"]);
        //            obj.UserId = Convert.ToInt64(item["UserId"]);
        //            obj.UserName = Convert.ToString(item["UserName"]);
        //            obj.Location = Convert.ToString(item["Location"]);
        //            obj.EmailId = Convert.ToString(item["EmailId"]);
        //            obj.IsActive = Convert.ToBoolean(item["IsActive"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Utility.Logger.WriteLog(ex);
        //        throw ex;
        //    }
        //    return obj;
        //}

        //internal List<PreparatorModel> GetAllPreparators()
        //{
        //    List<PreparatorModel> objList = new List<PreparatorModel>();
        //    DataSet ds = null;
        //    try
        //    {
        //        ds = m_db.ExecuteDataSetForProcedure("GetAllPreparators");
        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow item in ds.Tables[0].Rows)
        //            {
        //                PreparatorModel obj = new PreparatorModel();
        //                obj.UserId = Convert.ToInt64(item["UserId"]);
        //                obj.UserName = Convert.ToString(item["UserName"]);
        //                //obj.FirstName = Convert.ToString(item["FirstName"]);
        //                //obj.LastName = Convert.ToString(item["LastName"]);
        //                obj.PartnerId = Convert.ToInt32(item["PartnerId"]);
        //                obj.PartnerName = Convert.ToString(item["PartnerName"]);
        //                obj.Location = Convert.ToString(item["Location"]);
        //                obj.EmailId = Convert.ToString(item["EmailId"]);
        //                obj.IsActive = Convert.ToBoolean(item["IsActive"]);
        //                objList.Add(obj);
        //            }
        //        }
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //    objList = objList.OrderBy(p => p.UserName).ToList();
        //    return objList;
        //}

        #region EDIT and Delete Trasporter Details

        public bool DeleteTransportInfo(long trId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@TrasporterId", trId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WEBVIEWER_DeleteTransportInfo", paraList, 300);
                return true;
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }

        public bool UpdateTransportDetails(TransporterModel record, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", record.RecordId);
                paraList.AddQueryParameter("@BoxNo", record.BoxNo);
                paraList.AddQueryParameter("@Batch", record.Batch);
                paraList.AddQueryParameter("@TotalFolders", record.Folders);
                paraList.AddQueryParameter("@DestinationLocation", record.DestinationLocation);
                paraList.AddQueryParameter("@UserId", userId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WebTool_UpdateTransportDetails", paraList, 300);
                return true;
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }

        #endregion
        public bool AddBoxDetail(TransporterModel item, string operatorName, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                //paraList.AddQueryParameter("@Id", item.UserId);
                paraList.AddQueryParameter("@BoxNo", item.BoxNo);
                paraList.AddQueryParameter("@Folders", item.Folders);
                paraList.AddQueryParameter("@Batch", item.Batch);
                paraList.AddQueryParameter("@StartLocation", item.StartLocation);
                paraList.AddQueryParameter("@DestinationLocation", item.DestinationLocation);
                paraList.AddQueryParameter("@PickDate", item.PickDateTime);
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@UserId", userId);

                m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_AddTransportBoxDetails", paraList);
            }
            catch (Exception ex)
            {
         Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        public List<TransporterDTO> GetTransportBoxDetails(string boxNo, string batch, string partnerName, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            List<TransporterDTO> objList = new List<TransporterDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@Batch", batch);
                paraList.AddQueryParameter("@DestinationLocation", partnerName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBTOOL_GetTransportBoxDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        TransporterDTO obj = new TransporterDTO();
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxNo = Convert.ToString(item["BoxNo"]);
                        obj.Batch = Convert.ToString(item["Batch"]);
                        obj.TotalFolder = Convert.ToString(item["TotalFolder"]);
                        obj.StartLocation = Convert.ToString(item["StartLocation"]);
                        obj.DestinationLocation = Convert.ToString(item["DestinationLocation"]);
                        obj.TransportDate = Convert.ToString(item["TransportDate"]);
                        obj.ReceptionDate = Convert.ToString(item["ReceptionDate"]);
                        obj.IsReceptionDateAvailable = false;
                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        this.TotalRecordCount = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }


        public List<TransporterDTO> GetTransporterDetailsFromID(int Id)
        {
            List<TransporterDTO> objList = new List<TransporterDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", Id);

                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBTOOL_GetTransporterDetailsFromID", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        TransporterDTO obj = new TransporterDTO();
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.BoxNo = Convert.ToString(item["BoxNo"]);
                        obj.Batch = Convert.ToString(item["Batch"]);
                        obj.TotalFolder = Convert.ToString(item["TotalFolder"]);
                        obj.StartLocation = Convert.ToString(item["StartLocation"]);
                        obj.DestinationLocation = Convert.ToString(item["DestinationLocation"]);
                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        this.TotalRecordCount = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
             Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

    }
}