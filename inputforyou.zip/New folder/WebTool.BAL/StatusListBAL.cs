﻿using WebTool.Models;
using HitechDAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class StatusListBAL
    {
        #region Fields
        DBManager m_db = null;
        private string p;
        #endregion
        #region Constructor
        public StatusListBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public StatusListBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
            this.SourceRoots = new List<string>();
        }
        #endregion
        #region  Properties
        public List<ProcessModel> AllProcess { get; set; }
        public int TotalImages { get; set; }
        public List<string> SourceRoots { get; set; }
        #endregion

        /*Start Change By Niyati*/
        #region Static Class
        public static class DyExtension
        {
            public static void AddProperty(ExpandoObject expando, string propertyName, object propertyValue)
            {
                var expandoDict = expando as IDictionary<string, object>;
                if (expandoDict.ContainsKey(propertyName))
                    expandoDict[propertyName] = propertyValue;
                else
                    expandoDict.Add(propertyName, propertyValue);
            }
        }
        #endregion
        /*End Change By Niyati*/

        public List<object> RetrieveFoldersForListing(object FromDate, object ToDate, string BoxNo, string FolderNo, string[][] freeFields, string allcheckvalues)
        {
            List<object> objList = new List<object>();
            try
            {
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@fromDate", FromDate);
                paralist.AddQueryParameter("@toDate", ToDate);
                paralist.AddQueryParameter("@boxId", BoxNo);
                paralist.AddQueryParameter("@folderId", FolderNo);
                paralist.AddQueryParameter("@cifStatus", allcheckvalues);
                if (freeFields != null && freeFields.Length > 0)
                {
                    for (int i = 0; i < freeFields.Length; i++)
                    {
                        paralist.AddQueryParameter("@" + freeFields[i][0], (string.IsNullOrEmpty(freeFields[i][1]) || (freeFields[i][1]).Trim().ToUpper() == "SELECT") ? "" : freeFields[i][1]);
                    }
                    //ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveFolderList", paralist);
                }
                ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveFolderList", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    #region Get Column names
                    List<string> _columns = new List<string>();
                    for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                    {
                        _columns.Add(ds.Tables[0].Columns[i].ColumnName.Trim());
                    }

                    #endregion

                    #region Loop all rows to enter in anonymous type (Dynamic Data List)
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        dynamic expando = new ExpandoObject();
                        foreach (string dyHeader in _columns)
                        {
                            string _propName = dyHeader;
                            if (_propName == "BoxNo") { _propName = "boxid"; }
                            if (_propName == "FolderNo") { _propName = "folderid"; }
                            DyExtension.AddProperty(expando, _propName.Replace(" ", "").Trim().ToLower(), Convert.ToString(item[dyHeader]));
                        }
                        objList.Add(expando);
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objList;
        }

        public List<DynamicControlDetailsDTO> DynamicControlsRetrive(string projectName, string fornmname)
        {
            try
            {
                List<DynamicControlDetailsDTO> objList = new List<DynamicControlDetailsDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@formName", fornmname);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.CustomViewer_DynamicControlsRetrive", paralist);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    objList = new List<DynamicControlDetailsDTO>();
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        DynamicControlDetailsDTO obj = new DynamicControlDetailsDTO();
                        obj.ControlName = Convert.ToString(item["ControlName"]);
                        obj.Name = Convert.ToString(item["Name"]);
                        obj.TEXT = Convert.ToString(item["TEXT"]);
                        obj.DataSource = Convert.ToString(item["DataSource"]);
                        objList.Add(obj);
                    }
                }
                return objList;


            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Dictionary<string, string> GetFolderStatus(string projectName)
        {
            try
            {
                Dictionary<string, string> _dict = new Dictionary<string, string>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetriveFolderStatus", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        _dict.Add(Convert.ToString(item["FolderStatus"]), Convert.ToString(item["FolderStatusValue"]));
                    }
                }
                return _dict;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public List<HeaderDTO> GetHeaders(string projectName)
        {
            List<HeaderDTO> objheaderlst = new List<HeaderDTO>();
            HitechQueryParameter paralist = new HitechQueryParameter();
            DataSet ds = null;
            ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveHeader", paralist);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    objheaderlst.Add(new HeaderDTO() { HeaderName = Convert.ToString(item["HeaderName"]), width = Convert.ToString(item["Width"]) });
                }
            }

            return objheaderlst;
        }

        public DataSet RetrieveFolderDetails(int cifId)
        {
            DataSet ds = null;
            try
            {
                AllProcess = new List<Models.ProcessModel>();
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@cifId", cifId);
                ds = m_db.ExecuteDataSetForProcedure("dbo.CustomViewer_RetrieveMoreDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[1].Rows)
                    {
                        if (dr != null)
                        {
                            ProcessModel objProcessModel = new Models.ProcessModel();
                            objProcessModel.IsCompleted = (dr != null);
                            objProcessModel.ProcessOperator = Convert.ToString(dr["UserName"]);
                            objProcessModel.ProcessName = Convert.ToString(dr["ProcessName"]);
                            objProcessModel.StartTime = Convert.ToString(dr["StartDateTime"]);
                            objProcessModel.EndTime = Convert.ToString(dr["EndDateTime"]);
                            objProcessModel.TimeTaken = Convert.ToString(dr["TimeTaken"]);
                            AllProcess.Add(objProcessModel);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }
            return ds;
        }

        public List<WebTool.Models.ImageDTO> RetrieveImages(string projectName, long cifId, int pageSize, int pageIndex, bool isDisplayDeletedImage)
        {
            List<ImageDTO> objList = new List<ImageDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@cifId", cifId);
                paraList.AddQueryParameter("@PageSize", pageSize);
                paraList.AddQueryParameter("@PageIndex", pageIndex);
                paraList.AddQueryParameter("@IsDisplayDeletedImage", isDisplayDeletedImage);
                paraList.AddQueryParameter("@TotalImages", 0, SqlDbType.Int, ParameterDirection.InputOutput);
                DataSet _ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveImages", paraList);
                if (_ds != null && _ds.Tables.Count > 0 && _ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < _ds.Tables[0].Rows.Count; i++)
                    {
                        ImageDTO obj = new ImageDTO();
                        obj.CifId = ObjectExtension.SafeCastInt(_ds.Tables[0].Rows[i]["cifId"]);
                        obj.BoxNo = Convert.ToString(_ds.Tables[0].Rows[i]["BoxNo"]);
                        obj.FolderNo = Convert.ToString(_ds.Tables[0].Rows[i]["FolderNo"]);
                        obj.FileName = Convert.ToString(_ds.Tables[0].Rows[i]["fileName"]);
                        obj.RegistrationId = ObjectExtension.SafeCastInt(_ds.Tables[0].Rows[i]["registrationId"]);
                        obj.RotationIndex = ObjectExtension.SafeCastInt(_ds.Tables[0].Rows[i]["rotatedIndex"]);
                        obj.ConjugateFileName = Convert.ToString(_ds.Tables[0].Rows[i]["ConjugateFileName"]);
                        obj.IsDeleted = ObjectExtension.SafeCastInt(_ds.Tables[0].Rows[i]["isDeleted"]);
                        obj.IsColored = Convert.ToBoolean(_ds.Tables[0].Rows[i]["isColorSelected"]);
                        obj.DisplayName = (obj.IsColored) ? obj.ConjugateFileName : obj.FileName;
                        if (_ds.Tables[0].Columns.Contains("bookMark"))
                            obj.BookMark = Convert.ToString(_ds.Tables[0].Rows[i]["bookMark"]);
                        //if (_ds.Tables[0].Columns.Contains("treeBookMarkId"))
                        //    obj.TreeBookMarkId = ObjectExtension.SafeCastInt(_ds.Tables[0].Rows[i]["treeBookMarkId"]);
                        objList.Add(obj);
                    }

                    this.TotalImages = Convert.ToInt32(paraList.Find(x => x.ParameterName == "@TotalImages").Value);

                    if (_ds.Tables.Count > 1 && _ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < _ds.Tables[1].Rows.Count; i++)
                        {
                            if (!this.SourceRoots.Contains(Convert.ToString(_ds.Tables[1].Rows[i]["SourceRoot"])))
                            {
                                this.SourceRoots.Add(Convert.ToString(_ds.Tables[1].Rows[i]["SourceRoot"]));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }
    }
}