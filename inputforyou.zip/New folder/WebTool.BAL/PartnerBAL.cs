﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;



namespace WebTool.BAL
{
    public class PartnerBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public PartnerBAL()
        {
            string _conStr = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(_conStr);
        }
        public PartnerBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        public bool InsertUpdatePartnerRecord(PartnerModel item)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", item.UserId);
                paraList.AddQueryParameter("@FirstName", item.FirstName);
                paraList.AddQueryParameter("@UserName", item.UserName);
                paraList.AddQueryParameter("@Password", item.Password);
                paraList.AddQueryParameter("@Location", item.Location);
                paraList.AddQueryParameter("@EmailId", item.EmailId);
                paraList.AddQueryParameter("@IsActive", item.IsActive);
                m_db.ExecuteNonSPQuery("dbo.InsertUpdatePartnerDetails", paraList);
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }
        public PartnerModel GetPartnerDetailById(int Id)
        {
            PartnerModel obj = null;
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", Id);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.GetPartnerDetailById", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var item = ds.Tables[0].Rows[0];
                    obj = new PartnerModel();
                    obj.UserId = Convert.ToInt32(item["UserId"]);
                    obj.FirstName = Convert.ToString(item["FirstName"]);
                    obj.UserName = Convert.ToString(item["UserName"]);
                    obj.Password = Convert.ToString(item["Password"]);
                    obj.Location = Convert.ToString(item["Location"]);
                    obj.EmailId = Convert.ToString(item["EmailId"]);
                    obj.IsActive = Convert.ToBoolean(item["IsActive"]);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }
            return obj;
        }

        public List<PartnerModel> GetAllPartners()
        {
            List<PartnerModel> objPartners = new List<PartnerModel>();
            DataSet ds = null;

            try
            {
                ds = m_db.ExecuteDataSetForProcedure("GetAllPartners");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        PartnerModel obj = new PartnerModel();
                        obj.UserId = Convert.ToInt32(item["UserId"]);
                        obj.FirstName = Convert.ToString(item["FirstName"]);
                        obj.UserName = Convert.ToString(item["UserName"]);
                        obj.Password = Convert.ToString(item["Password"]);
                        obj.Location = Convert.ToString(item["Location"]);
                        obj.EmailId = Convert.ToString(item["EmailId"]);
                        obj.IsActive = Convert.ToBoolean(item["IsActive"]);
                        objPartners.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            objPartners = objPartners.OrderBy(p => p.UserName).ToList();
            return objPartners;
        }

        #endregion
    }
}