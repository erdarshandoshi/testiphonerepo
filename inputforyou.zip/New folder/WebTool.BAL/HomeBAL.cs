﻿using System;
using WebTool.Models;
using HitechDAO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace WebTool.BAL
{
    public class HomeBAL
    {
        #region Fields
        DBManager m_db = null;
        private string p;
        #endregion
        #region Constructor
        public HomeBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public HomeBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
        }
        #endregion


        public DataSet RetrieveProjectFolderStatus(string projectName)
        {
            DataTable dtForCompletedFolders = new DataTable();
            DataTable dtForWorkingFolders = new DataTable();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                //paraList.AddQueryParameter("@startDate", StartDate);
                //paraList.AddQueryParameter("@endDate", EndDate);
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBVIEWER_RetrieveProjectFolderStatus", paraList, 300);
                //if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                //{
                //    dtForCompletedFolders = ds.Tables[0];
                //}
                //else
                //{
                //    DataRow dr = dtForCompletedFolders.NewRow();
                //    DataColumn dc = new DataColumn("Result", typeof(string));
                //    dtForCompletedFolders.Columns.Add(dc);
                //    dr["Result"] = "No Records Found...";
                //    dtForCompletedFolders.Rows.Add(dr);
                //}
                //if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                //{
                //    dtForWorkingFolders = ds.Tables[1];
                //}
                //else
                //{
                //    DataRow dr = dtForWorkingFolders.NewRow();
                //    DataColumn dc = new DataColumn("Result", typeof(string));
                //    dtForWorkingFolders.Columns.Add(dc);
                //    dr["Result"] = "No Records Found...";
                //    dtForWorkingFolders.Rows.Add(dr);
                //}
                //string jsonStringForCompletedFolders = GetJson(dtForCompletedFolders);
                //jsonStringForCompletedFolders = jsonStringForCompletedFolders.Replace("_", " ");
                //string jsonStringForWorkingFolders = GetJson(dtForWorkingFolders);
                //jsonStringForWorkingFolders = jsonStringForWorkingFolders.Replace("_", " ");
                ////return new string[] { jsonStringForCompletedFolders, jsonStringForWorkingFolders };


                return ds;
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }



       
    }
}
