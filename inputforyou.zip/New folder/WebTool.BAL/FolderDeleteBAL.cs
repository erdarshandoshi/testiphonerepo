﻿using WebTool.Models;
using HitechDAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using DocflowWebTool.Utility;
namespace WebTool.BAL
{
    public class FolderDeleteBAL
    {
        #region Fields
        DBManager m_db = null;
        List<string> m_ProjectPaths;
        public bool _impersonateSuccessful = false;
        #endregion
        public FolderDeleteBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }

        public FolderDeleteBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
            m_ProjectPaths = RetrieveProjectDataPath();
        }

        public List<FolderDeleteModel> FolderDeleteList(string Box, string Folder)
        {
            try
            {
                List<FolderDeleteModel> objFolderDeletelst = new List<FolderDeleteModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@boxId", Box);
                paralist.AddQueryParameter("@folderId", Folder);
                ds = m_db.ExecuteDataSetForProcedure("dbo.FolderDelete_GetFolderList", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        FolderDeleteModel obj = new FolderDeleteModel();
                        obj.Id = Convert.ToInt32(item["cifId"]);
                        obj.Box = Convert.ToString(item["boxId"]);
                        obj.Folder = Convert.ToString(item["folderId"]);
                        obj.FolderStatus = Convert.ToString(item["FolderStatus"]);
                        objFolderDeletelst.Add(obj);
                    }
                }
                return objFolderDeletelst;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public List<RetriveReasonDTO> RetrieveFolderDeleteReasons(string projectName)
        {
            try
            {
                List<RetriveReasonDTO> objFolderDeletelst = new List<RetriveReasonDTO>();
                HitechQueryParameter param = new HitechQueryParameter();
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.FolderDelete_RetrieveFolderDeleteReasons", param);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    objFolderDeletelst = new List<RetriveReasonDTO>();
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RetriveReasonDTO obj = new RetriveReasonDTO();
                        obj.FolderDeleteReasonId = Convert.ToInt32(item["FolderDeleteReasonId"]);
                        obj.FolderDeleteReason = Convert.ToString(item["FolderDeleteReason"]);
                        objFolderDeletelst.Add(obj);

                    }

                }
                return objFolderDeletelst;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        public bool DeleteFolderFromDB(int reasonId, string remarks, int founduserId, ref int ret, long cifId)
        {
            try
            {
                HitechQueryParameter param = new HitechQueryParameter();
                param.AddQueryParameter("@cifId", cifId);
                param.AddQueryParameter("@reasonId", reasonId);
                param.AddQueryParameter("@remarks", remarks);
                param.AddQueryParameter("@userId", founduserId);
                param.AddQueryParameter("@ret", ret, SqlDbType.Int, ParameterDirection.InputOutput);
                m_db.ExecuteNonSPQuery("dbo.FolderDelete_DeleteFolderFromDB", param);
                ret = Convert.ToInt32(param.Find(p => p.ParameterName == "@ret").Value);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<string> RetrieveProjectDataPath()
        {
            {
                List<string> objlst = new List<string>();
                try
                {
                    DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBTOOL_RetrieveProjectDataPath");
                    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow item in ds.Tables[0].Rows)
                        {

                            objlst.Add(Convert.ToString(ds.Tables[0].Rows[0]["Path"]));
                        }
                    }
                    return objlst;
                }
                catch (Exception ex)
                {
                    // HitechPluginAPI.Logger.WriteLog(ex);
                    throw new Exception("Unable to retrieve DataPath from DB...!!! Please contact Admin : " + ex.Message);
                }

            }
        }


        public int RemoveDataFromDataPath(FolderDeleteModel folder)
        {
            int result = 0;
            try
            {
                FolderDeleteModel folderdeletemodel = new FolderDeleteModel();
                if (m_ProjectPaths != null && m_ProjectPaths.Count > 0)
                {
                    for (int index = 0; index < m_ProjectPaths.Count; index++)
                    {
                        List<string> _datapath = m_ProjectPaths;
                        _impersonateSuccessful = ImpersonateUser();
                        if (_impersonateSuccessful)
                        {
                            string _dataFullPath = System.IO.Path.Combine(_datapath[index], System.IO.Path.Combine(folder.Box, folder.Folder));
                            if (System.IO.Directory.Exists(_dataFullPath))
                            {
                                System.IO.DirectoryInfo _di = new System.IO.DirectoryInfo(_dataFullPath);
                                var _allFiles = _di.GetFiles();
                                var _allImageFiles = _allFiles.Where(x => x.CreationTime < DateTime.Now).Select(d => d.FullName);

                                if (_allImageFiles.Count() > 0)
                                {
                                    foreach (var _imageFile in _allImageFiles)
                                    {
                                        try
                                        {
                                            System.IO.File.Delete(_imageFile);
                                        }
                                        catch { }
                                    }
                                    try
                                    {
                                        if (System.IO.Directory.GetFiles(_dataFullPath).Count() == 0)
                                        {
                                            System.IO.Directory.Delete(_dataFullPath);
                                        }
                                    }
                                    catch { }
                                    result = 100;
                                    break;
                                }
                            }
                            Win32API.UndoImpersonation();
                        }
                        else
                        {
                            result = 99;
                        }
                    }


                }
                else
                {
                    //MessageBox.Show("No Data Available on DataPath");
                }
            }

            catch (Exception ex)
            {
                //HitechPluginAPI.Logger.WriteLog(ex);
                return -10000;
            }
            return result;

        }


        private bool ImpersonateUser()
        {
            try
            {
                var _keys = System.Configuration.ConfigurationManager.AppSettings.AllKeys;
                if (_keys != null && _keys.Count() > 0)
                {
                    foreach (var _key in _keys)
                    {
                        if (_key.StartsWith("DataPath_"))
                        {
                            string[] _strArr = _key.Split('_');
                            if (_strArr.Length > 2)
                            {
                                string _path = _strArr[1];
                                string domainName = _strArr[2];
                                {
                                    string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
                                    string _decryptedCredintials = DocflowWebTool.Utility.Utilities.DecodeFrom64(_encryptedCredintials);
                                    System.Diagnostics.Debug.WriteLine(_decryptedCredintials);
                                    string[] _credintials = _decryptedCredintials.Split('_');
                                    foreach (string _dataPath in m_ProjectPaths)
                                    {
                                        if (_dataPath.Contains(_path))
                                        {
                                            _impersonateSuccessful = DocflowWebTool.Utility.Win32API.ImpersonateValidUser(_credintials[0], domainName, _credintials[1]);
                                            System.Diagnostics.Debug.WriteLine("call final ImpersonateValidUser() => " + _credintials[0] + domainName + _credintials[1]);
                                            if (_impersonateSuccessful)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                else
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<string> GetBoxList()
        {
            try
            {
                List<string> objBoxes = new List<string>();
                HitechQueryParameter param = new HitechQueryParameter();
                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.FolderDelete_GetBoxList");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    objBoxes = new List<string>();
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        FolderDeleteModel obj = new FolderDeleteModel();
                        objBoxes.Add(Convert.ToString(item["boxId"]));
                    }

                }
                return objBoxes;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}



