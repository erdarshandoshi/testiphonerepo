﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebTool.Models;
using System.Data;
using HitechDAO;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class PaletteBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public PaletteBAL()
        {
            string _conStr = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];
            m_db = new DBManager(_conStr);
        }
        public PaletteBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        public List<AssignPaletteDTO> GetBoxListForPaletteNumber(string boxNo, string operatorName)
        {
            List<AssignPaletteDTO> objList = new List<AssignPaletteDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@OperatorName", operatorName);
                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_GetBoxDetails", paraList, 300);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        AssignPaletteDTO obj = new AssignPaletteDTO();
                        obj.BoxId = Convert.ToString(item["BoxId"]);
                        obj.PaletteNumber = Convert.ToString(item["PaletteNumber"]);
                        obj.PaletteStatus = Convert.ToString(item["PaletteStatus"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        public List<PaletteDTO> GetPaletteWiseDetail(string paletteNumber, string operatorName, DateTime? startDate, DateTime? endDate)
        {
            List<PaletteDTO> objList = new List<PaletteDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@PaletteNumber", paletteNumber);
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_GetPaletteWiseDetail", paraList, 300);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        PaletteDTO obj = new PaletteDTO();
                        obj.PaletteNo = Convert.ToString(item["PaletteNumber"]);
                        obj.BoxId = Convert.ToString(item["BoxId"]);
                        obj.PaletteId = Convert.ToInt32(item["PaletteId"]);
                        obj.PaletteStatus = Convert.ToString(item["PaletteStatus"]);
                        //obj.TotalBoxes = Convert.ToString(item["TotalBoxes"]);
                        obj.TotalFolder = Convert.ToString(item["TotalFolders"]);
                        obj.TotalSheet = Convert.ToString(item["TotalSheets"]);
                        obj.Destruction = Convert.ToString(item["Destruction"]);
                        obj.PaletteIntegrateDate = Convert.ToString(item["PaletteIntegrateDate"]);
                        obj.DestructionDate = Convert.ToString(item["DestructionDate"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }


        public bool AddPaletteNumber(string paletteNumber, string paletteStatus, string boxNo)
        {
            try
            {
                int result = 0;
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@PaletteNumber", paletteNumber);
                paraList.AddQueryParameter("@PaletteStatus", paletteStatus);
                paraList.AddQueryParameter("@BoxNo", boxNo);
                result = m_db.ExecuteNonSPQuery("IFY_Webtool_AddPaletteNumber", paraList, 300);
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }

        public bool AddDestructionDetails(PaletteDTO paletteDTO)
        {
            try
            {
                int result = 0;
                if (paletteDTO.PaletteStatus == "---Select---")
                {
                    paletteDTO.PaletteStatus = "";
                }
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Destruction", paletteDTO.Destruction);
                paraList.AddQueryParameter("@PaletteNumber", paletteDTO.PaletteNo);
                paraList.AddQueryParameter("@PaletteStatus", paletteDTO.PaletteStatus);
                paraList.AddQueryParameter("@PaletteId", paletteDTO.PaletteId);
                result = m_db.ExecuteNonSPQuery("IFY_Webtool_AddDestructionDetails", paraList, 300);
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw;
            }
        }


    }
}