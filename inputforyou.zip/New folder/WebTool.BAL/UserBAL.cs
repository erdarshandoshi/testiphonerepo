﻿using WebTool.Models;
using HitechDAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using DocflowWebTool.Utility;

namespace WebTool.BAL
{
    public class UserBAL
    {
        #region Fields
        DBManager m_db = null;
        private string p;
        #endregion
        #region Constructor
        public UserBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public UserBAL(string connectionString)
        {
            // TODO: Complete member initialization
            m_db = new DBManager(connectionString);
        }
        #endregion


        public List<RoleDTO> GetRoleList(string projectName)
        {
            try
            {

                List<RoleDTO> objRoleDTO = new List<RoleDTO>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = null;
                ds = m_db.ExecuteDataSetForProcedure("dbo.UserTypeRetrieveArray", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        RoleDTO obj = new RoleDTO();
                        obj.UserType = Convert.ToString(item["userType"]);
                        obj.UserTypeId = Convert.ToInt32(item["userTypeId"]);
                        objRoleDTO.Add(obj);
                    }
                }
                return objRoleDTO;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<UserListModel> UserList(string username, string firstname, int userTypeId)
        {
            try
            {
                List<UserListModel> objuserlst = new List<UserListModel>();
                HitechQueryParameter paralist = new HitechQueryParameter();
                DataSet ds = new DataSet();
                paralist.AddQueryParameter("@userId", null);
                paralist.AddQueryParameter("@userName ", username);
                paralist.AddQueryParameter("@password ", null);
                paralist.AddQueryParameter("@userTypeId ", userTypeId);
                paralist.AddQueryParameter("@companyId ", null);
                paralist.AddQueryParameter("@status", true);

                ds = m_db.ExecuteDataSetForProcedure("dbo.UsersRetrieveArray", paralist);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        UserListModel obj = new UserListModel();
                        obj.userId = Convert.ToInt32(item["userId"]);
                        obj.UserName = Convert.ToString(item["userName"]);
                        obj.Password = Convert.ToString(item["password"]);
                        obj.FirstName = Convert.ToString(item["firstname"]);
                        obj.LastName = Convert.ToString(item["lastname"]);
                        obj.Location = Convert.ToString(item["location"]).Trim();
                        obj.EmailId = Convert.ToString(item["emailId"]);
                        obj.status = Convert.ToBoolean(item["status"]);
                        obj.IsWebAccess = Convert.ToBoolean(item["IsWebAccess"]);
                        if (item["userCreatedDate"] != DBNull.Value) { obj.CreatedDate = Convert.ToDateTime(item["userCreatedDate"]); }
                        obj.UserTypeId = Convert.ToInt16(item["userTypeId"]);
                        obj.CompanyId = Convert.ToInt16(item["companyId"]);
                        obj.UserType = Convert.ToString(item["UserType"]);
                        //objresetDTO.UserType = Convert.ToInt32(item["Status"]);
                        objuserlst.Add(obj);
                    }

                }
                return objuserlst;
            }

            catch (Exception ex)
            {

                throw ex;
            }
        }




        public bool InsertUpdateRole(UserListModel record)
        {
            try
            {
                HitechQueryParameter paralist = new HitechQueryParameter();
                paralist.AddQueryParameter("@userId", record.userId, SqlDbType.BigInt, ParameterDirection.InputOutput);
                paralist.AddQueryParameter("@firstName", record.FirstName);
                paralist.AddQueryParameter("@lastName", (object)record.LastName ?? DBNull.Value);
                paralist.AddQueryParameter("@userName", (object)record.UserName ?? DBNull.Value);
                paralist.AddQueryParameter("@password", (object)record.Password ?? DBNull.Value);
                paralist.AddQueryParameter("@location", (object)record.Location.Trim() ?? DBNull.Value);
                paralist.AddQueryParameter("@emailId", (object)record.EmailId ?? DBNull.Value);
                paralist.AddQueryParameter("@companyId", (object)record.CompanyId ?? DBNull.Value);
                paralist.AddQueryParameter("@userTypeId", (object)record.UserTypeId ?? DBNull.Value);
                paralist.AddQueryParameter("@userStatus", (object)record.status ?? DBNull.Value);
                m_db.ExecuteNonSPQuery("dbo.Admin_InsertUpdateUserDetails", paralist);
                if(record.userId <= 0)
                {
                    record.userId = Convert.ToInt64(paralist.Find(p => p.ParameterName == "@userId").Value);
                }
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        public List<CompanyDTO> GetCompanyList()
        {
            List<CompanyDTO> objRoleDTO = new List<CompanyDTO>();
            DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.CompanyRetrieveArray");
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    CompanyDTO obj = new CompanyDTO();
                    obj.CompanyName = Convert.ToString(item["companyName"]);
                    obj.CompanyId = Convert.ToInt16(item["companyId"]);
                    objRoleDTO.Add(obj);
                }
            }
            return objRoleDTO;
        }
    }
}