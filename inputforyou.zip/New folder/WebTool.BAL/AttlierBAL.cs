﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HitechDAO;
using WebTool.Models;
using System.Data;
using DocflowWebTool.Utility;



namespace WebTool.BAL
{
    public class AttlierBAL
    {
        #region Fields
        DBManager m_db = null;
        #endregion

        #region Constructor
        public AttlierBAL()
            : this(System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"])
        {
        }
        public AttlierBAL(string connectionString)
        {
            m_db = new DBManager(connectionString);
        }
        #endregion

        #region Methods
        public bool AddReceptionBox(Models.AtelierReceptionModel record, string operatorName, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@BoxNo", record.BoxNo);
                paraList.AddQueryParameter("@Folders", record.Folders);
                paraList.AddQueryParameter("@Barcode", record.Batch);
                paraList.AddQueryParameter("@RecieveDateTime", record.RecieveDateTime);
                paraList.AddQueryParameter("@IsBag", record.IsBagBatchBox);
                paraList.AddQueryParameter("@UserId", userId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WebTool_AddReceptionBoxRecord", paraList);
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        public bool DeleteReceptionInfo(long id)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@Id", id);
                m_db.ExecuteNonSPQuery("IFY_WEBTOOL_DeleteBoxReceptionDetails", paraList, 300);
                return true;
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
        }

        public List<AtelierReceptionDTO> GetAtelierReceptionBoxDetails(string boxNo, string batch, string operatorName, DateTime? startDate, DateTime? endDate, bool isBag, int jtStartIndex, int jtPageSize, string jtSorting, ref long totalRecord)
        {
            List<AtelierReceptionDTO> objList = new List<AtelierReceptionDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxNo);
                paraList.AddQueryParameter("@Batch", batch);
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@IsBag", isBag);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("dbo.IFY_WEBTOOL_GetAtelierReceptionBoxDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        AtelierReceptionDTO obj = new AtelierReceptionDTO();
                        obj.Id = Convert.ToInt32(item["Id"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxBagNo = Convert.ToString(item["BoxId"]);
                        obj.Batch = Convert.ToString(item["Batch"]);
                        obj.TotalFolder = Convert.ToString(item["TotalFolders"]);
                        obj.OperatorName = Convert.ToString(item["OperatorName"]);
                        obj.RecievedTime = Convert.ToString(item["RecievedTime"]);
                        objList.Add(obj);
                    }
                    if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                    {
                        totalRecord = Convert.ToInt64(ds.Tables[1].Rows[0][0]);
                    }
                }
            }
            catch (Exception ex)
            {
             Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }
        #endregion

        #region Preparation
        public bool IsPreparationBatchStarted(string boxBatch, ref bool isAlreadyEnded, ref bool isAvailableInReception)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxBatch", boxBatch);
                paraList.AddQueryParameter("@IsBoxBatchAlreadyEnd", 0, SqlDbType.Bit, ParameterDirection.InputOutput);
                paraList.AddQueryParameter("@IsBoxBatchAvailableInReception", 0, SqlDbType.Bit, ParameterDirection.InputOutput);

                var result = m_db.ExecuteScalerForProcedure("dbo.IFY_WEBTOOL_IsPreparationBatchStarted", paraList);
                isAlreadyEnded = Convert.ToBoolean(paraList.Find(p => p.ParameterName == "@IsBoxBatchAlreadyEnd").Value);
                isAvailableInReception = Convert.ToBoolean(paraList.Find(p => p.ParameterName == "@IsBoxBatchAvailableInReception").Value);
                return (Convert.ToInt32(result) > 0);
            }
            catch (Exception ex)
            {
             Logger.WriteLog(ex);
                throw ex;
            }
        }

        public bool AddPreparationBox(Models.AtelierPreparationModel record, string operatorName, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@BoxBatch", record.BoxBatchNo);
                //paraList.AddQueryParameter("@RecieveDateTime", record.RecieveDateTime);
                paraList.AddQueryParameter("@IsBag", record.IsBag);
                paraList.AddQueryParameter("@UserId", userId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_AddPreparationBox", paraList);
            }
            catch (Exception ex)
            {
               Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        public bool UpdatePreparationBox(Models.AtelierPreparationModel record, string operatorName, long userId)
        {
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@OperatorName", operatorName);
                paraList.AddQueryParameter("@BoxBatch", record.BoxBatchNo);
                //paraList.AddQueryParameter("@RecieveDateTime", record.RecieveDateTime);
                paraList.AddQueryParameter("@IsBag", record.IsBag);
                paraList.AddQueryParameter("@UserId", userId);
                m_db.ExecuteNonSPQuery("dbo.IFY_WEBTOOL_AddPreparationBox", paraList);
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }
            return true;
        }

        #endregion

        #region Scanning

        public List<AtelierScanningDTO> GetScanningBoxDetails(string boxBatch, DateTime? startDate, DateTime? endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            List<AtelierScanningDTO> objList = new List<AtelierScanningDTO>();
            try
            {
                HitechQueryParameter paraList = new HitechQueryParameter();
                paraList.AddQueryParameter("@BoxNo", boxBatch);
                paraList.AddQueryParameter("@StartDate", startDate);
                paraList.AddQueryParameter("@EndDate", endDate);
                paraList.AddQueryParameter("@JtStartIndex", jtStartIndex);
                paraList.AddQueryParameter("@JtPageSize", jtPageSize);
                paraList.AddQueryParameter("@JtSorting", jtSorting);

                DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_GetScanningDetails", paraList);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow item in ds.Tables[0].Rows)
                    {
                        AtelierScanningDTO obj = new AtelierScanningDTO();
                        obj.Id = Convert.ToInt32(item["PreparationId"]);
                        obj.No = Convert.ToInt32(item["RNO"]);
                        obj.BoxNo = Convert.ToString(item["BoxBatch"]);
                        obj.BoxScanDate = Convert.ToString(item["ScanDate"]);
                        obj.PreparationStartDate = Convert.ToString(item["StartDate"]);
                        obj.PreparationEndDate = Convert.ToString(item["EndDate"]);
                        objList.Add(obj);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }

        public List<AtelierScanningDTO> GetBoxScanDetails(string boxNo)
        {

            List<AtelierScanningDTO> objList = new List<AtelierScanningDTO>();
            try
            {
                if (!(boxNo == null || boxNo == ""))
                {
                    HitechQueryParameter paraList = new HitechQueryParameter();
                    paraList.AddQueryParameter("@BoxNo", boxNo);

                    DataSet ds = m_db.ExecuteDataSetForProcedure("IFY_Webtool_InsertScanDate", paraList);
                    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow item in ds.Tables[0].Rows)
                        {
                            AtelierScanningDTO obj = new AtelierScanningDTO();
                            obj.Id = Convert.ToInt32(item["ID"]);
                            obj.BoxNo = Convert.ToString(item["BoxNo"]);
                            obj.PreparationEndDate = Convert.ToString(item["PreparationEndDate"]);
                            obj.BoxScanDate = Convert.ToString(item["ScanDate"]);
                            objList.Add(obj);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DocflowWebTool.Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return objList;
        }


        #endregion
    }
}