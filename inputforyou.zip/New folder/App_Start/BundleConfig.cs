﻿using System.Web;
using System.Web.Optimization;

namespace DocflowWebTool
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css"));

            bundles.Add(new StyleBundle("~/Content/themes/base/css").Include(
                        "~/Content/themes/base/jquery.ui.core.css",
                        "~/Content/themes/base/jquery.ui.resizable.css",
                        "~/Content/themes/base/jquery.ui.selectable.css",
                        "~/Content/themes/base/jquery.ui.accordion.css",
                        "~/Content/themes/base/jquery.ui.autocomplete.css",
                        "~/Content/themes/base/jquery.ui.button.css",
                        "~/Content/themes/base/jquery.ui.dialog.css",
                        "~/Content/themes/base/jquery.ui.slider.css",
                        "~/Content/themes/base/jquery.ui.tabs.css",
                        "~/Content/themes/base/jquery.ui.datepicker.css",
                        "~/Content/themes/base/jquery.ui.progressbar.css",
                        "~/Content/themes/base/jquery.ui.theme.css"));

            //bundles.Add(new StyleBundle("~/assets/plugins/bootstrap/css").Include(
            //    "~/assets/plugins/bootstrap/css/bootstrap.min.css",
            //    "~/assets/plugins/bootstrap/css/bootstrap-responsive.min.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/font-awesome/css").Include(
            //    "~/assets/plugins/font-awesome/css/font-awesome.min.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/css").Include(
            //    "~/assets/css/style-metro.css",
            //    "~/assets/css/style.css",
            //    "~/assets/css/style-responsive.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/css/themes").Include(
            //    "~/assets/css/themes/default.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/css/themes").Include(
            //"~/assets/plugins/uniform/css/uniform.default.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/gritter/css").Include(
            //    "~/assets/plugins/gritter/css/jquery.gritter.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/bootstrap-daterangepicker").Include(
            //    "~/assets/plugins/bootstrap-daterangepicker/daterangepicker.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/fullcalendar/fullcalendar").Include(
            //    "~/assets/plugins/fullcalendar/fullcalendar/fullcalendar.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/jqvmap/jqvmap").Include(
            //    "~/assets/plugins/jqvmap/jqvmap/jqvmap.css"
            //    ));

            //bundles.Add(new StyleBundle("~/assets/plugins/jquery-easy-pie-chart").Include(
            //    "~/assets/plugins/jquery-easy-pie-chart/jquery.easy-pie-chart.css"
            //    ));
        }
    }
}