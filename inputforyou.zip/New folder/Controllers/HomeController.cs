﻿using DocflowWebTool.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using WebTool.Models;

namespace DocflowWebTool.Controllers
{
    public class HomeController : BaseController
    {
        public ActionResult DashBoard()
        {
            DashboardDTO objdashboardmodel = new DashboardDTO();

            ProjectBAL objProjectDao = new ProjectBAL();

            ViewBag.DashboardData = objProjectDao.GetProjectDashBoardDetails();
            //objdashboardmodel.ProjectId = objProjectDao.ProjectId;

            return View();
        }

        [HttpPost]
        public JsonResult GetBoxStatusDashBoardWorkingFoldersDetails(string projectName)
        {
            DataTable dtForCompletedFolders = new DataTable();
            DataTable dtForWorkingFolders = new DataTable();

            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            WebTool.BAL.HomeBAL objhomebal = new WebTool.BAL.HomeBAL(foundProject.ProjectConnectionString);
            DataSet ds = objhomebal.RetrieveProjectFolderStatus(projectName);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                dtForCompletedFolders = ds.Tables[0];
            }
            else
            {
                DataRow dr = dtForCompletedFolders.NewRow();
                DataColumn dc = new DataColumn("Result", typeof(string));
                dtForCompletedFolders.Columns.Add(dc);
                dr["Result"] = "No Records Found...";
                dtForCompletedFolders.Rows.Add(dr);
            }
            if (ds != null && ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
            {
                dtForWorkingFolders = ds.Tables[1];
            }
            else
            {
                DataRow dr = dtForWorkingFolders.NewRow();
                DataColumn dc = new DataColumn("Result", typeof(string));
                dtForWorkingFolders.Columns.Add(dc);
                dr["Result"] = "No Records Found...";
                dtForWorkingFolders.Rows.Add(dr);
            }
            string jsonStringForCompletedFolders = GetJson(dtForCompletedFolders);
            jsonStringForCompletedFolders = jsonStringForCompletedFolders.Replace("_", " ");
            //string jsonStringForWorkingFolders = GetJson(dtForWorkingFolders);
            //jsonStringForWorkingFolders = jsonStringForWorkingFolders.Replace("_", " ");
            //return  jsonStringForCompletedFolders;

            return Json(new { Result = "OK", Records = jsonStringForCompletedFolders }, JsonRequestBehavior.AllowGet);
        }

        public string GetJson(DataTable dt)
        {
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;

            string str = "{cols: [";

            foreach (DataColumn col in dt.Columns)
            {
                if (dt.Rows.Count > 1 && col.ColumnName.ToString() == dt.Columns[dt.Columns.Count - 1].ColumnName)
                {
                    str += "{id: '" + col.ColumnName.Trim() + "', label: '" + col.ColumnName.Trim() + "', type: 'boolean'},";
                }
                else
                {
                    str += "{id: '" + col.ColumnName.Trim() + "', label: '" + col.ColumnName.Trim() + "', type: 'string'},";
                }
            }
            if (str[str.Length - 1] == ',')
            {
                str = str.Remove(str.Length - 1, 1);
            }
            str += "], rows: [";
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                str += "{c:[";
                foreach (DataColumn col in dt.Columns)
                {
                    //if (dt.Rows.Count > 1 && col.ColumnName.ToString() == dt.Columns[dt.Columns.Count - 1].ColumnName)
                    //{
                    str += "{v: '" + Convert.ToString(dr[col]).Trim() + "'},";
                    //}
                    //else
                    //{
                    //    str += "{v: '" + Convert.ToString(dr[col]).Trim() + "'},";
                    //}

                }
                if (str[str.Length - 1] == ',')
                {
                    str = str.Remove(str.Length - 1, 1);
                }
                str += "]},";
                //rows.Add(row);
            }
            if (str[str.Length - 1] == ',')
            {
                str = str.Remove(str.Length - 1, 1);
            }
            str += "]}";

            return str;
        }



        [HttpPost]
        public JsonResult Test()
        {
            return Json(new { Result = "OK"}, JsonRequestBehavior.AllowGet);
        }
    }
}
