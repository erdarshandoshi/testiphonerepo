﻿using WebTool.BAL;
using WebTool.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Script.Services;
using System.Web.Services;
using DocflowWebTool.Utility;

namespace DocflowWebTool.Controllers
{
    public class ResetController : Controller
    {
        //
        // GET: /Reset/
        /// <summary>
        /// ResetList method in Reset Controller
        /// </summary>
        /// <returns></returns>
        #region ResetList
        public ActionResult ResetList()
        {
            ResetModel obj = new ResetModel();
            return View(obj);
        }
        [HttpPost]
        public JsonResult ResetList(string projectName, string Status, string Box = null, string Folder = null, int jtPageSize = 0, int jtStartIndex = 0, string jtSorting = null)
        {

            try
            {
                if (Status == "-1") { Status = null; }
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                WebTool.BAL.ResetBAL objResetBAL = new WebTool.BAL.ResetBAL(foundProject.ProjectConnectionString);
                int recordscount = 0;
                List<WebTool.Models.ResetDTO> objResetlst = objResetBAL.ResetList(Box, Folder, Status);
                recordscount = objResetlst.Count();
                #region Paging
                if (jtPageSize > 0)
                {
                    objResetlst = objResetlst.Skip(jtStartIndex).Take(jtPageSize).ToList();//Paging
                }
                else
                {
                    objResetlst = objResetlst.ToList();
                }
                #endregion
                return Json(new { Result = "OK", Records = objResetlst, TotalRecordCount = recordscount }, JsonRequestBehavior.AllowGet);
            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetStatus(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                ResetBAL objResetBAL = new ResetBAL(foundProject.ProjectConnectionString);
                List<StatusDTO> objstatusDTO = objResetBAL.GetStatus(projectName);
                return Json(new { Result = "OK", Records = objstatusDTO, TotalRecordCount = objstatusDTO.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetReason(string projectName)
        {
            try
            {
                var foundReason = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                ResetBAL objResetBAL = new ResetBAL(foundReason.ProjectConnectionString);
                List<ReasonDTO> objresetDTO = objResetBAL.GetReason(projectName);
                return Json(new { Result = "OK", Records = objresetDTO, TotalRecordCount = objresetDTO.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetResetStatus(string projectName, int CurrentStatus)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                ResetBAL objResetBAL = new ResetBAL(foundProject.ProjectConnectionString);
                List<ResetStatusDTO> objresetstatusDTO = objResetBAL.GetResetStatus(projectName, CurrentStatus);
                return Json(new { Result = "OK", Records = objresetstatusDTO, TotalRecordCount = objresetstatusDTO.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        [HttpPost]
        public JsonResult FolderResetStatus(string projectName, int CurrentStatus, int Reason, string Remark, int ResetToStatus, string cifIds, bool ispreservedata)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                ResetBAL objResetBAL = new ResetBAL(foundProject.ProjectConnectionString);
                long founduserId = SessionDetails.UserId;
                string[] _allCifIdList = cifIds.Split(',');
                int ret = -999;
                string msg = "";
                bool _result = true;

                for (int i = 0; i < _allCifIdList.Length; i++)
                {
                    _result = _result && objResetBAL.InsertFolderResetLogReason(CurrentStatus, ResetToStatus, Reason, Remark, founduserId, Convert.ToInt64(_allCifIdList[i]));
                }

                if (_result)
                {
                    _result = objResetBAL.SetNewFolderStatus(cifIds, CurrentStatus, ResetToStatus, ispreservedata, ref ret, ref msg);
                }
                return Json(new { Result = "OK", Records = _result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        #endregion
    }
}
