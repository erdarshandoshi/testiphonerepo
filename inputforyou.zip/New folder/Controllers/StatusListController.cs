﻿using WebTool.BAL;
using WebTool.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Data;
using System.IO;
using DocflowWebTool.Utility;

namespace DocflowWebTool.Controllers
{
    public class StatusListController : Controller
    {
        #region Fields
        List<ImageDTO> m_images = new List<ImageDTO>();
        #endregion
        //
        // GET: /Reset/
        /// <summary>
        /// ResetList method in Reset Controller
        /// </summary>
        /// <returns></returns>
        #region StatusList
        public ActionResult StatusList()
        {
            StatusListModel obj = new StatusListModel();
            return View(obj);
        }
        [HttpPost]
        public JsonResult GetStatusListRecords(string projectName, string Box = null, string Folder = null, string FromDate = null, string ToDate = null, string[][] inputvalues = null, string allcheckvalues = null)
        {
            try
            {
                List<object> result = new List<object>();
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
                if (FromDate == "" && ToDate == "")
                {
                    FromDate = "01/01/2000 00:00:01";
                    ToDate = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                }
                DateTime _sd = DateTime.Now, _ed = DateTime.Now;
                bool _dateConverted = false;
                if (!string.IsNullOrEmpty(FromDate))
                {
                    if (!DateTime.TryParseExact(FromDate.Trim(), "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                    {
                        throw new Exception("Invalid StartDate");
                    }
                    if (!DateTime.TryParseExact(ToDate.Trim(), "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                    {
                        throw new Exception("Invalid EndDate");
                    }
                    _dateConverted = true;
                }
                List<object> objlist = objStatusListBAL.RetrieveFoldersForListing((_dateConverted ? (object)_sd : (object)DBNull.Value), (_dateConverted ? (object)_ed : (object)DBNull.Value), Box, Folder, inputvalues, allcheckvalues);
                #region Change key value to json object
                if (objlist != null)
                {
                    foreach (var item in objlist)
                    {
                        string _finalResult = "{";
                        var _tmp = (item as IDictionary<string, object>);

                        object _result = "";
                        foreach (string ky in _tmp.Keys)
                        {
                            string element = "\"" + ky + "\":\"" + _tmp[ky] + "\"";
                            _result += (_result == string.Empty) ? element : "," + element;
                        }
                        _finalResult += _result + "}";

                        JavaScriptSerializer j = new JavaScriptSerializer();
                        object a = j.Deserialize(_finalResult, typeof(object));
                        result.Add(a);
                    }
                }
                #endregion
                return Json(new { Result = "OK", Records = result, TotalRecordCount = objlist.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (System.Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        public JsonResult DynamicControlsRetrive(string projectName, string fornmname = "WebViewer")
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                WebTool.BAL.StatusListBAL objStatusListBAL = new WebTool.BAL.StatusListBAL(foundProject.ProjectConnectionString);
                List<WebTool.Models.DynamicControlDetailsDTO> objList = objStatusListBAL.DynamicControlsRetrive(projectName, fornmname).ToList();
                return Json(new { Result = "OK", Records = objList, TotalRecordCount = objList.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetFolderStatus(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
                Dictionary<string, string> obj = objStatusListBAL.GetFolderStatus(projectName);
                return Json(new { Result = "OK", Records = obj, TotalRecordCount = obj.Count }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetHeaders(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
                //List<Dictionary<string, object>> objlst = new  List<Dictionary<string, object>>;
                //Dictionary<string, object> objdict = objStatusListBAL.GetHeaders(projectName);
                Dictionary<string, object> objdict = new Dictionary<string, object>();
                objdict.Add("cifid", new { key = true, list = false });
                objdict.Add("boxid", new { list = true, title = "Box Number" });
                objdict.Add("folderid", new { list = true, title = "Folder Number" });
                objdict.Add("folderstatus", new { list = true, title = "Folder Status" });

                //List<string> objDyColumnList = new List<string>(); // bal.GetHeaders(projectName)
                //int _dyCol = 1;
                //foreach (string item in objDyColumnList)
                //{
                //    objdict.Add("Free" + _dyCol.ToString(), new { list = true, title = item });
                //    _dyCol++;
                //}

                var obj = objStatusListBAL.GetHeaders(projectName);
                int _dyCol = 1;
                foreach (var item in obj)
                {
                    //objdict.Add("Free" + _dyCol.ToString(), new { list = true, title = item.HeaderName, Width = item.width });
                    objdict.Add(item.HeaderName.Trim().ToLower().Replace(" ", ""), new { list = true, title = item.HeaderName, Width = item.width });
                    _dyCol++;
                }


                return Json(objdict, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetMoreDetails(string projectName, string Id)
        {
            List<WebTool.Models.TextValueCollection> objValues = new List<WebTool.Models.TextValueCollection>();
            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
            int cifId = Utility.Utilities.SafeCastToInt(Id);
            if (cifId > 0)
            {

                DataSet ds = objStatusListBAL.RetrieveFolderDetails(cifId);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow item = ds.Tables[0].Rows[0];
                    //    int _transferedCount = 0, _producedCount = 0;
                    //    if (objStatusListBAL.AllProcess != null && objStatusListBAL.AllProcess.Count > 0)
                    //    {
                    //        _producedCount = objStatusListBAL.AllProcess.Count(p => p.ProcessName == "Production");
                    //        _transferedCount = objStatusListBAL.AllProcess.Count(p => p.ProcessName == "Transfer");
                    //    }
                    objValues.Add(new WebTool.Models.TextValueCollection("BoxNo", Convert.ToString(item["boxId"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("FolderNo", Convert.ToString(item["folderId"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Scan Date", Convert.ToString(item["ScannedDate"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Enx FileName", Convert.ToString(item["EnxFileName"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Operator", Convert.ToString(item["Operator"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Preparator", Convert.ToString(item["Preparator"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Machine", Convert.ToString(item["Machine"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Total Scans", Convert.ToString(item["totalImages"])));
                    objValues.Add(new WebTool.Models.TextValueCollection("Cleanuped Scans", Convert.ToString(item["CleanupImages"])));
                    //objValues.Add(new TextValueCollection("Produced", _producedCount.ToString()));
                    //objValues.Add(new TextValueCollection("Transfered", _transferedCount.ToString()));
                }
                //return objValues;
            }
            return Json(new { Result = "OK", Records = objValues }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetProcessDetails(string projectName, string Id)
        {
            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
            string[] _processNames;
            if (projectName == "DKV")
            {
                _processNames = new string[] { "Identified", "Cleanup", "DTONE", "DTTWO", "DTQC", "Production", "QC" };
            }
            else if (projectName == "HDP")
            {
                _processNames = new string[] { "Identification", "CleanupInBulk", "Production", "QA", "Transfer" };
            }
            else if (projectName == "SWDE" || projectName == "VMW" || projectName == "VMMA" || projectName == "ZNA" || projectName == "EEG" || projectName == "MACTAC" || projectName == "CHR" || projectName == "IPA" || projectName == "ADVALVAS" || projectName == "MENSURA" || projectName == "ETHIASFE")
            {
                _processNames = new string[] { "CleanupInBulk", "DTONE", "DTTWO", "DTQC", "Production", "QA", "Transfer" };
            }
            else if (projectName == "WHESTIA" || projectName == "CNA" || projectName == "ETAT" || projectName == "ETHIASMS")
            {
                _processNames = new string[] { "Scanning", "CleanupInBulk", "Identification", "Production", "Transfer" };
            }
            else
            {
                _processNames = new string[] { "CleanupInBulk", "DTONE", "DTTWO", "DTQC", "Production", "QA", "Transfer" };
            }
            List<ProcessModel> objProcessModelList = new List<ProcessModel>();
            try
            {
                int cifId = Utility.Utilities.SafeCastToInt(Id);
                if (cifId > 0)
                {
                    if (!string.IsNullOrEmpty((ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()]).ProjectConnectionString))
                    {
                        //BAL.ViewerListBAL _viewerListBAL = new BAL.ViewerListBAL(Utility.SessionDetails.ProjectConnectionString);
                        DataSet ds = objStatusListBAL.RetrieveFolderDetails(cifId);

                        var _data = objStatusListBAL.AllProcess;
                        foreach (var singleProcess in _processNames)
                        {
                            var foundRow = _data.Find(p => Convert.ToString(p.ProcessName) == singleProcess);
                            string _userName = string.Empty, _startDate = string.Empty, _endDate = string.Empty, _timeTaken = string.Empty, _processName = string.Empty;
                            if (foundRow != null)
                            {
                                _processName = Convert.ToString(singleProcess);
                                _userName = Convert.ToString(foundRow.ProcessOperator);
                                _startDate = Convert.ToString(foundRow.StartTime);
                                _endDate = Convert.ToString(foundRow.EndTime);
                                _timeTaken = Convert.ToString(foundRow.TimeTaken);
                            }
                            else
                            {
                                _processName = Convert.ToString(singleProcess);
                            }
                            objProcessModelList.Add(new ProcessModel()
                            {
                                ProcessName = _processName,
                                ProcessOperator = _userName,
                                StartTime = _startDate,
                                EndTime = _endDate,
                                IsCompleted = (foundRow != null),
                                TimeTaken = _timeTaken
                            });
                        }
                    }
                }
                else
                {
                    Utility.Logger.WriteLog(new Exception("Invalid CifId : " + Id));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Json(new { Result = "OK", Records = objProcessModelList }, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult ProductionView(string projectName, long Id)
        {
            StatusListModel model = new StatusListModel();
            model.CifId = Id;
            ViewBag.ProjectName = projectName;
            if (TempData["totalImages"] != null)
            {
                model.TotalImages = Convert.ToInt32(TempData["totalImages"]);
            }
            return View(model);
        }


        [HttpGet]
        public ActionResult RawView(int id)
        {
            return View();
        }

        [HttpPost]
        public JsonResult LoadImages(string projectName, long cifId, int pageSize, int pageIndex)
        {
            int totalImages = 0;
            try
            {
                System.Diagnostics.Debug.WriteLine("LoadImages called");
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                StatusListBAL objStatusListBAL = new StatusListBAL(foundProject.ProjectConnectionString);
                // BAL.StatusListBAL objStatusListBAL = new BAL.StatusListBAL();
                m_images = objStatusListBAL.RetrieveImages(projectName, cifId, pageSize, pageIndex, false);
                totalImages = objStatusListBAL.TotalImages;

                //lblTotalImages.Text = totalImages.ToString();
                //lblTotalPage.Text = ((totalImages / pageSize) + 1).ToString();
                //lblFromTonumber.Text = "From " + ((pageSize * (pageIndex - 1)) + 1) + " To " + (((pageSize * pageIndex) < totalImages) ? (pageSize * pageIndex) : totalImages);


                // this.SetNavigationControl();

                if (m_images != null && m_images.Count > 0)
                {
                    //lblBoxNumber.Text = m_images[0].BoxNo;
                    //lblFolderNo.Text = m_images[0].FolderNo;


                    System.Diagnostics.Debug.WriteLine("calling ImpersonateValidUser() func from LoadImages");
                    //if (Utility.Win32API.ImpersonateValidUser())
                    //{
                    System.Diagnostics.Debug.WriteLine("ImpersonateValidUser() successfull");

                    foreach (var img in m_images)
                    {
                        string _path = string.Empty;

                        foreach (string s in objStatusListBAL.SourceRoots)
                        {
                            try
                            {
                                //if (Utility.Win32API.ImpersonateValidUser())
                                {
                                    string _temppath = Path.Combine(s, Path.Combine(img.BoxNo, Path.Combine(img.FolderNo, ((img.IsColored) ? img.ConjugateFileName : img.FileName))));
                                    System.IO.FileInfo _tempfi = new FileInfo(_temppath);
                                    bool _tempFile = _tempfi.Exists;
                                    if (_tempFile)
                                    {
                                        _path = Path.Combine(s, Path.Combine(img.BoxNo, Path.Combine(img.FolderNo, ((img.IsColored) ? img.ConjugateFileName : img.FileName))));
                                        break;
                                    }
                                    System.Diagnostics.Debug.WriteLine("Break from Path => " + _path);
                                }
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine("No any Path value.. it fails.." + ex.Message);
                            }

                        }

                        //System.IO.FileInfo _fi = new FileInfo(_path);
                        //if (_fi.Exists)
                        //{
                        try
                        {
                            if (_path.Trim().ToLower().EndsWith(".jpg") || _path.Trim().ToLower().EndsWith(".jpeg"))
                            {
                                img.Height = 180;
                                img.Width = 140;
                                img.ImageLocation = _path;
                                //img.Base64 = Utility.ImageHelper.GetMagickImageBase64String(_path, true, false);
                            }
                            else
                            {
                                img.Height = 180;
                                img.Width = 140;
                                img.ImageLocation = _path;
                                //img.Base64 = Utility.ImageHelper.GetMagickImageBase64String(_path, true, false);
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine("Got an error => " + ex.Message);
                            Utility.Logger.WriteLog(ex);
                        }
                        //}
                        //else
                        //{
                        //    //Utility.Logger.WriteLog(new Exception("File does not exist at " + _fi.FullName));
                        //    System.Diagnostics.Debug.WriteLine("file doesn't exist on " + _fi.FullName);
                        //}
                    }
                    //   Utility.Win32API.UndoImpersonation();
                    //}
                    //    //else
                    //    //{
                    //    //    throw new Exception("Unable to Impersonate User");
                    //    //}
                    //    //else
                    //    //{
                    //    //    string _nasUN = string.Empty;
                    //    //    string _nasPW = string.Empty;
                    //    //    UserDTO _userDTO = (System.Web.HttpContext.Current.Session["LoggedUser"] as UserDTO);
                    //    //    foreach (var _key in System.Configuration.ConfigurationManager.AppSettings.AllKeys)
                    //    //    {
                    //    //        if (_key.StartsWith("DataPath_"))
                    //    //        {
                    //    //            string[] _strArr = _key.Split('_');
                    //    //            if (_strArr.Length > 2)
                    //    //            {
                    //    //                string _path = _strArr[2];
                    //    //                if (_userDTO.ProjectPaths[0].Contains(_path))
                    //    //                {
                    //    //                    string _encryptedCredintials = System.Configuration.ConfigurationManager.AppSettings[_key];
                    //    //                    string _decryptedCredintials = Utility.Utilities.DecodeFrom64(_encryptedCredintials);
                    //    //                    string[] _credintials = _decryptedCredintials.Split('_');
                    //    //                    _nasUN = _credintials[0];
                    //    //                    _nasPW = _credintials[1];
                    //    //                }
                    //    //            }
                    //    //        }
                    //    //    }
                    //    //    Utility.Logger.WriteLog(new Exception("Imperonating fail... \nUN : " + _nasUN + "\t PW : " + _nasPW));
                    //    //}
                    //    UcImagePanel1.DataSource = m_images;
                    //    UcImagePanel1.DataBind();

                }
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
            }
            return Json(new { Result = "OK", ImageList = m_images, TotalImages = totalImages }, JsonRequestBehavior.AllowGet);
        }

    }




        #endregion



}


