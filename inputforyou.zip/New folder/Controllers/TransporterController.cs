﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.Models;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using System.Web.Services;
using System.Web.Script.Services;
using System.IO;
using WebTool.BAL;
using DocflowWebTool.Utility;

namespace DocflowWebTool.Controllers
{
    public class TransporterController : TransporterBaseController
    {
        public ActionResult UpdateRecord(string Id = null)
        {
            TransporterModel data = null;
            try
            {
                if (Session["SecondLoginModel"] != null && Session["SecondLoginModel"] is SecondLoginModel)
                {
                    SecondLoginModel obj = Session["SecondLoginModel"] as SecondLoginModel;
                    var foundproject = ProjectDetails.ProjectInfo[obj.ProjectName];
                    data = new TransporterModel();

                    WebTool.BAL.TransporterBAL objBal = new TransporterBAL(ProjectDetails.ProjectInfo[obj.ProjectName].ProjectConnectionString);
                    var result = objBal.GetTransporterDetailsFromID(Convert.ToInt32(Id));
                    foreach (var item in result)
                    {
                        data.BoxNo = item.BoxNo;
                        data.Batch = item.Batch;
                        data.DestinationLocation = item.DestinationLocation;
                        data.Folders = item.TotalFolder;
                    }

                    if (TempData["IsBagBatchBox"] != null && TempData["IsBoxBatchBox"] != null && TempData["BoxLength"] != null)
                    {
                        data.IsBagBatchBox = Convert.ToBoolean(TempData["IsBagBatchBox"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                    }
                    else
                    {
                        data.IsBox = foundproject.IsBox;
                        data.IsBagBatchBox = foundproject.IsBagBatchBox;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                    }
                    data.RecordId = Utility.Utilities.SafeCastInt(Id);

                    data.ProjectName = obj.ProjectName;
                    data.TransporterName = obj.Operator;
                    data.StartLocation = foundproject.StartingLocation;

                    data.PickDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    data.BoxLength = foundproject.BoxLength;
                    ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                    if (!string.IsNullOrEmpty(Request.QueryString["pid"]))
                    {
                        data.DestinationLocation = Request.QueryString["pid"];
                        ViewBag.Destination = Request.QueryString["pid"];
                    }
                    SetViewBagWarning("Record is open for Update...");
                    return View("Index", data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Transporter");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        public ActionResult Index(string BoxNo = null)
        {
            TransporterModel data = null;
            try
            {
                if (Session["SecondLoginModel"] != null && Session["SecondLoginModel"] is SecondLoginModel)
                {
                    SecondLoginModel obj = Session["SecondLoginModel"] as SecondLoginModel;
                    var foundproject = ProjectDetails.ProjectInfo[obj.ProjectName];
                    data = new TransporterModel();

                    if (TempData["IsBagBatchBox"] != null && TempData["IsBoxBatchBox"] != null && TempData["BoxLength"] != null)
                    {
                        data.IsBagBatchBox = Convert.ToBoolean(TempData["IsBagBatchBox"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                    }
                    else
                    {
                        data.IsBox = foundproject.IsBox;
                        data.IsBagBatchBox = foundproject.IsBagBatchBox;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                    }
                    data.Batch = string.Empty;

                    data.ProjectName = obj.ProjectName;
                    data.TransporterName = obj.Operator;
                    data.StartLocation = foundproject.StartingLocation;

                    data.PickDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    data.BoxLength = foundproject.BoxLength;
                    ViewBag.PartnerList = new WebTool.BAL.PartnerBAL().GetAllPartners();
                    ViewBag.BoxNo = BoxNo;
                    if (!string.IsNullOrEmpty(Request.QueryString["pid"]))
                    {
                        data.DestinationLocation = Request.QueryString["pid"];
                        ViewBag.Destination = Request.QueryString["pid"];
                    }
                    else
                    {
                        data.DestinationLocation = "AtelierFoes";
                    }
                    if (TempData["LastSuccessBox"] != null && Convert.ToString(TempData["LastSuccessBox"]) != string.Empty)
                    {
                        SetViewBagSuccess(string.Format("Last box entered {0}", TempData["LastSuccessBox"]));
                    }
                    return View(data);

                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Transporter");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        [HttpPost]
        public ActionResult Index(TransporterModel data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                   TransporterBAL objTransporterBAL = new TransporterBAL(ProjectDetails.ProjectInfo[data.ProjectName].ProjectConnectionString);

                    if (data.RecordId > 0)
                    {
                        //code for update and redirect to listing
                        objTransporterBAL.UpdateTransportDetails(data, SessionDetails.UserId);
                        return RedirectToAction("ListBoxDetails", "Transporter");
                    }
                    else
                    {
                        objTransporterBAL.AddBoxDetail(data, SessionDetails.SecondLoginInfo.Operator, SessionDetails.UserId);
                        TempData["LastSuccessBox"] = data.BoxNo;
                        TempData["IsBagBatchBox"] = data.IsBagBatchBox;
                        TempData["IsBoxBatchBox"] = data.IsBoxBatchBox;
                        if (!data.IsBoxBatchBox)
                        {
                            return RedirectToAction("Index", "Transporter", new { pid = data.DestinationLocation });
                        }
                        else
                        {
                            return RedirectToAction("Index", "Transporter", new { pid = data.DestinationLocation, BoxNo = data.BoxNo });
                        }
                    }
                }
                else
                {
                    ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                    return View(data);
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        /// <summary>
        /// this function will be used for verify project details
        /// </summary>
        /// <returns></returns>
        public ActionResult VerifyProject()
        {
            SecondLoginModel obj = new SecondLoginModel();
            if (TempData["Warning"] != null)
            {
                SetViewBagWarning(Convert.ToString(TempData["Warning"]));
            }
            if (!string.IsNullOrEmpty(Request.QueryString["pn"]))
            {
                obj.ProjectName = Request.QueryString["pn"];
            }
            return View(obj);
        }


        [HttpPost]
        public ActionResult VerifyProject(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
                WebTool.Models.SecondLoginModel objSession2 = new WebTool.Models.SecondLoginModel();
                objSession2.Operator = collection["Operator"];
                objSession2.ProjectName = collection["ProjectName"];
                Session["SecondLoginModel"] = objSession2;
                //string s = DocflowWebTool.Utility.Utilities.EncodeTo64(string.Format("ProjectName={0}&TransporterName={1}", _pn, _tn));
                return RedirectToAction("Index", "Transporter");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult Logout()
        {
            Session.Remove("SecondLoginModel");
            return RedirectToAction("VerifyProject");
        }

        public JsonResult IsValidBox(string BoxNo, int BoxLength)
        {
            return Json((BoxNo.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsValidTransportBox(string BoxNo, int BoxLength, bool IsBox)
        {
            if (!IsBox) return Json(true, JsonRequestBehavior.AllowGet);
            return Json((BoxNo.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsValidTransportBatch(string Batch, int BoxLength, bool IsBox)
        {
            if (IsBox) return Json(true, JsonRequestBehavior.AllowGet);
            return Json((Batch.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }


        public ActionResult ListBoxDetails()
        {
            if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
            {
                ViewBag.ProjectName = SessionDetails.SecondLoginInfo.ProjectName;
                return View();
            }
            else
            {
                TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                return RedirectToAction("VerifyProject", "Transporter");
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetTransportBoxDetails(string boxNo, string batch, string partnerName, string startDateTime, string endDateTime, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                TransporterBAL objTransporterBAL = null;
                List<TransporterDTO> objResultList = new List<TransporterDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    objTransporterBAL = new TransporterBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    //objResultList = objTransporterBAL.GetTransportBoxDetails(boxNo, partnerName, SessionDetails.SecondLoginInfo.Operator, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                    objResultList = objTransporterBAL.GetTransportBoxDetails(boxNo, batch, partnerName, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                }
                return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = objTransporterBAL.TotalRecordCount });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetTransportBoxDetailsExcel(string boxNo, string batch, string partnerName, string startDateTime, string endDateTime, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
               TransporterBAL objTransporterBAL = null;
                List<TransporterDTO> objResultList = new List<TransporterDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    objTransporterBAL = new TransporterBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    objResultList = objTransporterBAL.GetTransportBoxDetails(boxNo, batch, partnerName, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                }
                return new { Result = "OK", Records = objResultList, TotalRecordCount = objTransporterBAL.TotalRecordCount };

            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }

        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetBoxListInExcel(string boxNo, string batch, string StartDate, string endDate, string destinationLocation, string fields, string receptionId)
        {
            try
            {
                var result = this.GetTransportBoxDetailsExcel(boxNo, batch, destinationLocation, StartDate, endDate, 0, 10000, "TransportDate DESC");
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<TransporterDTO>;
                if (objList == null || objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion


                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(TransporterDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];

                    string[] _allIds = receptionId.TrimStart(',').TrimEnd(',').Split(',');

                    for (int m = 0; m < _allIds.Length; m++)
                    {
                        if (_allIds[m] == "")
                        {
                            _allIds[m] = "0";
                        }
                        if (item.Id == Convert.ToInt64(_allIds[m]))
                        {
                            IRow _row = _sheet.CreateRow(_currentRowCount++);
                            for (int j = 0; j < _columns.Length; j++)
                            {
                                var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                                if (foundProp != null)
                                {
                                    _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                                    _row.GetCell(j).SetCellType(CellType.String);
                                }
                            }
                        }
                    }

                    //for (int m = 0; m < _allIds.Length; m++)
                    //{
                    //    if (item.Id == Convert.ToInt64(_allIds[m]))
                    //    {
                    //        IRow _row = _sheet.CreateRow(_currentRowCount++);
                    //        for (int j = 0; j < _columns.Length; j++)
                    //        {
                    //            var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                    //            if (foundProp != null)
                    //            {
                    //                _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                    //                _row.GetCell(j).SetCellType(CellType.String);
                    //            }
                    //        }
                    //    }
                    //}
                    //}
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", boxNo, StartDate))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        #region Delete AND Edit Trasporter Details

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object DeleteTrasporterDetails(long trasporterId)
        {
            TransporterBAL _transporterBAL = new TransporterBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
            try
            {
                _transporterBAL.DeleteTransportInfo(trasporterId);
                return Json(new { Message = "Record Deleted Successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //[WebMethod]
        //[ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        //public object UpdateTransportBoxDetails(TransporterDTO record)
        //{
        //    BAL.TransporterBAL _transporterBAL = new BAL.TransporterBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
        //    try
        //    {
        //        _transporterBAL.UpdateTransportDetails(record, SessionDetails.UserId);
        //        return new { Result = "OK" };
        //    }
        //    catch (Exception ex)
        //    {
        //        string _errorMsg = ex.Message;
        //        if (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message))
        //        {
        //            _errorMsg = "Unable to do operation... <br />Developer Info: <br />" + ex.InnerException.Message;
        //        }
        //        Utility.Logger.WriteLog(ex);
        //        return new { Result = "ERROR", Message = _errorMsg };
        //        //return new { Result = "ERROR", Message = ex.Message };
        //    }
        //}


        #endregion
    }
}
