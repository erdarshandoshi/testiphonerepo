﻿using WebTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using DocflowWebTool.Utility;

namespace DocflowWebTool.Controllers
{
    public class RightsController : Controller
    {
        //
        // GET: /Rights/
        [HttpGet]
        public ActionResult RightsList()
        {
            RightsModel objmodel = new RightsModel();
            //if (ViewData["moduleNames"] != null)
            //if (TempData["moduleNames"] != null)
            //{
            //    objmodel.ModuleDetailNames = TempData["moduleNames"] as List<SelectListItem>;
            //}
            return View(objmodel);
        }
        [HttpPost]
        public JsonResult RightsList(string projectName, string ModuleName)
        {
            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            RightsBAL objRightsBAL = new WebTool.BAL.RightsBAL(foundProject.ProjectConnectionString);

            List<WebTool.Models.RightsModel> objrightslst = objRightsBAL.RightsList(projectName, ModuleName).Where(p => !p.MarkAsDeleted).ToList();

            return Json(new { Result = "OK", Records = objrightslst, TotalRecordCount = objrightslst.Count }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult InsertUpdateRights(string projectName, RightsDTO record)
        {
            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            RightsBAL objRightsBAL = new RightsBAL(foundProject.ProjectConnectionString);
            bool result = objRightsBAL.InsertUpdateRights(projectName, record);
            return Json(new { Result = (result ? "OK" : "Error"), Record = record, Message = "Unable to create/update data." }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteRights(string projectName, int ModuleId)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objRightsBAL = new RightsBAL(foundProject.ProjectConnectionString);
                bool result = objRightsBAL.DeleteRights(projectName, ModuleId);
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult GetRoleList(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                UserBAL objUserBAL = new UserBAL(foundProject.ProjectConnectionString);
                var objRoleDTO = objUserBAL.GetRoleList(projectName).Select(x => new { DisplayText = x.UserType, Value = x.UserTypeId });
                return Json(new { Result = "OK", Options = objRoleDTO }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetUserList(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objUserBAL = new RightsBAL(foundProject.ProjectConnectionString);
                var objUserDTO = objUserBAL.GetUserList(projectName).Select(x => new { DisplayText = x.UserName, Value = x.userId });
                return Json(new { Result = "OK", Options = objUserDTO }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetAllModuleName(string projectName)
        {
            try
            {
                RightsModel objmodel = new RightsModel();
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objRightsBAL = new WebTool.BAL.RightsBAL(foundProject.ProjectConnectionString);
                List<WebTool.Models.RightsModel> lstmodulename = objRightsBAL.GetModuleList(projectName).Where(p => !p.MarkAsDeleted).ToList();
                List<SelectListItem> _ObjModuleDetailNames = new List<SelectListItem>();
                objmodel.ModuleDetailNames = new List<SelectListItem>();
                //_ObjModuleDetailNames.Add(new SelectListItem { Text = "Select All", Value = "0" });
                foreach (var item in lstmodulename)
                {
                    _ObjModuleDetailNames.Add(new SelectListItem { Text = item.ModuleName, Value = item.ModuleId.ToString() });
                }
                objmodel.ModuleDetailNames = _ObjModuleDetailNames;
                return Json(new { Result = "OK", Options = _ObjModuleDetailNames }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetUserModuleName(string projectName, long userId)
        {
            try
            {
                RightsModel objmodel = new RightsModel();
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objRightsBAL = new RightsBAL(foundProject.ProjectConnectionString);
                //List<Models.RightsModel> lstmodulename = objRightsBAL.GetModuleList(projectName).Where(p => !p.MarkAsDeleted).ToList();
                List<RightsModel> lstmodulename = objRightsBAL.GetUserModuleName(projectName, userId).ToList();
                List<SelectListItem> _ObjModuleDetailNames = new List<SelectListItem>();
                objmodel.ModuleDetailNames = new List<SelectListItem>();
                foreach (var item in lstmodulename)
                {
                    _ObjModuleDetailNames.Add(new SelectListItem { Text = item.ModuleName, Value = item.ModuleId.ToString() });
                }
                objmodel.ModuleDetailNames = _ObjModuleDetailNames;
                return Json(new { Result = "OK", Options = _ObjModuleDetailNames }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult InsertUpdateRoleRights(string projectName, int RoleId, string ModuleListId)
        {
            try
            {
                RightsModel objmodel = new RightsModel();
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objRightsBAL = new RightsBAL(foundProject.ProjectConnectionString);
                List<RightsModel> lstUsers = objRightsBAL.GetUsersByRole(projectName, RoleId).ToList();
                List<string> _modulesIds = ModuleListId.Split(',').ToList();
                bool _modulestatus = true;
                foreach (var item in lstUsers)
                {
                    foreach (var _moduleid in _modulesIds)
                    {
                        var _userId = item.UserId;
                        objRightsBAL.GetInsertUpdateUserRights(projectName, _userId, Math.Abs(Convert.ToInt16(_moduleid)).ToString(), Convert.ToInt16(_moduleid) > 0);
                    }
                }
                return Json(new { Result = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        [HttpPost]
        public JsonResult InsertUpdateUserRights(string projectName, int UserId, string ModuleListId)
        {
            try
            {
                RightsModel objmodel = new RightsModel();
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                RightsBAL objRightsBAL = new RightsBAL(foundProject.ProjectConnectionString);
                List<string> _modulesIds = ModuleListId.Split(',').ToList();
                foreach (var _moduleid in _modulesIds)
                {
                    objRightsBAL.GetInsertUpdateUserRights(projectName, UserId, Math.Abs(Convert.ToInt16(_moduleid)).ToString(), Convert.ToInt16(_moduleid) > 0);

                }
                return Json(new { Result = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




    }
}
