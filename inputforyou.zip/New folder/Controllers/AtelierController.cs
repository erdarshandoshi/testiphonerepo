using DocflowWebTool.Utility;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Services;
using System.Web.Services;
using WebTool.BAL;
using WebTool.Models;

namespace DocflowWebTool.Controllers
{
    public class AtelierController : AtelierBaseController
    {
        #region Verify Proeject
        /// <summary>
        /// Load of page
        /// </summary>
        /// <returns></returns>
        public ActionResult VerifyProject()
        {
            //SecondLoginModel objModel = new SecondLoginModel() { ProjectName = "ETHIASPE", Operator = "Test1Operator", Process = "PreparationEnd" };
            SecondLoginModel obj = new SecondLoginModel();
            if (TempData["Warning"] != null)
            {
                SetViewBagWarning(Convert.ToString(TempData["Warning"]));
            }
            if (!string.IsNullOrEmpty(Request.QueryString["pn"]))
            {
                obj.ProjectName = Request.QueryString["pn"];
            }
            //return View(objModel);
            return View(obj);

        }

        /// <summary>
        /// this function will be used for verify project details
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult VerifyProject(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
               SecondLoginModel objSession2 = new SecondLoginModel();
                //objSession2.Operator = collection["Operator"];
                objSession2.ProjectName = collection["ProjectName"];
                objSession2.Process = Convert.ToString(collection["Process"]);
                Session["SecondLoginModel"] = objSession2;
                if (objSession2.Process.Trim() == "Reception")
                {
                    return RedirectToAction("Reception", "Atelier");
                }
                else if (objSession2.Process.Trim() == "PreparationStart")
                {
                    return RedirectToAction("PreparationStart", "Atelier");
                }
                else if (objSession2.Process.Trim() == "PreparationEnd")
                {
                    return RedirectToAction("PreparationEnd", "Atelier");
                }
                else if (objSession2.Process.Trim() == "Transport")
                {
                    return RedirectToAction("Transport", "Atelier");
                }
                else if (objSession2.Process.Trim() == "View")
                {
                    return RedirectToAction("ViewBox", "Atelier");
                }
                else if (objSession2.Process.Trim() == "Palette")
                {
                    return RedirectToAction("Palette", "Atelier");
                }
                else if (objSession2.Process.Trim() == "Scanning")
                {
                    return RedirectToAction("Scanning", "Atelier");
                }
                else
                {
                    this.SetViewBagError("No Process Found... Please select proper process.");
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

        #endregion

        #region Logout
        public ActionResult Logout()
        {
            if (Session["SecondLoginModel"] != null)
            {
                Session.Remove("SecondLoginModel");
            }
            return RedirectToAction("VerifyProject");
        }
        #endregion

        public JsonResult IsValidBox(string BoxNo, int BoxLength)
        {
            return Json((BoxNo.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsValidTransportBox(string BoxNo, int BoxLength, bool IsBox)
        {
            if (!IsBox) return Json(true, JsonRequestBehavior.AllowGet);
            return Json((BoxNo.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsValidTransportBoxForAttelierFoes(string BoxBatch, int BoxLength, bool IsBox)
        {
            if (!IsBox) return Json(true, JsonRequestBehavior.AllowGet);
            return Json((BoxBatch.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsValidTransportBatch(string Batch, int BoxLength, bool IsBox)
        {
            if (IsBox) return Json(true, JsonRequestBehavior.AllowGet);
            return Json((Batch.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        #region Reception - Adding box
        public ActionResult Reception()
        {
            AtelierReceptionModel data = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    data = new AtelierReceptionModel();

                    if (TempData["IsBagBatchBox"] != null && TempData["IsBoxBatchBox"] != null && TempData["BoxLength"] != null && TempData["IsProjectNameInBarcode"] != null)
                    {
                        data.IsBagBatchBox = Convert.ToBoolean(TempData["IsBagBatchBox"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                        data.BoxLength = Convert.ToString(TempData["BoxLength"]);
                        data.IsProjectNameInBarcode = Convert.ToBoolean(TempData["IsProjectNameInBarcode"]);
                    }
                    else
                    {
                        var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                        data.IsBox = foundproject.IsBox;
                        data.IsBagBatchBox = foundproject.IsBagBatchBox;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                        data.BoxLength = foundproject.BoxLength;
                        data.IsProjectNameInBarcode = foundproject.IsProjectNameInBarcode;
                    }
                    data.Batch = string.Empty;
                    data.RecieveDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    if (TempData["LastSuccessBox"] != null)
                    {
                        SetViewBagSuccess(string.Format("Last {0} entered {1}", (data.IsBagBatchBox ? "Bag-Batch-Box" : (data.IsBoxBatchBox ? "Box-Batch-Box" : "Box")), (data.IsBagBatchBox ? "Bag^N" : (Convert.ToString(TempData["LastSuccessBox"]) + "-" + Convert.ToString(TempData["LastSuccessBatch"])))));
                        if (data.IsBoxBatchBox)
                        {
                            data.BoxNo = Convert.ToString(TempData["LastSuccessBox"]);
                            ViewBag.BoxNo = data.BoxNo;
                        }
                    }
                    return View(data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        [HttpPost]
        public ActionResult Reception(WebTool.Models.AtelierReceptionModel data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    TempData["IsProjectNameInBarcode"] = data.IsProjectNameInBarcode;
                    AttlierBAL objPickingBAL = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    if (data.IsBoxBatchBox && data.IsProjectNameInBarcode)
                    {
                        data.Batch = data.Batch.Replace(SessionDetails.SecondLoginInfo.ProjectName, "");
                    }
                    objPickingBAL.AddReceptionBox(data, data.Operator, SessionDetails.UserId);

                    TempData["IsBagBatchBox"] = data.IsBagBatchBox;
                    TempData["IsBoxBatchBox"] = data.IsBoxBatchBox;
                    TempData["BoxLength"] = data.BoxLength;
                    TempData["Operator"] = data.Operator;


                    if (!data.IsBagBatchBox)
                    {
                        TempData["LastSuccessBox"] = data.BoxNo;
                        TempData["LastSuccessBatch"] = data.Batch;
                    }
                    return RedirectToAction("Reception", "Atelier", new { OperatorName = data.Operator });
                }
                else
                {
                    return View(data);
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View(data);
            }
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object DeleteReceptionDetails(long Id)
        {
            AttlierBAL _transporterBAL = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
            try
            {
                _transporterBAL.DeleteReceptionInfo(Id);
                return Json(new { Message = "Record Deleted Successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region List Reception Boxes
        public ActionResult ListBoxDetails()
        {
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    ViewBag.IsBagBatchBox = foundProject.IsBagBatchBox;
                    ViewBag.IsBoxBatchBox = foundProject.IsBoxBatchBox;
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
            }
            return View();
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetReceptionBoxDetails(string boxNo, string batch, string operatorName, string startDateTime, string endDateTime, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                if (boxNo == "undefined")
                {
                    boxNo = string.Empty;
                }
                if (batch == "undefined")
                {
                    batch = string.Empty;
                }
                AttlierBAL objAttlierBAL = null;
                List<AtelierReceptionDTO> objResultList = new List<AtelierReceptionDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objAttlierBAL = new AttlierBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objAttlierBAL.GetAtelierReceptionBoxDetails(boxNo, batch, operatorName, _st, _et, foundProject.IsBagBatchBox, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetReceptionBoxDetailsExcel(string boxNo, string batch, string operatorName, string startDateTime, string endDateTime, int jtStartIndex, int jtPageSize, string jtSorting)
        {

            try
            {
                if (boxNo == "undefined")
                {
                    boxNo = string.Empty;
                }
                if (batch == "undefined")
                {
                    batch = string.Empty;
                }
               AttlierBAL objAttlierBAL = null;
                List<AtelierReceptionDTO> objResultList = new List<AtelierReceptionDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objAttlierBAL = new AttlierBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objAttlierBAL.GetAtelierReceptionBoxDetails(boxNo, batch, operatorName, _st, _et, foundProject.IsBagBatchBox, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord };

                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }

            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }

        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetReceptionBoxDetailsInExcel(string boxNo, string batch, string operatorName, string startDateTime, string endDateTime, string fields)
        {
            try
            {
                var result = this.GetReceptionBoxDetailsExcel(boxNo, batch, operatorName, startDateTime, endDateTime, 0, 10000, "RecievedTime DESC");
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<AtelierReceptionDTO>;
                if (objList == null || objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(AtelierReceptionDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", boxNo, startDateTime))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }
        #endregion

        #region Preparation
        public ActionResult PreparationStart()
        {
            AtelierPreparationModel data = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    data = new AtelierPreparationModel();
                    data.IsBatchAlreadyStarted = false;
                    if (TempData["IsBag"] != null && TempData["BoxBatchLength"] != null && TempData["IsProjectNameInBarcode"] != null && TempData["IsBoxBatchBox"] != null)
                    {
                        data.IsBag = Convert.ToBoolean(TempData["IsBag"]);
                        data.BoxBatchLength = Convert.ToString(TempData["BoxBatchLength"]);
                        data.IsProjectNameInBarcode = Convert.ToBoolean(TempData["IsProjectNameInBarcode"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                    }
                    else
                    {
                        var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                        data.IsBag = foundproject.IsBagBatchBox;
                        data.BoxBatchLength = foundproject.BoxLength;
                        data.IsProjectNameInBarcode = foundproject.IsProjectNameInBarcode;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                    }
                    data.BoxBatchNo = string.Empty;
                    data.RecieveDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    if (TempData["LastSuccessBox"] != null)
                    {
                        SetViewBagSuccess(string.Format("Preparation started for {1} {0}...", (data.IsBag ? "Batch" : "Box"), Convert.ToString(TempData["LastSuccessBox"])));
                    }
                    return View(data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        [HttpPost]
        public ActionResult PreparationStart(AtelierPreparationModel data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    AttlierBAL objPickingBAL = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    if (data.IsBoxBatchBox && data.IsProjectNameInBarcode)
                    {
                        data.BoxBatchNo = data.BoxBatchNo.Replace(SessionDetails.SecondLoginInfo.ProjectName, "");
                    }
                    objPickingBAL.AddPreparationBox(data, data.Operator, SessionDetails.UserId);

                    TempData["IsBag"] = data.IsBag;
                    TempData["BoxBatchLength"] = data.BoxBatchLength;
                    TempData["LastSuccessBox"] = data.BoxBatchNo;
                    TempData["IsBoxBatchBox"] = data.IsBoxBatchBox;
                    TempData["IsProjectNameInBarcode"] = data.IsProjectNameInBarcode;
                    return RedirectToAction("PreparationStart", "Atelier");
                }
                else
                {
                    return View(data);
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View(data);
            }
        }

        public ActionResult PreparationEnd()
        {
            AtelierPreparationModel data = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    data = new AtelierPreparationModel();
                    data.IsBatchAlreadyStarted = true;
                    if (TempData["IsBag"] != null && TempData["BoxBatchLength"] != null && TempData["IsProjectNameInBarcode"] != null && TempData["IsBoxBatchBox"] != null)
                    {
                        data.IsBag = Convert.ToBoolean(TempData["IsBag"]);
                        data.BoxBatchLength = Convert.ToString(TempData["BoxBatchLength"]);
                        data.IsProjectNameInBarcode = Convert.ToBoolean(TempData["IsProjectNameInBarcode"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                    }
                    else
                    {
                        var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                        data.IsBag = foundproject.IsBagBatchBox;
                        data.BoxBatchLength = foundproject.BoxLength;
                        data.IsProjectNameInBarcode = foundproject.IsProjectNameInBarcode;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                    }
                    data.BoxBatchNo = string.Empty;
                    data.RecieveDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    if (TempData["LastSuccessBox"] != null)
                    {
                        SetViewBagSuccess(string.Format("Preparation is ended for {1} {0}...", (data.IsBag ? "Batch" : "Box"), Convert.ToString(TempData["LastSuccessBox"])));
                    }
                    return View(data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        [HttpPost]
        public ActionResult PreparationEnd(AtelierPreparationModel data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    AttlierBAL objPickingBAL = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    if (data.IsBoxBatchBox && data.IsProjectNameInBarcode)
                    {
                        data.BoxBatchNo = data.BoxBatchNo.Replace(SessionDetails.SecondLoginInfo.ProjectName, "");
                    }
                    objPickingBAL.AddPreparationBox(data, data.Operator, SessionDetails.UserId);
                    TempData["IsBag"] = data.IsBag;
                    TempData["BoxBatchLength"] = data.BoxBatchLength;
                    TempData["LastSuccessBox"] = data.BoxBatchNo;
                    TempData["IsBoxBatchBox"] = data.IsBoxBatchBox;
                    TempData["IsProjectNameInBarcode"] = data.IsProjectNameInBarcode;
                    return RedirectToAction("PreparationEnd", "Atelier");
                }
                else
                {
                    return View(data);
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View(data);
            }
        }

        public ActionResult IsValidPreparationBoxBatch(string BoxBatchNo, int BoxBatchLength, bool IsBatchAlreadyStarted)
        {
            if (BoxBatchNo.Length != BoxBatchLength)
            {
                return Json("Invalid Box by length !!!", JsonRequestBehavior.AllowGet);
            }
            if (BoxBatchNo.Length > 0)
            {
                BoxBatchNo = BoxBatchNo.Replace(SessionDetails.SecondLoginInfo.ProjectName, "");
            }
            bool isAlreadyEnded = false;
            bool isAvailableInReception = false;
            if (IsBatchAlreadyStarted)
            {
              
                AttlierBAL objBal = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                if (!objBal.IsPreparationBatchStarted(BoxBatchNo, ref isAlreadyEnded, ref isAvailableInReception))
                {
                    return Json("Box/Batch is not Started..! You can not end it, plase first start it...", JsonRequestBehavior.AllowGet);
                }
                if (isAlreadyEnded)
                {
                    return Json("Box/Batch is already Over...", JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                AttlierBAL objBal = new AttlierBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                bool _result = objBal.IsPreparationBatchStarted(BoxBatchNo, ref isAlreadyEnded, ref isAvailableInReception);
                if (!isAvailableInReception)
                {
                    return Json("Box/Batch is not recieved in reception...!", JsonRequestBehavior.AllowGet);
                }

                if (_result)
                {
                    return Json("Box/Batch is already Started..!", JsonRequestBehavior.AllowGet);
                }
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ListBoxPreparation()
        {
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    ViewBag.IsBagBatchBox = foundProject.IsBagBatchBox;
                    ViewBag.IsBoxBatchBox = foundProject.IsBoxBatchBox;
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
            }
            return View();
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetPreparationBoxDetails(string boxBatch, string operatorName, string startDate, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                PreparationBAL objPreparationBAL = null;
                List<PreparationDTO> objResultList = new List<PreparationDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPreparationBAL = new PreparationBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objPreparationBAL.GetPreparationBoxDetails(boxBatch, operatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public object GetPreparationBoxDetailsInExcel(string boxBatch, string operatorName, string startDate, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                PreparationBAL objPreparationBAL = null;
                List<PreparationDTO> objResultList = new List<PreparationDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPreparationBAL = new PreparationBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objPreparationBAL.GetPreparationBoxDetails(boxBatch, operatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord };
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetPreparationDetailsInExcel(string boxNo, string batch, string operatorName, string startDateTime, string endDateTime, string fields)
        {
            try
            {
                var result = this.GetPreparationBoxDetailsInExcel(boxNo, operatorName, startDateTime, endDateTime, 0, 10000, "BoxBatch DESC");
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<PreparationDTO>;
                if (objList == null || objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(PreparationDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", boxNo, startDateTime))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        #endregion

        #region Transport
        public ActionResult Transport(string Destination = null, string BoxBatch = null, string Operator = null)
        {
            TransportBAL objBal = new TransportBAL();
            AtelierTransportModel data = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    data = new AtelierTransportModel();
                    data.BoxBatch = string.Empty;

                    if (TempData["IsBagBatchBox"] != null && TempData["IsBoxBatchBox"] != null && TempData["BoxLength"] != null && TempData["IsProjectNameInBarcode"] != null)
                    {
                        data.IsBagBatchBox = Convert.ToBoolean(TempData["IsBagBatchBox"]);
                        data.IsBoxBatchBox = Convert.ToBoolean(TempData["IsBoxBatchBox"]);
                        data.BoxLength = Convert.ToString(TempData["BoxLength"]);
                        data.IsProjectNameInBarcode = Convert.ToBoolean(TempData["IsProjectNameInBarcode"]);
                    }
                    else
                    {
                        var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                        data.IsBox = foundproject.IsBox;
                        data.IsBagBatchBox = foundproject.IsBagBatchBox;
                        data.IsBoxBatchBox = foundproject.IsBoxBatchBox;
                        data.BoxLength = foundproject.BoxLength;
                        data.IsProjectNameInBarcode = foundproject.IsProjectNameInBarcode;
                    }
                    data.Batch = string.Empty;
                    data.DestinationList = objBal.GetAllTransportDestination();
                    data.RecieveDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    ViewBag.Destination = Destination;
                    ViewBag.BoxBatch = BoxBatch;
                    ViewBag.Operator = Operator;
                    if (TempData["LastSuccessBox"] != null)
                    {
                        SetViewBagSuccess(string.Format("Transport box added - {0} - {1}...", Convert.ToString(TempData["LastSuccessBox"]), Convert.ToString(TempData["LastSuccessBatch"])));
                    }
                    return View(data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }

        }

        [HttpPost]
        public ActionResult Transport(FormCollection formcollection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    TempData["IsProjectNameInBarcode"] = formcollection["IsProjectNameInBarcode"];
                    AtelierTransportModel objAtelierTransportModel = new AtelierTransportModel();
                    TransportBAL objTransportBAL = new TransportBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    objAtelierTransportModel.TransportId = Convert.ToInt32(formcollection["TransportId"]);
                    objAtelierTransportModel.BoxBatch = formcollection["BoxBatch"];
                    objAtelierTransportModel.RecieveDate = string.Empty;
                    objAtelierTransportModel.Destination = formcollection["DestinationList"];
                    if ((Convert.ToBoolean(formcollection["IsBoxBatchBox"]) == true) && (Convert.ToBoolean(formcollection["IsProjectNameInBarcode"]) == true))
                    {
                        objAtelierTransportModel.Batch = formcollection["Batch"].Replace(SessionDetails.SecondLoginInfo.ProjectName, "");
                    }
                    objTransportBAL.AddTransportDetails(objAtelierTransportModel, formcollection["Operator"], SessionDetails.UserId);
                    TempData["LastSuccessBox"] = formcollection["BoxBatch"];
                    TempData["LastSuccessBatch"] = formcollection["Batch"];
                    TempData["BoxLength"] = formcollection["BoxLength"];
                    TempData["IsBagBatchBox"] = formcollection["IsBagBatchBox"];
                    TempData["IsBoxBatchBox"] = formcollection["IsBoxBatchBox"];
                    if (formcollection["IsBoxBatchBox"].ToLower().Trim() == "false")
                    {
                        return RedirectToAction("Transport", "Atelier", new { Destination = formcollection["DestinationList"], Operator = formcollection["Operator"] });
                    }
                    else
                    {
                        return RedirectToAction("Transport", "Atelier", new { Destination = formcollection["DestinationList"], BoxBatch = formcollection["BoxBatch"], Operator = formcollection["Operator"] });
                    }
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View();
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetTransportBoxDetails(string boxBatch, string batch, string startDate, string operatorName, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                if (batch == "undefined")
                {
                    batch = string.Empty;
                }
                if (operatorName == "undefined")
                {
                    operatorName = string.Empty;
                }
               TransportBAL objTransportBAL = null;
                List<TransportDTO> objResultList = new List<TransportDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objTransportBAL = new TransportBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objTransportBAL.GetTransportBoxDetails(boxBatch, batch, operatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public object GetTransportBoxDetailsinExcel(string boxBatch, string batch, string startDate, string operatorName, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                if (batch == "undefined")
                {
                    batch = string.Empty;
                }
                if (operatorName == "undefined")
                {
                    operatorName = string.Empty;
                }
                WebTool.BAL.TransportBAL objTransportBAL = null;
                List<TransportDTO> objResultList = new List<TransportDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objTransportBAL = new WebTool.BAL.TransportBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objTransportBAL.GetTransportBoxDetails(boxBatch, batch, operatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting, ref totalRecord);
                    return new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord };
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetTransportBoxDetailsInExcel(string boxNo, string batch, string operatorName, string startDateTime, string endDateTime, string fields)
        {
            try
            {
                var result = this.GetTransportBoxDetailsinExcel(boxNo, batch, startDateTime, operatorName, endDateTime, 0, 10000, "RecievedDate DESC");
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<TransportDTO>;
                if (objList == null || objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(TransportDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", boxNo, startDateTime))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        public ActionResult ListBoxTransport()
        {
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    ViewBag.IsBagBatchBox = foundProject.IsBagBatchBox;
                    ViewBag.IsBoxBatchBox = foundProject.IsBoxBatchBox;
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
            }
            return View();
        }

        [WebMethod(EnableSession = true)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object DeleteTrasportDetails(long trasportId)
        {
            WebTool.BAL.TransportBAL _transporterBAL = new WebTool.BAL.TransportBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
            try
            {
                _transporterBAL.DeleteTransportInfo(trasportId);
                return Json(new { Message = "Record Deleted Successfully." }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region View Box

        public ActionResult ViewBox()
        {


            return View();


        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetBoxListForIFYPartner(string boxNo, string batch, string preparatorName, string startDate, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                BoxListBAL objBoxListBAL = new BoxListBAL();
                List<BoxListDTO> objResultList = new List<BoxListDTO>();

                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new BoxListBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    if (SessionDetails.UserName == "AtelierIFY")
                    {
                        objResultList = objBoxListBAL.GetAtelierIFYViewList(boxNo, preparatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                    }
                    else
                    {
                        objResultList = objBoxListBAL.GetAtelierPartnerViewList(boxNo, batch, preparatorName, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                    }
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult UpdateAtelierBackToIfyStatus(AtelierReceptionDTO record)
        {
            BoxListBAL objBoxListBAL = new BoxListBAL();
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new BoxListBAL(foundProject.ProjectConnectionString);
                    objBoxListBAL.UpdateAtelierReceptionBackToIfyStatus(record);
                }
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                string _errorMsg = ex.Message;
                if (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message))
                {
                    _errorMsg = "Unable to do operation... <br />Developer Info: <br />" + ex.InnerException.Message;
                }
                Utility.Logger.WriteLog(ex);
                return Json(new { Result = "ERROR", Message = _errorMsg });
            }
        }

        #endregion

        #region Box Palette

        public ActionResult ViewPalette()
        {
            return View();
        }

        public ActionResult Palette()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Palette(FormCollection collection)
        {
            AssignPaletteDTO _objPaletteModel = new AssignPaletteDTO();
            PaletteBAL objPaletteBal = new PaletteBAL();
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPaletteBal = new PaletteBAL(foundProject.ProjectConnectionString);

                    _objPaletteModel.PaletteNumber = Convert.ToString(collection["PaletteNo"]);
                    _objPaletteModel.PaletteStatus = Convert.ToString(collection["PaletteStatus"]);

                    string _AllBoxes = Convert.ToString(collection["hdnBoxes"]);
                    if (!string.IsNullOrEmpty(_AllBoxes))
                    {
                        var _box = _AllBoxes.Split(',');
                        if (_box.Length > 0)
                        {
                            for (int i = 0; i < _box.Length; i++)
                            {
                                _objPaletteModel.BoxId = _box[i];
                                objPaletteBal.AddPaletteNumber(_objPaletteModel.PaletteNumber, _objPaletteModel.PaletteStatus, _box[i]);
                            }
                        }
                    }
                }
            }
            return View();
        }

        public ActionResult AddPaletteNumber()
        {
            return View();
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetBoxListForPaletteNumber(string boxNo, string operatorName)
        {
            PaletteBAL objBoxListBAL = new PaletteBAL();
            try
            {
                PaletteBAL objPaletteBAL = new PaletteBAL();
                List<AssignPaletteDTO> objResultList = new List<AssignPaletteDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPaletteBAL = new PaletteBAL(foundProject.ProjectConnectionString);
                    objResultList = objPaletteBAL.GetBoxListForPaletteNumber(boxNo, operatorName);
                    return Json(new { Result = "OK", Records = objResultList });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public object GetBoxListForPaletteNumberExcel(string boxNo, string operatorName)
        {
            PaletteBAL objBoxListBAL = new PaletteBAL();
            try
            {
                PaletteBAL objPaletteBAL = new PaletteBAL();
                List<AssignPaletteDTO> objResultList = new List<AssignPaletteDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPaletteBAL = new PaletteBAL(foundProject.ProjectConnectionString);
                    objResultList = objPaletteBAL.GetBoxListForPaletteNumber(boxNo, operatorName);
                    return new { Result = "OK", Records = objResultList };
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetBoxListForPaletteNumberInExcel(string boxNo, string operatorName, string fields)
        {
            try
            {
                var result = this.GetBoxListForPaletteNumberExcel(boxNo, operatorName);
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<AssignPaletteDTO>;
                if (objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(AssignPaletteDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", boxNo, System.DateTime.Now))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }


        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetPaletteWiseDetails(string paletteNubmer, string operatorName, string startDate, string endDate)
        {
            PaletteBAL objBoxListBAL = new PaletteBAL();
            try
            {
                PaletteBAL objPaletteBAL = new PaletteBAL();
                List<PaletteDTO> objResultList = new List<PaletteDTO>();

                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPaletteBAL = new PaletteBAL(foundProject.ProjectConnectionString);
                    objResultList = objPaletteBAL.GetPaletteWiseDetail(paletteNubmer, operatorName, _st, _et);
                    return Json(new { Result = "OK", Records = objResultList });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }


        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult AddDestructionDetails(PaletteDTO record)
        {
            PaletteBAL objBoxListBAL = new PaletteBAL();
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new PaletteBAL(foundProject.ProjectConnectionString);
                    objBoxListBAL.AddDestructionDetails(record);
                }
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                string _errorMsg = ex.Message;
                if (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message))
                {
                    _errorMsg = "Unable to do operation... <br />Developer Info: <br />" + ex.InnerException.Message;
                }
                Utility.Logger.WriteLog(ex);
                return Json(new { Result = "ERROR", Message = _errorMsg });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetPaletteWiseBoxList(string paletteNumber, string paletteStatus)
        {
            try
            {
                BoxListBAL objBoxListBAL = new BoxListBAL();
                List<AssignPaletteDTO> objResultList = new List<AssignPaletteDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new BoxListBAL(foundProject.ProjectConnectionString);
                    objResultList = objBoxListBAL.GetPaletteWiseBoxList(paletteNumber, paletteStatus);
                    return Json(new { Result = "OK", Records = objResultList });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        public ActionResult BoxPalette(string PaletteNo, string PaletteStatus)
        {

            ViewBag.PaletteNo = PaletteNo;
            ViewBag.PaletteStatus = PaletteStatus;
            return View();
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetPaletteNumberWiseBoxList(string PaletteNo, string PaletteStatus)
        {
            try
            {
                BoxListBAL objBoxListBAL = new BoxListBAL();
                List<AssignPaletteDTO> objResultList = new List<AssignPaletteDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new BoxListBAL(foundProject.ProjectConnectionString);
                    objResultList = objBoxListBAL.GetPaletteWiseBoxList(PaletteNo, PaletteStatus);
                    return Json(new { Result = "OK", Records = objResultList });
                }

                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }

        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetPaletteNumberBoxList(string PaletteNo, string PaletteStatus)
        {
            try
            {
                BoxListBAL objBoxListBAL = new BoxListBAL();
                List<AssignPaletteDTO> objResultList = new List<AssignPaletteDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objBoxListBAL = new BoxListBAL(foundProject.ProjectConnectionString);
                    objResultList = objBoxListBAL.GetPaletteWiseBoxList(PaletteNo, PaletteStatus);
                    return new { Result = "OK", Records = objResultList };
                }

                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }

        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetBoxListInExcel(string PaletteNo, string PaletteStatus, string fields)
        {
            try
            {
                var result = this.GetPaletteNumberBoxList(PaletteNo, PaletteStatus);
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<AssignPaletteDTO>;
                if (objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(AssignPaletteDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", PaletteNo, PaletteStatus))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public object GetPaletteWiseDetailsInExcel(string paletteNubmer, string operatorName, string startDate, string endDate)
        {
            PaletteBAL objBoxListBAL = new PaletteBAL();
            try
            {
                PaletteBAL objPaletteBAL = new PaletteBAL();
                List<PaletteDTO> objResultList = new List<PaletteDTO>();

                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPaletteBAL = new PaletteBAL(foundProject.ProjectConnectionString);
                    objResultList = objPaletteBAL.GetPaletteWiseDetail(paletteNubmer, operatorName, _st, _et);
                    return new { Result = "OK", Records = objResultList };
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }
            }
            catch (Exception ex)
            {
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public object GetPaletteDetailsInExcel(string paletteNubmer, string operatorName, string startDateTime, string endDateTime, string fields)
        {
            try
            {
                var result = this.GetPaletteWiseDetailsInExcel(paletteNubmer, operatorName, startDateTime, endDateTime);
                var propRecord = result.GetType().GetProperty("Records");
                var rawList = propRecord.GetValue(result, null);

                var objList = rawList as List<PaletteDTO>;
                if (objList == null || objList.Count == 0)
                {
                    throw new Exception("No Data Available...");
                }
                var _columns = fields.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                ISheet _sheet = hssfworkbook.CreateSheet();
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeFormula = false;
                ((HSSFSheet)hssfworkbook.GetSheetAt(0)).AlternativeExpression = false;
                int _currentRowCount = 0;
                #region Create Columns
                for (int j = 0; j < _columns.Length; j++)
                {
                    _sheet.SetColumnWidth(j, 20 * 256);
                }
                #endregion

                #region Header
                IRow _headerRow = _sheet.CreateRow(_currentRowCount);
                var font = hssfworkbook.CreateFont();
                font.FontHeightInPoints = 10;
                font.FontName = "Calibri";
                font.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.Bold;

                var _allModelProps = typeof(PaletteDTO).GetProperties();
                _currentRowCount++;
                for (int j = 0; j < _columns.Length; j++)
                {
                    _headerRow.CreateCell(j).SetCellValue(_columns[j]);
                    #region Header Style
                    ICellStyle headerStyle = hssfworkbook.CreateCellStyle();
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.General;
                    headerStyle.VerticalAlignment = VerticalAlignment.Top;
                    headerStyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                    headerStyle.SetFont(font);
                    #endregion

                    _headerRow.GetCell(j).CellStyle = headerStyle;
                    _headerRow.GetCell(j).SetCellType(CellType.String);
                }
                #endregion

                ICellStyle _cellStyleYellow = hssfworkbook.CreateCellStyle();
                _cellStyleYellow.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.LightYellow.Index;

                ICellStyle _cellStyleRed = hssfworkbook.CreateCellStyle();
                _cellStyleRed.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;

                #region Row Write
                for (int i = 0; i < objList.Count; i++)
                {
                    var item = objList[i];
                    IRow _row = _sheet.CreateRow(_currentRowCount++);
                    for (int j = 0; j < _columns.Length; j++)
                    {
                        var foundProp = _allModelProps.FirstOrDefault(p => p.Name.Trim().ToLower() == _columns[j].Trim().ToLower());
                        if (foundProp != null)
                        {
                            _row.CreateCell(j).SetCellValue(Convert.ToString(foundProp.GetValue(item, null)));
                            _row.GetCell(j).SetCellType(CellType.String);
                        }
                    }
                }
                #endregion

                MemoryStream mem = new MemoryStream();
                hssfworkbook.Write(mem);
                byte[] fileBytes = mem.ToArray();
                hssfworkbook = null;


                HttpContext.Response.Clear();
                HttpContext.Response.ClearContent();
                HttpContext.Response.ClearHeaders();

                HttpContext.Response.ContentType = "application/ms-excel";
                HttpContext.Response.Charset = string.Empty;
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", System.Web.HttpUtility.UrlPathEncode(string.Format("{0}_{1}.xls", paletteNubmer, startDateTime))));
                HttpContext.Response.AddHeader("Content-Length", fileBytes.Length.ToString());
                HttpContext.Response.OutputStream.Write(fileBytes, 0, fileBytes.Length);
                HttpContext.Response.Flush();

                return new { Result = "OK" };
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                return new { Result = "ERROR", Message = ex.Message };
            }
        }

        #endregion

        #region Scanning

        public ActionResult Scanning()
        {
            AtelierScanningModel data = null;
            try
            {
                data = new AtelierScanningModel();
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    if (TempData["BoxLength"] != null)
                    {
                        data.BoxLength = Convert.ToString(TempData["BoxLength"]);
                    }
                    else
                    {
                        var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                        data.BoxLength = foundproject.BoxLength;
                    }

                }
                return View(data);

            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View(data);
            }
        }

        public ActionResult ListBoxScanning()
        {
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
            }
            return View();
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetScanningBoxDetails(string boxBatch, string startDate, string endDate, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                WebTool.BAL.AttlierBAL objTransportBAL = null;
                List<AtelierScanningDTO> objResultList = new List<AtelierScanningDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDate, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objTransportBAL = new WebTool.BAL.AttlierBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objTransportBAL.GetScanningBoxDetails(boxBatch, _st, _et, jtStartIndex, jtPageSize, jtSorting);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetBoxScanDetails(string boxNo)
        {
            try
            {
                AttlierBAL objTransportBAL = null;
                List<AtelierScanningDTO> objResultList = new List<AtelierScanningDTO>();

                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objTransportBAL = new AttlierBAL(foundProject.ProjectConnectionString);
                    long totalRecord = 0;
                    objResultList = objTransportBAL.GetBoxScanDetails(boxNo);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = totalRecord });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }



        #endregion
    }
}
