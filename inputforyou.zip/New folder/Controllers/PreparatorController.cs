﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using WebTool.Models;

namespace DocflowWebTool.Controllers
{
    public class PreparatorController : BaseController
    {
        public ActionResult Index()
        {
            PreparatorBAL objBal = new PreparatorBAL();
            var _data = objBal.GetAllPreparators();
            return View(_data);
        }

        public ActionResult Create(int? Id)
        {
            ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
            if (Id.HasValue)
            {
                PreparatorBAL objPartnerBAL = new PreparatorBAL();
                PreparatorModel obj = objPartnerBAL.GetPreparatorDetailById(Id.Value);
                ViewBag.Mode = "Update";
                return View(obj);
            }
            else
            {
                ViewBag.Mode = "Add Preparator";
                return View();
            }
        }

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
           PreparatorModel obj = new PreparatorModel();
            try
            {
                obj.UserId = Utility.Utilities.SafeCastToLong(collection["UserId"]);
                obj.PartnerId = Utility.Utilities.SafeCastToLong(collection["PartnerId"]);
                obj.UserName = collection["UserName"];
                obj.Location = collection["Location"];
                obj.EmailId = collection["EmailId"];
                obj.IsActive = true;
                if (ModelState.IsValid)
                {
                    PreparatorBAL objBAL = new PreparatorBAL();
                    objBAL.InsertUpdatePreparatorRecord(obj);
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Execption = ex;
                return View();
            }
        }
    }
}
