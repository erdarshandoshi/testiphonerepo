﻿using WebTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using System.Web.Script.Services;
using System.Web.Services;
using DocflowWebTool.Utility;


namespace DocflowWebTool.Controllers
{
    public class FolderDeleteController : Controller
    {

        public ActionResult FolderDeleteList()
        {
            return View();
        }

        [HttpPost]
        public JsonResult FolderDeleteList(string projectName, string Box, string Folder, int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                FolderDeleteBAL objFolderDeleteBAL = new FolderDeleteBAL(foundProject.ProjectConnectionString);
                int recordscount = 0;

                List<FolderDeleteModel> objFolderDeletelst = objFolderDeleteBAL.FolderDeleteList(Box, Folder);
                recordscount = objFolderDeletelst.Count();
                #region sorting
                if (string.IsNullOrEmpty(jtSorting) || jtSorting.Equals("Folder ASC"))
                {
                    objFolderDeletelst = objFolderDeletelst.OrderBy(p => p.Folder).ToList();
                }
                else if (jtSorting.Equals("Folder DESC"))
                {
                    objFolderDeletelst = objFolderDeletelst.OrderByDescending(p => p.Folder).ToList();
                }
                else
                {
                    objFolderDeletelst = objFolderDeletelst.OrderBy(p => p.Folder).ToList();
                }
                #endregion
                #region paging
                if (jtPageSize > 0)
                {
                    objFolderDeletelst = objFolderDeletelst.Skip(jtStartIndex).Take(jtPageSize).ToList();
                }
                else
                {
                    objFolderDeletelst = objFolderDeletelst.ToList();
                }
                #endregion
                return Json(new { Result = "OK", Records = objFolderDeletelst, TotalRecordCount = recordscount }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {

                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult RetrieveFolderDeleteReasons(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
               FolderDeleteBAL objFolderDeleteBAL = new FolderDeleteBAL(foundProject.ProjectConnectionString);
                List<RetriveReasonDTO> objFolderDeletelst = objFolderDeleteBAL.RetrieveFolderDeleteReasons(projectName);
                var jsonResult = Json(new { Result = "OK", Records = objFolderDeletelst, TotalRecordCount = objFolderDeletelst.Count }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;
            }
            catch (Exception ex)
            {

                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult DeleteFolderFromDB(string projectName, int reasonId, string remarks, List<FolderDeleteModel> lstFolderDeleteModel, bool DeleteDataFromDataPath)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                FolderDeleteBAL objFolderDeleteBAL = new FolderDeleteBAL(foundProject.ProjectConnectionString);
                int founduserId = Convert.ToInt32(SessionDetails.UserId);
                int ret = -999;
                bool _result = true;
                foreach (var item in lstFolderDeleteModel)
                {
                    _result = _result && objFolderDeleteBAL.DeleteFolderFromDB(reasonId, remarks, founduserId, ref ret, Convert.ToInt64(item.Id));
                    if (DeleteDataFromDataPath == true)
                    {
                        int _removedata = objFolderDeleteBAL.RemoveDataFromDataPath(item);
                    }

                }
                return Json(new { Result = "OK", Records = _result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }

        }


        [HttpPost]
        public object GetBoxList(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
               FolderDeleteBAL objFolderDeleteBAL = new FolderDeleteBAL(foundProject.ProjectConnectionString);
                int founduserId = Convert.ToInt32(SessionDetails.UserId);
                List<string> objFolderDeletelst = objFolderDeleteBAL.GetBoxList();
                var jsonResult = Json(new { Result = "OK", Records = objFolderDeletelst, TotalRecordCount = objFolderDeletelst.Count }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });

            }
        }

    }
}