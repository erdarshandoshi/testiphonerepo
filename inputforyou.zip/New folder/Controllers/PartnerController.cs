﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using WebTool.Models;

namespace DocflowWebTool.Controllers
{
    public class PartnerController : Controller
    {
        public ActionResult Index()
        {
            PartnerBAL objPartnerBAL = new PartnerBAL();
            var _partners = objPartnerBAL.GetAllPartners();
            return View(_partners);
        }
        public ActionResult Create(int? Id)
        {
            if (Id.HasValue)
            {
                PartnerBAL objPartnerBAL = new PartnerBAL();
                PartnerModel obj = objPartnerBAL.GetPartnerDetailById(Id.Value);
                ViewBag.Mode = "Update";
                return View(obj);
            }
            else
            {
                ViewBag.Mode = "Add Partner";
                return View();
            }
        }
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            PartnerModel obj = new PartnerModel();
            try
            {
                obj.UserId = Utility.Utilities.SafeCastInt(collection["UserId"]);
                obj.FirstName = collection["FirstName"];
                obj.UserName = collection["UserName"];
                obj.Password = collection["Password"];
                obj.EmailId = collection["EmailId"];
                obj.Location = collection["Location"];
                obj.IsActive = true;
                if (ModelState.IsValid)
                {
                    PartnerBAL objPartnerBAL = new PartnerBAL();
                    objPartnerBAL.InsertUpdatePartnerRecord(obj);
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Execption = ex;
                return View("Create", obj);
            }
        }

        //public ActionResult Delete(int id) //will be used in future
        //{
        //    return View();
        //}
    }
}
