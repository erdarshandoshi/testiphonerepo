﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.Models;
using WebTool.BAL;
using System.Dynamic;

namespace DocflowWebTool.Controllers
{
    public class ProjectController : BaseController
    {
        //
        // GET: /Project/
        ProjectBAL _objProjectBal = new ProjectBAL();

        [HttpGet]
        public ActionResult Create(int? id)
        {
            ProjectModel objModel = new ProjectModel();
            ProjectBAL objProjectBAL = new ProjectBAL();
            PartnerBAL objPartnerBAL = new PartnerBAL();
            try
            {
                //ViewBag.AvailableProcesses = objProjectBAL.GetAllProcess();
                objModel.PartnerList = objPartnerBAL.GetAllPartners();
                //objModel.ProcessFlow.Add(new ProcessDTO() { Id = 101, ProcessName = "Auto Registration", SortOrder = 1 });
                ViewBag.Mode = "Save";
                var processDetails = objProjectBAL.GetAllProcessDetails();

                List<SelectListItem> _ObjProcessDetailNames = new List<SelectListItem>();
                /*Start change by niyati*/
                IEnumerable<ProjectStatus> ProjectStateTypes = Enum.GetValues(typeof(ProjectStatus))
                                                      .Cast<ProjectStatus>();
                objModel.ProjectStateList = from action in ProjectStateTypes
                                             select new SelectListItem { Text = action.ToString(), Value = ((int)action).ToString() };
                /*end change by niyati*/

                #region Edit
                if (id.HasValue)
                {
                    var foundProject = _objProjectBal.GetProjectDetailsById(id.Value);

                    var foundProcessDetails = _objProjectBal.GetProcessDetailById(id.Value);

                    if (foundProject != null)
                    {
                        objModel.Id = id.Value;
                        objModel.ProjectName = foundProject.ProjectName;
                        objModel.CompanyName = foundProject.CompanyName;
                        objModel.BoxStructure = foundProject.BoxStructure;
                        objModel.BoxLength = foundProject.BoxLength;
                        objModel.StartingLocation = foundProject.StartingLocation;
                        objModel.IsPickingList = foundProject.IsPickingList;
                        objModel.ScanningDPI = foundProject.ScanDPI;
                        objModel.IsPatchInData = foundProject.IsPatchInData;
                        objModel.IsFtpSftpScan = foundProject.IsFtpSftpScan;
                        objModel.Box = foundProject.IsBox;
                        objModel.BoxBatchBag = foundProject.IsBoxBatchBox;
                        objModel.BagBatchBox = foundProject.IsBagBatchBox;
                        objModel.DataPath = foundProject.DataPath;
                        objModel.ProductionPath = foundProject.ProductionPath;
                        objModel.NetworkPath = foundProject.NetworkPath;
                        objModel.IsFtpSftpScan = foundProject.IsFtpSftpScan;
                        objModel.Protocol = foundProject.TransferProtocol;
                        objModel.ProtocolEncryption = foundProject.TransferEncryption;
                        objModel.Port = foundProject.TransferPort;
                        objModel.Url = foundProject.TransferHost;
                        objModel.UserName = foundProject.TransferUsername;
                        objModel.Password = foundProject.TransferPassword;
                        objModel.ProjectDescription = foundProject.ProjectDescription;
                        objModel.Documents = foundProject.Documents;
                        //DateTime _dDate;
                        //if (DateTime.TryParseExact(Convert.ToString(foundProject.DevelopMentDate).Trim(), "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _dDate))
                        //{
                        //    objModel.DevelopmentDate = _dDate;
                        //}
                        objModel.DevelopmentDate = foundProject.DevelopMentDate.ToString("dd/MM/yyyy");
                        objModel.LiveDate = foundProject.LiveDate.ToString("dd/MM/yyyy");
                        objModel.TestingDate = foundProject.TestingDate.ToString("dd/MM/yyyy");
                        //objModel.PartnerId = Convert.ToInt32(foundProject.Partner);
                        /*Start Change by Niyati*/
                        objModel.ProjectScanPartners = foundProject.ProjectScanPartners;
                        objModel.ProjectStateId = foundProject.ProjectStateId;
                        /*End Change by Niyati*/
                    }
                    else
                    {
                        RedirectToAction("List", "Project");
                    }

                    objModel.InputInbound = _objProjectBal.GetInputInboundDetails(id.Value);

                    var _SelectedCheckboxIDs = foundProcessDetails.Select(x => x.ProcessDetailId).ToArray();
                    foreach (var item in processDetails)
                    {
                        if (_SelectedCheckboxIDs.Contains(item.ProcessDetailId))
                        {
                            _ObjProcessDetailNames.Add(new SelectListItem { Text = item.ProcessDetailName, Value = item.ProcessDetailId.ToString(), Selected = true });
                        }
                        else
                        {
                            _ObjProcessDetailNames.Add(new SelectListItem { Text = item.ProcessDetailName, Value = item.ProcessDetailId.ToString(), Selected = false });
                        }
                    }
                    ViewBag.Mode = "Update";
                }
                #endregion
                else
                {
                    objModel.Id = 0;
                    foreach (var item in processDetails)
                    {
                        _ObjProcessDetailNames.Add(new SelectListItem { Text = item.ProcessDetailName, Value = item.ProcessDetailId.ToString() });
                    }
                }
                objModel.ProcessDetailNames = _ObjProcessDetailNames;
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                throw ex;
            }
            return View(objModel);
        }

        public ActionResult List(ProjectDTO obj)
        {
            LoginBAL _objLogin = new LoginBAL();
            List<ProjectListDTO> _objlist = new List<ProjectListDTO>();
            _objlist = _objLogin.GetProjectList();
            return View(_objlist);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(FormCollection formcollection)
        {
            try
            {
                ProjectModel _objProjectModel = new ProjectModel();
                if (ModelState.IsValid)
                {
                    _objProjectModel.Id = Convert.ToInt32(formcollection["Id"]);
                    #region Project Details
                    _objProjectModel.ProjectName = formcollection["ProjectName"];
                    _objProjectModel.CompanyName = formcollection["CompanyName"];
                    _objProjectModel.StartingLocation = formcollection["StartingLocation"];
                    _objProjectModel.IsPickingList = Convert.ToString(formcollection["IsPickingList"]).Contains("true");
                    _objProjectModel.BoxLength = formcollection["BoxLength"];
                    _objProjectModel.BoxStructure = formcollection["BoxStructure"];
                    _objProjectModel.ScanningDPI = formcollection["ScanningDPI"];
                    _objProjectModel.IsPatchInData = Convert.ToString(formcollection["IsPatchInData"]).Contains("true");
                    _objProjectModel.DataPath = formcollection["DataPath"];
                    _objProjectModel.ProductionPath = formcollection["ProductionPath"];
                    //_objProjectModel.PartnerId = Utility.Utilities.SafeCastInt(formcollection["PartnerId"]);
                    int _logistic = Utility.Utilities.SafeCastInt(formcollection["logistic"]);
                    _objProjectModel.Box = (_logistic == 0);
                    _objProjectModel.BagBatchBox = (_logistic == 1);
                    _objProjectModel.BoxBatchBag = (_logistic == 2);
                    _objProjectModel.ScanningDPI = formcollection["ScanningDPI"];
                    _objProjectModel.NetworkPath = formcollection["NetworkPath"];
                    _objProjectModel.InputInbound.IsScan = Convert.ToString(formcollection["IsScan"]).Contains("true");
                    _objProjectModel.ProjectDescription = formcollection["ProjectDescription"];
                    #endregion

                    #region Project Time lines
                    string _dateFormat = "dd/MM/yyyy";
                    _objProjectModel.DevelopmentDate = string.Empty;
                    _objProjectModel.TestingDate = string.Empty;
                    _objProjectModel.LiveDate = string.Empty;
                    if (!string.IsNullOrEmpty(formcollection["DevelopmentDate"]) && formcollection["DevelopmentDate"].Trim().Length == 10)
                    {
                        DateTime _ddate;
                        if (DateTime.TryParseExact(formcollection["DevelopmentDate"].Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ddate))
                        {
                            _objProjectModel.DevelopmentDate = _ddate.ToString(_dateFormat);
                        }
                    }

                    if (!string.IsNullOrEmpty(formcollection["TestingDate"]) && formcollection["TestingDate"].Trim().Length == 10)
                    {
                        DateTime _tdate;
                        if (DateTime.TryParseExact(formcollection["TestingDate"].Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _tdate))
                        {
                            _objProjectModel.TestingDate = _tdate.ToString(_dateFormat);
                        }
                    }

                    if (!string.IsNullOrEmpty(formcollection["LiveDate"]) && formcollection["LiveDate"].Trim().Length == 10)
                    {
                        DateTime _ldate;
                        if (DateTime.TryParseExact(formcollection["LiveDate"].Trim(), _dateFormat, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ldate))
                        {
                            _objProjectModel.LiveDate = _ldate.ToString(_dateFormat);
                        }
                    }
                    #endregion

                    #region Transfer Ftp Sftp Details
                    _objProjectModel.IsFtpSftpScan = Convert.ToString(formcollection["IsFtpSftpScan"]).Contains("true");
                    #region Insert All Details
                    int Pid = _objProjectBal.InsertProjectDetails(_objProjectModel);
                    #endregion

                    #region Insert Partners details
                    /*Start Change By Niyati*/
                    var PartnerIds = formcollection["PartnerIds"];
                    string[] _PartnerIds = PartnerIds.Split(',');
                    foreach (var item in _PartnerIds)
                    {
                        ProjectPartners objprojectpartner = new ProjectPartners();
                        objprojectpartner.PartnerId = Convert.ToInt32(item);
                        objprojectpartner.IsPalleteRequiredOnReception = (formcollection["BoxPalleteOnReception_" + item] == "on");
                        objprojectpartner.IsPalleteRequiredOnTransport = (formcollection["BoxPalleteOnTransport_" + item] == "on");
                        _objProjectModel.ProjectScanPartners.Add(objprojectpartner);
                    }
                    /*End Change By Niyati*/
                    _objProjectBal.InsertPartnerDetails(_objProjectModel.ProjectScanPartners, Pid);
                    #endregion

                    #region Insert ProjectStatus details
                    var _ProjectStatusId = formcollection["ProjectStatusId"];
                    IEnumerable<ProjectStatus> actionTypes = Enum.GetValues(typeof(ProjectStatus))
                                                      .Cast<ProjectStatus>();
                    _objProjectModel.ProjectStateList = from action in actionTypes
                                                         select new SelectListItem
                                                         {
                                                             Text = action.ToString(),
                                                             Value = ((int)action).ToString()
                                                         };
                    #endregion

                    if (_objProjectModel.IsFtpSftpScan)
                    {
                        _objProjectModel.Protocol = formcollection["Protocol"];
                        if (formcollection["ProtocolEncryption"] != "0")
                        {
                            _objProjectModel.ProtocolEncryption = formcollection["ProtocolEncryption"];
                        }
                        else
                        {
                            _objProjectModel.ProtocolEncryption = string.Empty;
                        }
                        _objProjectModel.Port = Convert.ToInt32(formcollection["Port"]);
                        _objProjectModel.Url = formcollection["Url"];
                        _objProjectModel.UserName = formcollection["UserName"];
                        _objProjectModel.Password = formcollection["Password"];
                        //var _insertedEmailDetails = _objProjectBal.GetInsertedFTPSFTPDetails(_objProjectModel.Protocol, _objProjectModel.ProtocolEncryption, _objProjectModel.Url, _objProjectModel.UserName);
                        //if (_insertedEmailDetails.Tables[0].Rows.Count == 0)
                        //{
                        _objProjectBal.InsertFTPSFTPDetailsOutBound(_objProjectModel, Pid);
                        //}

                    }

                    #endregion

                    List<InputInboundEmailJobDTO> _emailList = new List<InputInboundEmailJobDTO>();
                    List<InputInboundFtpSftpDTO> _ftpSftpList = new List<InputInboundFtpSftpDTO>();

                    #region Input Inbound
                    #region Email
                    string _emailJobs = Convert.ToString(formcollection["hdnEmails"]);
                    if (!string.IsNullOrEmpty(_emailJobs))
                    {

                        var _emailJobRows = _emailJobs.Split('|');
                        if (_emailJobRows.Length > 0)
                        {
                            List<InputInboundEmailJobDTO> _emailDetails = new List<InputInboundEmailJobDTO>();
                            for (int ej = 0; ej < _emailJobRows.Length; ej++)
                            {
                                var _emailJobCells = _emailJobRows[ej].Split(',');
                                if (_emailJobCells.Length > 0) // && _emailJobCells.Length == 5)
                                {
                                    var _insertedEmailDetails = _objProjectBal.GetInsertedEmailDetails(_emailJobCells[3], _emailJobCells[1], _emailJobCells[2]);
                                    if (_insertedEmailDetails == null)
                                    {
                                        InputInboundEmailJobDTO obj = new InputInboundEmailJobDTO();
                                        obj.Id = Convert.ToInt32(_emailJobCells[0]);
                                        obj.JobName = _emailJobCells[1];
                                        obj.MailHost = _emailJobCells[2];
                                        obj.EmailId = _emailJobCells[3];
                                        obj.EmailPassword = _emailJobCells[4];
                                        _emailDetails.Add(obj);
                                        _emailList.Add(obj);
                                    }
                                    else
                                    {
                                        _emailList.Add(_insertedEmailDetails);
                                    }
                                }
                            }
                            _objProjectBal.InsertEmailDetails(_emailDetails, Pid);
                        }
                    }
                    #endregion

                    #region FTP-SFTP Details
                    string _ftpSftpJobs = Convert.ToString(formcollection["hdnFTPSFTP"]);
                    if (!string.IsNullOrEmpty(_ftpSftpJobs))
                    {
                        var _ftpSftpRows = _ftpSftpJobs.Split('|');
                        if (_ftpSftpRows.Length > 0)
                        {
                            List<InputInboundFtpSftpDTO> _ftpSftpDetails = new List<InputInboundFtpSftpDTO>();
                            for (int ej = 0; ej < _ftpSftpRows.Length; ej++)
                            {
                                var _ftpSftpJobCells = _ftpSftpRows[ej].Split(',');
                                if (_ftpSftpJobCells.Length > 0)
                                {
                                    var _insertedEmailDetails = _objProjectBal.GetInsertedFTPSFTPDetails(_ftpSftpJobCells[1], _ftpSftpJobCells[2], _ftpSftpJobCells[4], _ftpSftpJobCells[5]);
                                    if (_insertedEmailDetails == null)
                                    {
                                        InputInboundFtpSftpDTO obj = new InputInboundFtpSftpDTO();
                                        obj.Protocol = _ftpSftpJobCells[1];
                                        if (_ftpSftpJobCells[2] != "0")
                                        {
                                            obj.Encryption = _ftpSftpJobCells[2];
                                        }
                                        else
                                        {
                                            obj.Encryption = string.Empty;
                                        }

                                        obj.Port = Convert.ToInt32(_ftpSftpJobCells[3]);
                                        obj.Host = _ftpSftpJobCells[4];
                                        obj.FTPUserName = _ftpSftpJobCells[5];
                                        obj.FTPPassword = _ftpSftpJobCells[6];
                                        _ftpSftpDetails.Add(obj);
                                        _ftpSftpList.Add(obj);
                                    }
                                    else
                                    {
                                        _ftpSftpList.Add(_insertedEmailDetails);
                                    }
                                }
                            }
                            _objProjectBal.InsertFTPSFTPDetails(_ftpSftpDetails, Pid);
                        }
                    }
                    #endregion
                    #endregion

                    #region Project Processes


                    var _chkProcessList = formcollection["chkProcessList"];
                    int _processOrder = 1;
                    _objProjectModel.ProcessDetailNames = new List<SelectListItem>();
                    if (!string.IsNullOrEmpty(_chkProcessList))
                    {
                        ProjectBAL objProjectBAL = new ProjectBAL();
                        var _allProcess = _objProjectBal.GetProcessDetailById(_objProjectModel.Id);

                        string[] _processList = _chkProcessList.Split(',');

                        if (formcollection["Id"] != null && (Convert.ToInt32(formcollection["Id"]) > 0))
                        {
                            var _allProcessIds = _allProcess.Select(p => p.ProcessDetailId).Distinct();
                            var _selectedProcessIds = _processList.Select(p => Convert.ToInt32(p)).Distinct();

                            var result = (from x in _allProcessIds
                                          join y in _selectedProcessIds
                                          on x equals y into outer
                                          from T3 in outer.DefaultIfEmpty()
                                          where T3 == 0
                                          select x).ToList();
                            for (int i = 0; i < result.Count; i++)
                            {
                                _objProjectBal.DeleteProjectProcessList(result[i], Pid);
                            }

                        }

                        var _allProcessFromDB = objProjectBAL.GetAllProcessDetails();

                        foreach (var item in _processList)
                        {

                            var ProcessId = item;
                            var ProcessOrder = _processOrder++;
                            _objProjectBal.InsertProjectProcessList(ProcessId, Pid, ProcessOrder);

                            var foundProcess = _allProcessFromDB.Find(p => p.ProcessDetailId == Convert.ToInt32(ProcessId));
                            if (foundProcess != null)
                            {
                                _objProjectModel.ProcessDetailNames.Add(new SelectListItem() { Text = foundProcess.ProcessDetailName, Value = ProcessId });
                            }
                        }
                    }
                    #endregion

                    if (Request.Files.Count > 0)
                    {
                        for (int i = 0; i < Request.Files.Count; i++)
                        {
                            var fItem = Request.Files[i];
                            if (fItem.ContentLength > 0)
                            {
                                ProjectDocuments doc = new ProjectDocuments();
                                doc.Id = 0;
                                doc.ProjectId = Pid;
                                doc.DocName = fItem.FileName;
                                //doc.DocPath = fItem.FileName;
                                doc.DocSize = ((fItem.ContentLength / 1024M) > 1024) ? (fItem.ContentLength / 1048576M).ToString("F") + " MB" : (fItem.ContentLength / 1024M).ToString("F") + " KB";
                                doc.ContentType = fItem.ContentType;
                                _objProjectBal.InsertUpdateProjectDocument(doc);

                                #region Create Directory if not exist
                                string _projectDocs = Request.MapPath("~/ProjectDocuments");
                                if (!System.IO.Directory.Exists(_projectDocs))
                                {
                                    System.IO.Directory.CreateDirectory(_projectDocs);
                                }

                                _projectDocs = System.IO.Path.Combine(_projectDocs, string.Format("{0}_{1}", _objProjectModel.Id, _objProjectModel.ProjectName));
                                if (!System.IO.Directory.Exists(_projectDocs))
                                {
                                    System.IO.Directory.CreateDirectory(_projectDocs);
                                }
                                #endregion

                                string _fn = System.IO.Path.Combine(_projectDocs, doc.Id + System.IO.Path.GetExtension(doc.DocName));
                                fItem.SaveAs(_fn);
                            }
                        }
                    }

                    if (formcollection["Id"] != null && (Convert.ToInt32(formcollection["Id"]) > 0))
                    {
                        if (!string.IsNullOrEmpty(formcollection["hdnRemoveEmailId"]))
                        {
                            _objProjectBal.DeleteEmailById(formcollection["hdnRemoveEmailId"]);
                        }
                        if (!string.IsNullOrEmpty(formcollection["hdnRemoveFtpSftpId"]))
                        {
                            _objProjectBal.DeleteFtpSftpById(formcollection["hdnRemoveFtpSftpId"]);
                        }
                        if (!string.IsNullOrEmpty(formcollection["hdnDeleteDocumentIds"]))
                        {
                            _objProjectBal.DeleteProjectDocumentById(formcollection["hdnDeleteDocumentIds"]);
                            string[] _projectDocId;
                            _projectDocId = formcollection["hdnDeleteDocumentIds"].Split(',');
                            for (int i = 0; i < _projectDocId.Length; i++)
                            {
                                try
                                {
                                    System.IO.DirectoryInfo _folder = new System.IO.DirectoryInfo(Request.MapPath(string.Format("~/ProjectDocuments/{0}_{1}", _objProjectModel.Id, _objProjectModel.ProjectName)));
                                    if (_folder.Exists)
                                    {
                                        var foundFiles = _folder.GetFiles(_projectDocId[i] + ".*");
                                        if (foundFiles.Length > 0)
                                        {
                                            foundFiles[0].Delete();
                                        }
                                    }
                                }
                                catch { }
                            }
                        }
                    }
                    /*Start Commented By Niyati*/
                    //SendMail(_objProjectModel, _emailList, _ftpSftpList);
                    /* End Commented By Niyati*/
                }
            }
            catch
            {
                throw;
            }
            return RedirectToAction("List", "Project");
        }

        private void SendMail(ProjectModel obj, List<InputInboundEmailJobDTO> eamilDetails, List<InputInboundFtpSftpDTO> ftpSftpDetails)
        {
            var _config = Utility.MailConfiguration.Config["DocflowRobot"];
            var _mailTemplate = Utility.MailConfiguration.MailTemplate["ProjectCreateUpdate"];
            string _subject = (obj.Id > 0) ? obj.ProjectName + " Project Updates" : "New Docflow Project - " + obj.ProjectName;
            string _body = _mailTemplate.HTMLBody; //string _body = System.IO.File.ReadAllText(HttpContext.Server.MapPath(@"~/Templates/Email.html"));
            _body = _body.Replace("[[@MailTitle]]", _subject);

            //_body = _body.Replace("[[@ServerName]]", System.Environment.MachineName);
            //_body = _body.Replace("[[@ServerUser]]", System.Environment.UserName);
            //_body = _body.Replace("[[@ServerDateTime]]", DateTime.Now.ToString());

            _body = _body.Replace("[[@ProjectName]]", obj.ProjectName);
            _body = _body.Replace("[[@CompanyName]]", obj.CompanyName);
            _body = _body.Replace("[[@ProjectDescription]]", obj.ProjectDescription);

            _body = _body.Replace("[[@StartingLocation]]", obj.StartingLocation);
            _body = _body.Replace("[[@PickingList]]", (obj.IsPickingList ? "Yes" : "No"));
            _body = _body.Replace("[[@BoxStructure]]", obj.BoxStructure);
            _body = _body.Replace("[[@BoxLength]]", obj.BoxLength);
            _body = _body.Replace("[[@ScanningDPI]]", obj.ScanningDPI);
            _body = _body.Replace("[[@PatchInData]]", (obj.IsPatchInData ? "Yes" : "No"));
            _body = _body.Replace("[[@DataPath]]", obj.DataPath);
            _body = _body.Replace("[[@ProductionPath]]", obj.ProductionPath);

            PartnerBAL objPartnerBAL = new PartnerBAL();
            _body = _body.Replace("[[@Partner]]", objPartnerBAL.GetAllPartners().Find(p => p.UserId == obj.PartnerId).UserName);
            _body = _body.Replace("[[@Logitic]]", (obj.Box ? "Box" : (obj.BoxBatchBag ? "BoxBatchBag" : "BagBatchBox")));

            _body = _body.Replace("[[@DevelopmentDate]]", obj.DevelopmentDate);
            _body = _body.Replace("[[@TestingDate]]", obj.TestingDate);
            _body = _body.Replace("[[@LiveDate]]", obj.LiveDate);

            #region Proccesses
            string _processHtml = string.Empty;
            if (obj.ProcessDetailNames.Count > 0)
            {
                _processHtml += "<ul>";
                foreach (var pItem in obj.ProcessDetailNames)
                {
                    _processHtml += "<li>";
                    _processHtml += pItem.Text;
                    _processHtml += "</li>";
                }
                _processHtml += "</ul>";
            }
            _body = _body.Replace("[[@ProjectProcesses]]", _processHtml);
            #endregion

            #region Input Inboud
            _body = _body.Replace("[[@Scanning]]", (obj.InputInbound.IsScan ? "Yes" : "No"));
            #region FTPSFTP Info
            if (ftpSftpDetails.Count > 0)
            {
                string _ftpSftp = "<tr class='textdark item-line'><td class='lblCaption'>FTP/SFTP: </td><td class='lblDetails' style='color:green;'>" + ftpSftpDetails.Count + " Details Available</td></tr>";
                //string _ftpSftp = "<div class='textdark item-line'> <div class='lblCaption'> FTP/SFTP: </div> </div> <div style='clear: both; height: 1px;'> </div> <div class='datagrid'> ";
                _ftpSftp += "<tr><td colspan='2'><div class='datagrid'><table><thead><tr><th>Protocol</th><th>Encryption</th><th>Host</th><th>Port</th><th>UserName</th><th>Password</th></tr></thead><tbody>";
                foreach (var fItem in ftpSftpDetails)
                {
                    _ftpSftp += ((ftpSftpDetails.IndexOf(fItem) % 2 == 0) ? "<tr>" : "<tr class='alt'>");
                    _ftpSftp += string.Format("<td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>", fItem.Protocol, fItem.Encryption, fItem.Host, fItem.Port, fItem.FTPUserName, fItem.FTPPassword);
                    _ftpSftp += "</tr>";
                }
                _ftpSftp += "</tbody></table></div></td></tr>";
                _body = _body.Replace("[[@InputInboundFtpSftp]]", _ftpSftp);
            }
            else
            {
                string _ftpSftp = "<tr class='textdark item-line'><td class='lblCaption'>FTP/SFTP: </td><td class='lblDetails' style='color:red;'>No Details Available</td></tr>";
                _body = _body.Replace("[[@InputInboundFtpSftp]]", _ftpSftp);
            }
            #endregion

            #region Email Info
            if (eamilDetails.Count > 0)
            {
                string _email = "<tr class='textdark item-line'><td class='lblCaption'>Email: </td><td class='lblDetails' style='color:green;'>" + eamilDetails.Count + "Details Available</td></tr>";
                //string _email = "<div class='textdark item-line'> <div class='lblCaption'>Email: </div> </div> <div style='clear: both; height: 1px;'> </div> <div class='datagrid'> ";
                _email += "<tr><td colspan='2'><div class='datagrid'><table><thead><tr><th>JobName</th><th>Host</th><th>Email</th><th>Password</th></tr></thead><tbody>";
                foreach (var eItem in eamilDetails)
                {
                    _email += ((eamilDetails.IndexOf(eItem) % 2 == 0) ? "<tr>" : "<tr class='alt'>");
                    _email += string.Format("<td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td>", eItem.JobName, eItem.MailHost, eItem.EmailId, eItem.EmailPassword);
                    _email += "</tr>";
                }
                _email += "</tbody></table></div></td></tr>";
                _body = _body.Replace("[[@InputInboundEmails]]", _email);
            }
            else
            {
                //string _email = "<div class='textdark item-line'> <div class='lblCaption'>Email: </div> <p style='color: red;'> No Details Available </p></div>";
                string _email = "<tr class='textdark item-line'><td class='lblCaption'>Email: </td><td class='lblDetails' style='color:red;'>No Details Available</td></tr>";
                _body = _body.Replace("[[@InputInboundEmails]]", _email);
            }
            #endregion
            #endregion

            #region Transfer
            if (obj.IsFtpSftpScan)
            {
                string _transferFtpSftp = "<tr class='textdark item-line'><td class='lblCaption'>Transfer Details: </td><td class='lblDetails' style='color:green;'>" + obj.Protocol + "</td></tr>";
                _transferFtpSftp += "<tr><td colspan='2'><div class='datagrid'><table><thead><tr><th>Protocol</th><th>Encryption</th><th>Host</th><th>Port</th><th>UserName</th><th>Password</th></tr></thead><tbody>";
                _transferFtpSftp += "<tr>"; //"<tr class='alt'>";
                _transferFtpSftp += string.Format("<td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>", obj.Protocol, obj.ProtocolEncryption, obj.Url, obj.Port, obj.UserName, obj.Password);
                _transferFtpSftp += "</tr></tbody></table></div></td></tr>";
                _body = _body.Replace("[[@TransferDetails]]", _transferFtpSftp);
            }
            else
            {
                string _networkPath = string.Empty;
                if (string.IsNullOrEmpty(obj.NetworkPath))
                {
                    _networkPath = "<tr class='textdark item-line'><td class='lblCaption'>Local/Network Path: </td><td class='lblDetails' style='color:red;'> No Details Available... </td></tr>";
                }
                else
                {
                    _networkPath = "<tr class='textdark item-line'><td class='lblCaption'>Local/Network Path: </td><td class='lblDetails' style='color:green;'>" + obj.NetworkPath + "</td></tr>";
                }
                //string _networkPath = string.Format("<tr class='textdark item-line'><td class='lblCaption'>Local/Network Path:</td><td class='lblDetails'>{0}</td></tr>", obj.NetworkPath);
                _body = _body.Replace("[[@TransferDetails]]", _networkPath);
            }
            #endregion


            #region Project Documents
            ProjectBAL objProjectBAL = new ProjectBAL();
            var _projectdocuments = objProjectBAL.GetProjectDocumentsById(obj.Id);
            if (_projectdocuments.Count > 0)
            {
                string _doc = "<tr class='textdark item-line'><td class='lblCaption'>Project Documents: </td><td class='lblDetails' style='color:green;'>" + _projectdocuments.Count + " Details Available</td></tr>";
                _doc += "<tr><td colspan='2'><div class='datagrid'><table><thead><tr><th>No</th><th>FileName</th><th>Media Type</th><th>FileSize</th></tr></thead><tbody>";
                foreach (var dItem in _projectdocuments)
                {
                    _doc += ((_projectdocuments.IndexOf(dItem) % 2 == 0) ? "<tr>" : "<tr class='alt'>");
                    _doc += string.Format("<td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td>", (_projectdocuments.IndexOf(dItem) + 1), dItem.DocName, dItem.ContentType, dItem.DocSize);
                    _doc += "</tr>";
                }
                _doc += "</tbody></table></div></td></tr>";
                _body = _body.Replace("[[@ProjectDocuments]]", _doc);
            }
            else
            {
                //string _email = "<div class='textdark item-line'> <div class='lblCaption'>Email: </div> <p style='color: red;'> No Details Available </p></div>";
                string _email = "<tr class='textdark item-line'><td class='lblCaption'>Email: </td><td class='lblDetails' style='color:red;'>No Details Available</td></tr>";
                _body = _body.Replace("[[@ProjectDocuments]]", _email);
            }
            #endregion

            Utility.MailHelper.SendMail(_config.EmailId, _mailTemplate.ToRecipient, _mailTemplate.CcRecipient, _body, _subject, _config.EmailId, _config.MailPassword, _config.MailHost, _config.Port, _config.EnableSSL, null);
        }

        [HttpPost]
        public ActionResult GetInputInBoundEmailJobs(string jobName, string host, string emailId, string pwd)
        {
            return PartialView("_Create_EmailJobs", jobName);
        }

        [HttpPost]
        public ActionResult Logout()
        {
            System.Web.Security.FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            return RedirectToAction("Login", "Home");
        }

        public JsonResult IsProjectExist(string ProjectName, int Id)
        {
            if (Id == 0)
            {
                ProjectBAL objProjectDao = new ProjectBAL();
                return Json(objProjectDao.IsProjectExist(ProjectName), JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(true);
            }
        }

        public ActionResult Download(string FName, string ContentType)
        {
            if (System.IO.File.Exists(Request.MapPath(FName)))
            {
                return File(FName, ContentType);
            }
            else
            {
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);
            }
        }

        //[HttpPost]
        public ActionResult DeleteDocument(int Id)
        {
            return new HttpStatusCodeResult(System.Net.HttpStatusCode.NotFound);
        }


        #region PickingList Methods
        #region Load
        [HttpGet]
        public ActionResult PickingList(string projectName)
        {
            ViewBag.ProjectName = projectName;
            return View("PickingList");
        }
        [HttpPost]
        public JsonResult GetHeaders(string projectName)
        {
            var finalObj = new Dictionary<string, object>();
            finalObj.Add("Id", new { key = true, create = false, edit = false, list = false });
            finalObj.Add("No", new { create = false, edit = false, title = "No" });
            finalObj.Add("BoxNo", new { create = true, edit = true, title = "BoxNo" });
            if (Session != null && Session["LoggedUser"] != null)
            {
                var user = Session["LoggedUser"] as UserDTO;
                var foundProject = user.Projects.Find(p => p.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
                if (foundProject != null)
                {
                    PickingListBAL objPickingListBAL = new PickingListBAL(foundProject.ProjectConnectionString);
                    List<string> result = objPickingListBAL.GetPickingListHeader();
                    for (int i = 0; i < result.Count; i++)
                    {
                        if (i < 2)
                        {
                            finalObj.Add("Free" + (i + 1), new { create = true, edit = true, title = result[i] });
                        }
                        else
                        {
                            finalObj.Add("Free" + (i + 1), new { create = true, edit = true, title = result[i], visibleResponsive = true });
                        }
                    }
                }
            }
            return Json(finalObj);
        }
        [HttpPost]
        public JsonResult GetPickingListData(string projectName, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            PickingListResult pickingListModel = new PickingListResult();
            if (Session != null && Session["LoggedUser"] != null)
            {
                var user = Session["LoggedUser"] as UserDTO;
                var foundProject = user.Projects.Find(p => p.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
                if (foundProject != null)
                {
                    PickingListBAL objPickingListBAL = new PickingListBAL(foundProject.ProjectConnectionString);
                    pickingListModel = objPickingListBAL.GetPickingListRecords(jtStartIndex, jtPageSize, jtSorting);
                }
                else
                {
                    pickingListModel.CustomErrorMessage = string.Format("Invalid Project '{0}' !!! Please check project name.", projectName);
                }
            }
            if (pickingListModel.Error != null && !string.IsNullOrEmpty(pickingListModel.CustomErrorMessage))
            {
                return Json(new { Result = "ERROR", Message = pickingListModel.CustomErrorMessage });
            }
            else
            {
                return Json(new { Result = "OK", Records = pickingListModel.Data, TotalRecordCount = pickingListModel.TotalRecordCount });
            }
        }
        #endregion

        [HttpPost]
        public JsonResult UpdatePickingListData(PickingListDTO item, string projectName)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { Result = "ERROR", Message = "Form is not valid! Please correct it and try again." });
                }

                if (Session != null && Session["LoggedUser"] != null)
                {
                    var user = Session["LoggedUser"] as UserDTO;
                    var foundProject = user.Projects.Find(p => p.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
                    PickingListBAL objPickingListBAL = new PickingListBAL(foundProject.ProjectConnectionString);
                    objPickingListBAL.UpdatePickingListRecord(item);
                }
                else
                {
                    throw new Exception("Session Time Out. Please do login again.");
                }
                return Json(new { Result = "OK" });
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult AddPickingListData(PickingListDTO record, string projectName)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json(new { Result = "ERROR", Message = "Form is not valid! Please correct it and try again." });
                }

                if (Session != null && Session["LoggedUser"] != null)
                {
                    var user = Session["LoggedUser"] as UserDTO;
                    var foundProject = user.Projects.Find(p => p.ProjectName.Trim().ToLower() == projectName.Trim().ToLower());
                    PickingListBAL objPickingListBAL = new PickingListBAL(foundProject.ProjectConnectionString);
                    objPickingListBAL.AddPickingListRecord(record);
                    return Json(new { Result = "OK", Record = record });
                }
                else
                {
                    throw new Exception("Session Time Out. Please do login again.");
                }
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }
        #endregion
    }

}
