﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using WebTool.Models;
using DocflowWebTool.Utility;

namespace DocflowWebTool.Controllers
{
    public class PickingController : PickingBaseController
    {
        public ActionResult Index()
        {
            PickingModel data = null;
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundproject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    data = new PickingModel();
                    data.IsPickingAvailable = foundproject.IsPickingList;
                    data.Barcode = string.Empty;
                    data.RecieveDate = DateTime.Now.ToString("dd MMMM yyyy - hh:mm tt");
                    data.BoxLength = foundproject.BoxLength;

                    if (TempData["LastSuccessBox"] != null && Convert.ToString(TempData["LastSuccessBox"]) != string.Empty)
                    {

                        SetViewBagSuccess(string.Format("Last box entered {0}", TempData["LastSuccessBox"]));
                        if (data.IsPickingAvailable)
                        {
                            data.BoxNo = Convert.ToString(TempData["LastSuccessBox"]);
                        }

                        if (TempData["LastSuccessBarcode"] != null && Convert.ToString(TempData["LastSuccessBarcode"]) != string.Empty)
                        {
                            SetViewBagSuccess(string.Format("Last box-barcode entered {0}-{1}", TempData["LastSuccessBox"], TempData["LastSuccessBarcode"]));
                        }
                    }
                    return View(data);
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                ViewBag.PartnerList = new PartnerBAL().GetAllPartners();
                return View(data);
            }
        }

        /// <summary>
        /// this function will be used for verify project details
        /// </summary>
        /// <returns></returns>
        public ActionResult VerifyProject()
        {
            if (TempData["Warning"] != null)
            {
                SetViewBagWarning(Convert.ToString(TempData["Warning"]));
            }
            return View();
        }


        [HttpPost]
        public ActionResult Index(PickingModel data)
        {
            try
            {
                if (ModelState.IsValid)
                {
                   PickingListBAL objPickingBAL = new PickingListBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                    objPickingBAL.AddPickedBox(data, data.Operator, SessionDetails.UserId);
                    TempData["LastSuccessBox"] = data.BoxNo;
                    if (data.IsPickingAvailable)
                    {
                        TempData["LastSuccessBarcode"] = data.Barcode;
                    }
                    return RedirectToAction("Index", "Picking");
                }
                else
                {
                    return View(data);
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
                return View(data);
            }
        }

        [HttpPost]
        public ActionResult VerifyProject(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
                SecondLoginModel objSession2 = new SecondLoginModel();
                objSession2.Operator = collection["Operator"];
                objSession2.ProjectName = collection["ProjectName"];
                Session["SecondLoginModel"] = objSession2;
                //string s = DocflowWebTool.Utility.Utilities.EncodeTo64(string.Format("ProjectName={0}&PickingName={1}", _pn, _tn));
                return RedirectToAction("Index", "Picking");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Logout()
        {
            Session.Remove("SecondLoginModel");
            return RedirectToAction("VerifyProject");
        }


        public JsonResult IsValidBox(string BoxNo, int BoxLength)
        {
            return Json((BoxNo.Length == BoxLength), JsonRequestBehavior.AllowGet);
        }

        public ActionResult ListBoxDetails()
        {
            try
            {
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    ViewBag.IsPickingListAvailable = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].IsPickingList;
                }
                else
                {
                    TempData["Warning"] = "Page was refreshed or session expired. Please give required details again.";
                    return RedirectToAction("VerifyProject", "Picking");
                }
            }
            catch (Exception ex)
            {
                SetViewBagError(ex);
            }
            return View();
        }


        [HttpPost]
        [System.Web.Services.WebMethod(EnableSession = true)]
        public JsonResult GetPickingBoxDetails(string boxNo, string barcode, string startDateTime, string endDateTime, int jtStartIndex, int jtPageSize, string jtSorting)
        {
            try
            {
                PickingListBAL objPickingBAL = null;
                List<PickingModelDTO> objResultList = new List<PickingModelDTO>();
                DateTime? _st = null, _et = null;

                DateTime _sd, _ed;
                if (DateTime.TryParseExact(startDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _sd))
                {
                    _st = _sd;
                }
                if (DateTime.TryParseExact(endDateTime, "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _ed))
                {
                    _et = _ed;
                }
                if (!string.IsNullOrEmpty(SessionDetails.SecondLoginInfo.ProjectName))
                {
                    var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
                    objPickingBAL = new PickingListBAL(foundProject.ProjectConnectionString);
                    //objResultList = objPickingBAL.GetPickingBoxDetails(boxNo, barcode, SessionDetails.SecondLoginInfo.Operator, _st, _et, foundProject.IsPickingList, jtStartIndex, jtPageSize, jtSorting);
                    objResultList = objPickingBAL.GetPickingBoxDetails(boxNo, barcode, _st, _et, foundProject.IsPickingList, jtStartIndex, jtPageSize, jtSorting);
                    return Json(new { Result = "OK", Records = objResultList, TotalRecordCount = objPickingBAL.TotalRecordCount });
                }
                else
                {
                    throw new Exception("Project name is empty, either session is expired or update your project details in DB. Please contact IT team.");
                }

            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }

        [HttpPost]
        public JsonResult GetHeaders()
        {

            var finalObj = new Dictionary<string, object>();
            finalObj.Add("Id", new { key = true, create = false, edit = false, list = false });
            finalObj.Add("No", new { edit = false, title = "No" });
            finalObj.Add("BoxNo", new { edit = true, title = "BoxNo" });

            var foundProject = ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName];
            if (foundProject == null)
            {
                if (HttpContext.Request.IsAjaxRequest())
                {
                    return new JsonResult { Data = "LogOut", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    RedirectToAction("Login", "Account");
                }
            }
            if (foundProject.IsPickingList)
            {
                finalObj.Add("Barcode", new { edit = true, title = "Barcode" });
            }
            finalObj.Add("RecievedTime", new { edit = true, title = "Recieved Time" });
            if (foundProject.IsPickingList)
            {
                PickingListBAL objPickingListBAL = new PickingListBAL(ProjectDetails.ProjectInfo[SessionDetails.SecondLoginInfo.ProjectName].ProjectConnectionString);
                List<string> result = objPickingListBAL.GetPickingListHeader();
                for (int i = 0; i < result.Count; i++)
                {
                    finalObj.Add("Free" + (i + 1), new { edit = false, title = result[i], visibleResponsive = true });
                }
            }
            return Json(finalObj);
        }
    }
}
