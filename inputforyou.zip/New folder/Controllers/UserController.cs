﻿using DocflowWebTool.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.BAL;
using WebTool.Models;
using WebTool.Utilities;

namespace DocflowWebTool.Controllers
{
    public class UserController : Controller
    {
        public ActionResult UserList()
        {
            return View();
        }

        [HttpPost]
        public JsonResult UserList(string projectName, int UserTypeId, string UserName = null, string FirstName = null, int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
            WebTool.BAL.UserBAL objUserBAL = new WebTool.BAL.UserBAL(foundProject.ProjectConnectionString);
            int recordscount = 0;
            List<WebTool.Models.UserListModel> objuserlist = objUserBAL.UserList(UserName, FirstName, UserTypeId);

            recordscount = objuserlist.Count();
            #region sorting
            if (string.IsNullOrEmpty(jtSorting) || jtSorting.Equals("userName ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.UserName).ToList();
            }
            else if (jtSorting.Equals("userName DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.UserName).ToList();
            }
            else if (jtSorting.Equals("firstname ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.FirstName).ToList();
            }
            else if (jtSorting.Equals("firstname DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.FirstName).ToList();
            }
            else if (jtSorting.Equals("lastname ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.LastName).ToList();
            }
            else if (jtSorting.Equals("lastname DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.LastName).ToList();
            }
            else if (jtSorting.Equals("location ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.Location).ToList();
            }
            else if (jtSorting.Equals("location DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.Location).ToList();
            }
            else if (jtSorting.Equals("UserType ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.UserType).ToList();
            }
            else if (jtSorting.Equals("UserType DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.UserType).ToList();
            }
            else if (jtSorting.Equals("status ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.status).ToList();
            }
            else if (jtSorting.Equals("status DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.status).ToList();
            }
            else if (jtSorting.Equals("IsWebAccess ASC"))
            {
                objuserlist = objuserlist.OrderBy(p => p.IsWebAccess).ToList();
            }
            else if (jtSorting.Equals("IsWebAccess DESC"))
            {
                objuserlist = objuserlist.OrderByDescending(p => p.IsWebAccess).ToList();
            }

            #endregion
            #region Paging
            if (jtPageSize > 0)
            {
                objuserlist = objuserlist.Skip(jtStartIndex).Take(jtPageSize).ToList();//Paging
            }
            else
            {
                objuserlist = objuserlist.ToList();
            }
            #endregion

            return Json(new { Result = "OK", Records = objuserlist, TotalRecordCount = recordscount }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetRoleList(string projectName)
        {
            try
            {
                var foundProject = ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()];
                WebTool.BAL.UserBAL objUserBAL = new WebTool.BAL.UserBAL(foundProject.ProjectConnectionString);
                var objRoleDTO = objUserBAL.GetRoleList(projectName).Select(x => new { DisplayText = x.UserType, Value = x.UserTypeId });
                return Json(new { Result = "OK", Options = objRoleDTO }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public JsonResult GetCompanyList(string projectName)
        {
            try
            {
                WebTool.BAL.UserBAL objUserBAL = new WebTool.BAL.UserBAL(ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()].ProjectConnectionString);

                var companyOption = objUserBAL.GetCompanyList().Select(x => new { DisplayText = x.CompanyName, Value = x.CompanyId });
                if (companyOption == null || companyOption.Count() == 0)
                {
                    return Json(new { Result = "ERROR", Message = "No Company Records Found !!!" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { Result = "OK", Options = companyOption }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                string _msg = ex.Message;
                if (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message))
                {
                    _msg += System.Environment.NewLine + ex.InnerException.Message;
                }
                return Json(new { Result = "ERROR", Message = _msg }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult InsertUpdate(UserListModel record, string projectName)
        {
            WebTool.BAL.UserBAL objUserBAL = new WebTool.BAL.UserBAL(ProjectDetails.ProjectInfo[projectName.Trim().ToUpper()].ProjectConnectionString);
            bool result = objUserBAL.InsertUpdateRole(record);
            return Json(new { Result = (result ? "OK" : "Error"), Record = record, Message = "Unable to create/update data." }, JsonRequestBehavior.AllowGet);
        }


    }
}