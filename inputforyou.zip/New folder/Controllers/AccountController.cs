﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebTool.Models;
using WebTool.BAL;

namespace DocflowWebTool.Controllers
{
    public class AccountController : IFYController
    {
        //
        // GET: /Account/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            if (!string.IsNullOrEmpty(Request.QueryString["pn"]))
            {
                TempData["pn"] = Request.QueryString["pn"];
            }
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string _pn = Convert.ToString(TempData["pn"]);
                    string _cs = System.Configuration.ConfigurationManager.AppSettings["CONNSTRING"];

                    LoginBAL m_LoginBAL = new LoginBAL(_cs);
                    m_LoginBAL.UserName = model.UserName.Trim();
                    m_LoginBAL.Password = model.Password.Trim();
                    m_LoginBAL.ConnectionString = _cs;
                    UserDTO result = m_LoginBAL.DoLogin();
                    if (result != null)
                    {
                        Session["LoggedUser"] = result;
                        if (result.UserType.Trim().ToLower() == "admin" || result.UserType.Trim().ToLower() == "developer")
                        {
                            return RedirectToAction("DashBoard", "Home", (_pn == string.Empty) ? null : new { pn = _pn });
                        }
                        else if (result.UserType.Trim().ToLower() == "typetransport" || result.UserType.Trim().ToLower() == "transport")
                        {
                            return RedirectToAction("VerifyProject", "Transporter", (_pn == string.Empty) ? null : new { pn = _pn });
                        }
                        else if (result.UserType.Trim().ToLower() == "typepicking" || result.UserType.Trim().ToLower() == "picking")
                        {
                            return RedirectToAction("VerifyProject", "Picking", (_pn == string.Empty) ? null : new { pn = _pn });
                        }
                        else if (result.UserType.Trim().ToLower() == "partner")
                        {
                            return RedirectToAction("VerifyProject", "Atelier", (_pn == string.Empty) ? null : new { pn = _pn });
                        }
                        else
                        {
                            throw new Exception("No valid user type found... No access to site...");
                        }
                    }
                    else
                    {
                        ViewBag.InvalidMessage = "User Name or Password is Wrong!!!";
                        Session["LoggedUser"] = null;
                        return View(model);
                    }
                }
                else
                {
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                Utility.Logger.WriteLog(ex);
                SetViewBagError(ex);
                return View(model);
            }
        }


        public JsonResult IsProjectExist(string ProjectName)
        {
            WebTool.BAL.ProjectBAL objProjectDao = new WebTool.BAL.ProjectBAL();
            return Json(!objProjectDao.IsProjectExist(ProjectName), JsonRequestBehavior.AllowGet);
        }
    }
}
