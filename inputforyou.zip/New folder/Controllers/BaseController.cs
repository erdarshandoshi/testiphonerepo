﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Threading;
using System.Web.Routing;

namespace DocflowWebTool.Controllers
{
    public interface IUitility
    {
        void SetViewBagWarning(string warning);
        void SetViewBagSuccess(string success);
        void SetViewBagError(string error);
        void SetViewBagError(Exception ex);
    }

    public class IFYController : Controller, IUitility
    {
        public void SetViewBagWarning(string warning)
        {
            ViewBag.Warning = warning;
        }

        public void SetViewBagSuccess(string success)
        {
            ViewBag.Success = success;
        }

        public void SetViewBagError(string error)
        {
            ViewBag.Error = error;
        }

        public void SetViewBagError(Exception ex)
        {
            ViewBag.Exception = ex;
        }
    }

    public class BaseController : IFYController
    {
        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.HttpContext.Session == null || filterContext.HttpContext.Session["LoggedUser"] == null)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = 403;
                    filterContext.Result = new JsonResult { Data = "LogOut", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                    filterContext.Result = RedirectToAction("Login", "Account");
            }
            else
            {
                base.OnActionExecuted(filterContext);
                //base.Execute(filterContext.RequestContext);
            }

        }
    }

    public class TransporterBaseController : IFYController
    {
        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.HttpContext.Session == null || filterContext.HttpContext.Session["LoggedUser"] == null)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = 403;
                    filterContext.Result = new JsonResult { Data = "LogOut", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    filterContext.Result = RedirectToAction("Login", "Account");
                }
            }
            else
            {
                var _user = filterContext.HttpContext.Session["LoggedUser"] as WebTool.Models.UserDTO;
                if (_user.UserType.Trim().ToLower() != "typetransport" || !_user.UserType.Trim().ToLower().Contains("transport"))
                {
                    filterContext.Result = RedirectToAction("Login", "Account", new { Message = "You are not transporter." });
                }
                else
                {
                    base.OnActionExecuted(filterContext);
                }
            }
        }
    }

    public class PickingBaseController : IFYController
    {
        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.HttpContext.Session == null || filterContext.HttpContext.Session["LoggedUser"] == null)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = 403;
                    filterContext.Result = new JsonResult { Data = "LogOut", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    filterContext.Result = RedirectToAction("Login", "Account");
                }
            }
            else
            {
                var _user = filterContext.HttpContext.Session["LoggedUser"] as WebTool.Models.UserDTO;
                if (_user.UserType.Trim().ToLower() != "typepicking" || !_user.UserType.Trim().ToLower().Contains("picking"))
                {
                    filterContext.Result = RedirectToAction("Login", "Account", new { Message = "You are not Picker." });
                }
                else
                {
                    base.OnActionExecuted(filterContext);
                }
            }
        }
    }

    public class AtelierBaseController : IFYController
    {
        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.HttpContext.Session == null || filterContext.HttpContext.Session["LoggedUser"] == null)
            {
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = 403;
                    filterContext.Result = new JsonResult { Data = "LogOut", JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                }
                else
                {
                    filterContext.Result = RedirectToAction("Login", "Account");
                }
            }
            else
            {
                var _user = filterContext.HttpContext.Session["LoggedUser"] as WebTool.Models.UserDTO;
                if (_user.UserType.Trim().ToLower() != "partner")
                {
                    filterContext.Result = RedirectToAction("Login", "Account", new { Message = "You are not Partner." });
                }
                else
                {
                    base.OnActionExecuted(filterContext);
                }
            }
        }
    }


}